# 3KO — Contemporary Nigerian Fashion Brand E-Commerce Platform

Comprehensive implementation blueprint for the 3KO digital flagship, translating the visual reference mock-up and brand philosophy into a production-grade contemporary fashion e-commerce platform.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The implementation plan documents the complete architectural specification, design tokens, responsive layout rules, and e-commerce state management for developer handover and production deployment.

- **Brand Architecture**: Dual-pillar collection model — **3KO STREET** (urban, heavy cottons, bold graphics, dropped shoulders) and **3KO FORM** (clean, tailored piques, French linen blends, smart-casual).
- **The Lagos Collection System**: A 9-location cultural archive (001 Ikoyi to 009 Freedom Park), each anchored by GPS coordinates, historical lore, distinct color identity, and custom packaging.
- **E-Commerce Scope**: Client-side state architecture with multi-currency conversion (**NGN ₦**, **USD $**, **GBP £**), dynamic slide-out cart, persistent wishlist, comprehensive sizing charts, and a multi-step checkout simulator with localized Nigerian dispatch and DHL Worldwide integration.
- **Developer Package Delivery**: Standalone codebase archived at `public/3ko-source-code.zip` with complete setup documentation in `DEVELOPER_HANDOFF.md`.

---

## 1. Overview & Core Concept

- **What It Does**: A digital flagship for 3KO (*"Lagos in Every Thread"*), merging contemporary streetwear, smart-casual tailoring, and location-based African storytelling with an editorial, international fashion aesthetic.
- **Target Audience / Persona**: Culturally discerning, style-forward Nigerian and international audiences seeking high-quality African fashion that avoids clichés, prioritizing contemporary minimalism and urban craftsmanship.
- **Key Value**: Delivers the tactile aura of a high-fashion label campaign with practical e-commerce functionality: real-time sizing guides, interactive packaging previews, and multi-currency ordering.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Campaign & Discovery Flow**:
   - Arrive at the cinematic hero overlooking the Lekki-Ikoyi Link Bridge.
   - Interact with the `01 / 03` campaign pager or explore the dual **3KO STREET** and **3KO FORM** editorial panels.
   - Browse the 9-part horizontal Lagos Collections carousel on warm cream `#F4F1EA` canvas.
2. **Product Exploration & Fit Verification**:
   - Filter by brand line (`Street`, `Form`, `Editions`) or location (`001 Ikoyi` to `009 Freedom Park`).
   - Open Product Detail Page (PDP) with sticky purchase module, colorway swatches, fabric specifications, and dual-unit (CM / Inches) architectural fit guide.
3. **Cart & Bag Management**:
   - Slide-out bag drawer with real-time quantity stepper, item removal, promo code discount (`LAGOSFIRST` for 10% off), and a dynamic free-shipping progress tracker (₦100,000 / $70 threshold).
4. **Checkout & Order Confirmation**:
   - Two-step checkout: Shipping information (with Nigerian states + global countries) $\to$ Payment selection (Paystack, International Cards, Apple Pay) $\to$ Confirmed order receipt with generated tracking serial (`#3KO-LGS-XXXXXX`) and printable receipt.

### Visual Identity & Theme

- **Aesthetic Direction**: High-contrast, editorial, minimal contemporary streetwear; restrained and confident; no generic ornamental clutter.
- **Color Tokens**:
  - **Base Canvas**: Jet Black (`#080808`), Structural Charcoal (`#121212` / `#181818`), Off-White / Cream (`#F4F1EA`), Crisp White (`#FFFFFF`).
  - **Lagos 9-Collection Identity Palette**:
    - `001 IKOYI` — Black (`#080808`)
    - `002 NATIONAL THEATRE` — White (`#FFFFFF`)
    - `003 LAGOS ISLAND` — Dark Blue (`#1E3A8A`)
    - `004 BALOGUN` — Red (`#DC2626`)
    - `005 TARKWA BAY` — Sky Blue (`#38BDF8`)
    - `006 VICTORIA ISLAND` — Green (`#16A34A`)
    - `007 YABA` — Brown (`#854D0E`)
    - `008 BADAGRY` — Grey (`#64748B`)
    - `009 FREEDOM PARK` — Pink (`#EC4899`)
- **Typography Hierarchy**:
  - *Display Headings*: `Outfit` (weights 700 to 900) for bold, monumental editorial headlines.
  - *Body Prose*: `Plus Jakarta Sans` (weights 400 to 600) for clean readability.
  - *Data & Telemetry*: Monospace with tabular numerals (`tabular-nums`) for currency values, geographic coordinates, and serial numbers.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Zero-Dependency Client Router vs. External Router Library**
  - *Chosen Approach*: Lightweight browser history API sync with native popstate handling inside `ShopContext.tsx`.
  - *Why*: Provides clean, instant URL synchronization (`/`, `/shop`, `/street`, `/form`, `/collections/:slug`, `/product/:slug`, `/about`, `/lagos`, `/contact`) with zero external bundle bloat and zero hydration mismatches.
- **Decision 2: Local Storage Persistence for Bag, Orders, and Wishlist**
  - *Chosen Approach*: Client-side persistence via `localStorage` hooks.
  - *Why*: Allows instant offline state preservation across page refreshes without requiring mandatory backend authentication for browsing.
- **Decision 3: Multi-Currency Architecture**
  - *Chosen Approach*: Native price triples stored directly in product schema (`priceNGN`, `priceUSD`, `priceGBP`).
  - *Why*: Prevents awkward rounding errors and preserves intentional luxury price points across regional markets.

---

## 4. Technical Architecture & Data Strategy

### System & Component Architecture Diagram

```text
┌────────────────────────────────────────────────────────────────────────┐
│                        3KO CLIENT WEB APPLICATION                      │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
               ┌────────────────────┴────────────────────┐
               ▼                                         ▼
   ┌───────────────────────┐                 ┌───────────────────────┐
   │     Global Assets     │                 │   ShopContext Store   │
   │  • Typography         │                 │  • Cart & Wishlist    │
   │  • Brand Logo & Crops │                 │  • Currency (NGN/USD) │
   │  • Tailwind CSS v4    │                 │  • Modals & Routing   │
   └───────────┬───────────┘                 └───────────┬───────────┘
               │                                         │
               └────────────────────┬────────────────────┘
                                    │
               ┌────────────────────┴────────────────────┐
               ▼                                         ▼
   ┌───────────────────────────┐             ┌───────────────────────────┐
   │     Navigation & Layout   │             │   Interactive Overlays    │
   │  • Navbar (Sticky, 3-zone)│             │  • CartDrawer (Slide-in)  │
   │  • Footer & Social Links  │             │  • SearchModal (Live)     │
   │  • Mobile Drawer Menu     │             │  • SizeGuideModal (CM/IN) │
   │                           │             │  • CheckoutModal (2-Step) │
   │                           │             │  • QuickViewModal         │
   └─────────────┬─────────────┘             └───────────────────────────┘
                 │
                 ▼
   ┌─────────────────────────────────────────────────────────────────────┐
   │                             Page Views                              │
   │  ├── HomePage (Hero, Street/Form Panels, 9-Collection Carousel)     │
   │  ├── ShopPage (Filtering by Line & Location, Sort by Price/Feature) │
   │  ├── CollectionDetailPage (Coordinates, Cultural Lore, Palette)    │
   │  ├── ProductDetailPage (Sticky Purchase Module, Fabric, Packaging) │
   │  ├── AboutPage (Manifesto, Street/Form Pillars, Atelier Ethics)     │
   │  ├── LagosCulturalPage (Interactive 9-Sanctuary City Guide)         │
   │  └── ContactPage (Victoria Island & Ikoyi Flagships, Concierge)     │
   └─────────────────────────────────────────────────────────────────────┘
```

### Data Schema Overview

```typescript
interface Product {
  id: string;
  slug: string;
  name: string;
  subtitle: string;
  line: 'street' | 'form' | 'edition';
  collectionId: string; // '001' to '009'
  collectionName: string;
  priceNGN: number;
  priceUSD: number;
  priceGBP: number;
  color: string;
  colorHex: string;
  sizes: string[];
  description: string;
  fabricDetails: string[];
  careInstructions: string[];
  fit: string;
  images: string[];
  packagingNote: string;
}

interface LagosCollection {
  id: string; // '001' to '009'
  numberStr: string;
  slug: string;
  name: string;
  fullName: string;
  colorName: string;
  colorHex: string;
  image: string;
  landmark: string;
  coordinates: string;
  personality: string;
  shortDesc: string;
  fullStory: string;
  paletteDescription: string;
}
```

### Production Integration Points for External Developers

1. **Payment Gateway**: Connect `handleFinalPayment` in `src/components/CheckoutModal.tsx` to the Paystack Inline SDK (`@paystack/inline-js`) or Stripe Elements for live card and bank transfer settlement.
2. **Catalog Headless API**: Replace static fixtures in `src/data/products.ts` and `src/data/collections.ts` with live queries from Shopify Storefront API, Medusa.js, or Supabase.
3. **Logistics & Tracking**: Integrate DHL Express API / GIG Logistics API to replace simulated dispatch rates with live dynamic waybills.
