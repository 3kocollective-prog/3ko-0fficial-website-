# 3KO — Developer Handoff & Technical Implementation Guide

> **Brand Identity:** 3KO — LAGOS IN EVERY THREAD  
> **Type:** Contemporary Nigerian Fashion Label & E-Commerce Web Application  
> **Tech Stack:** React 19, TypeScript, Vite 8, Tailwind CSS v4, Lucide Icons, Motion  

---

## 1. Quick Start for Developers

### Prerequisites
- **Node.js**: v18.0.0 or higher
- **npm**: v9.0.0 or higher (or pnpm / yarn)

### Installation & Local Setup
```bash
# 1. Install dependencies
npm install

# 2. Run local development server (runs on http://localhost:3000)
npm run dev

# 3. Type check & lint
npm run lint

# 4. Production build
npm run build

# 5. Preview production build locally
npm run preview
```

---

## 2. Project Architecture & Directory Structure

```text
├── index.html                   # Entry HTML with Outfit & Plus Jakarta Sans typography
├── package.json                 # Dependencies & build scripts
├── tsconfig.json                # Strict TypeScript configuration
├── vite.config.ts               # Vite configuration with Tailwind CSS v4
├── DEVELOPER_HANDOFF.md         # This developer guide
│
├── public/                      # Static assets & photography
│   ├── assets/aistudio/         # Original high-res source mockups & brand wordmarks
│   └── images/
│       ├── brand/               # Hero background, Street/Form panels, City panorama, Logos
│       ├── collections/         # The 9 Lagos collection photos (001_ikoyi ... 009_freedom_park)
│       └── social/              # 6 editorial campaign Instagram shots
│
└── src/
    ├── main.tsx                 # React DOM mount point
    ├── App.tsx                  # Main Router, global layouts, and modal orchestrator
    ├── index.css                # Tailwind CSS v4 base layer, fonts, and custom scrollbars
    ├── types.ts                 # Core TypeScript definitions (Product, Collection, Cart, Order)
    │
    ├── context/
    │   └── ShopContext.tsx      # Global store (Cart, Wishlist, Multi-currency, Modals, Navigation)
    │
    ├── data/
    │   ├── collections.ts       # Definitive data for the 9 Lagos Collections (001–009)
    │   └── products.ts          # Garment catalog, pricing (NGN/USD/GBP), sizing, fabrics
    │
    ├── components/
    │   ├── Navbar.tsx           # Sticky nav with 3KO wordmark, links, currency, search, cart
    │   ├── Hero.tsx             # Cinematic campaign hero with 01/03 slide pager & CTA buttons
    │   ├── StreetFormSection.tsx# Side-by-side editorial panels for 3KO STREET vs 3KO FORM
    │   ├── LagosCollectionsSection.tsx # The 9 collection cards on cream background with color strips
    │   ├── CitySection.tsx      # Cinematic wide monochrome panorama ("THE CITY — LAGOS")
    │   ├── PackagingSection.tsx # "UNBOX LAGOS" 1200 GSM rigid collector box showcase
    │   ├── SocialSection.tsx    # 6-image Instagram editorial grid with look inspector
    │   ├── ProductCard.tsx      # Reusable card with hover alternate image, Quick Bag, and Wishlist
    │   ├── CartDrawer.tsx       # Slide-out bag drawer with quantity controls, promo codes & shipping bar
    │   ├── SearchModal.tsx      # Real-time search across products, fabrics, and collections
    │   ├── SizeGuideModal.tsx   # Fit guide with Tops & Trousers charts (CM & Inches toggle)
    │   ├── CheckoutModal.tsx    # Multi-step checkout (Nigerian states, DHL, Paystack/Cards simulator)
    │   ├── QuickViewModal.tsx   # Quick product modal with size selector
    │   └── Footer.tsx           # Black brand footer with newsletter, shop/about links, socials
    │
    └── pages/
        ├── HomePage.tsx         # Full recreation of the visual reference mockup
        ├── ShopPage.tsx         # Full catalog with line filters, location filters, and sorting
        ├── CollectionDetailPage.tsx # Dedicated location deep-dive with coordinates, lore & products
        ├── ProductDetailPage.tsx    # Luxury editorial PDP with fabric, care, and packaging
        ├── AboutPage.tsx        # Manifesto, Street & Form philosophy, ethical Lagos atelier
        ├── LagosCulturalPage.tsx    # Cultural guide exploring the 9 Lagos districts
        └── ContactPage.tsx      # Victoria Island & Ikoyi flagship showrooms, concierge form
```

---

## 3. Brand Design System & Color Tokens

### Base Palette
| Token | Hex Code | Usage |
| :--- | :--- | :--- |
| **Black** | `#080808` | Primary dark background, typography on light surfaces |
| **Charcoal** | `#181818` / `#121212` | Card backgrounds, elevated surfaces, borders |
| **Warm Cream** | `#F4F1EA` | The Lagos Collection section canvas, light trousers |
| **White** | `#FFFFFF` | Primary text on dark backgrounds, buttons, borders |

### The 9 Lagos Collection Accent System
Each collection is tied to a specific location and signature accent color:
1. **LAGOS 001 — IKOYI:** Black (`#080808` / `#181818`) — Premium / Refined / Timeless
2. **LAGOS 002 — NATIONAL THEATRE:** White (`#FFFFFF` / `#E4E2DC`) — Clean / Cultural / Purposeful
3. **LAGOS 003 — LAGOS ISLAND:** Dark Blue (`#1E3A8A`) — Historic / Urban / Bold
4. **LAGOS 004 — BALOGUN:** Red (`#DC2626`) — Energetic / Commercial / Vibrant
5. **LAGOS 005 — TARKWA BAY:** Sky Blue (`#38BDF8`) — Relaxed / Coastal / Free
6. **LAGOS 006 — VICTORIA ISLAND:** Green (`#16A34A`) — Business / Modern / Confident
7. **LAGOS 007 — YABA:** Brown (`#854D0E`) — Youthful / Creative / Grounded
8. **LAGOS 008 — BADAGRY:** Grey (`#64748B`) — Historical / Resilient / Understated
9. **LAGOS 009 — FREEDOM PARK:** Pink (`#EC4899`) — Artistic / Expressive / Contemporary

### Typography
- **Display Headings:** `Outfit` (Bold, ExtraBold, Black weights `700`, `800`, `900`) with tight tracking (`tracking-tight`).
- **Body Prose:** `Plus Jakarta Sans` (weights `300`, `400`, `500`, `600`).
- **Data & Telemetry:** Monospace (`font-mono`) with `tabular-nums` for prices, coordinates, and serial numbers.

---

## 4. Key E-Commerce & State Capabilities

1. **Multi-Currency System:**
   - Real-time conversion across **NGN (₦)**, **USD ($)**, and **GBP (£)** via `ShopContext`.
2. **Interactive Bag Drawer:**
   - Add to bag with custom sizes (`S`, `M`, `L`, `XL`, `XXL`) and colors.
   - Quantity stepper, item removal, persistent state via `localStorage`.
   - Free shipping progress threshold indicator (₦100,000 / $70).
   - Promo code validation (e.g. `LAGOSFIRST` grants 10% discount).
3. **Checkout Flow:**
   - Customer shipping details supporting all 36 Nigerian states + FCT and international destinations.
   - Shipping options: Lagos Same-Day Dispatch, Nationwide Express, DHL Express Worldwide.
   - Payment method options: Paystack, International Cards, Instant Bank Transfer, Apple Pay.
   - Confirmation screen with unique order serial (`#3KO-LGS-XXXXXX`) and print receipt utility.
4. **Search & Filter:**
   - Real-time client-side search indexing garment names, colors, collections, lines, and fabric specs.
   - Filtering by brand line (`3KO Street`, `3KO Form`, `Editions`) and collection (`001` to `009`).

---

## 5. Integrating with Headless CMS or Backend

### To connect with a Real Backend (Shopify, Medusa.js, WooCommerce, or Strapi):
- Replace `src/data/products.ts` and `src/data/collections.ts` with API fetch calls in `ShopContext.tsx`.
- Connect `handleFinalPayment` in `src/components/CheckoutModal.tsx` to the Paystack Popup SDK (`@paystack/inline-js`) or Stripe Elements.
