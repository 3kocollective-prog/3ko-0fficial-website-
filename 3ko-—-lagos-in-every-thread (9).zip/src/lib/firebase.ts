import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  User,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDoc,
  getDocFromServer,
  collection,
  query,
  where,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  serverTimestamp,
  orderBy,
} from 'firebase/firestore';
import {
  getStorage,
  ref as storageRef,
  uploadBytes,
  getDownloadURL,
  deleteObject,
} from 'firebase/storage';
import firebaseConfig from '../../firebase-applet-config.json';

// Initialize Firebase App singleton
export const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

// CRITICAL: Must pass firestoreDatabaseId from firebase-applet-config.json
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const storage = getStorage(app);

// Helper for uploading product images to Firebase Storage
export async function uploadProductImage(file: File, productId: string = 'product'): Promise<string> {
  const fileExt = file.name.split('.').pop() || 'jpg';
  const cleanFileName = `${Date.now()}-${Math.random().toString(36).substring(2, 7)}.${fileExt}`;
  const path = `products/${productId}/${cleanFileName}`;
  const imgRef = storageRef(storage, path);

  try {
    const snapshot = await uploadBytes(imgRef, file, {
      contentType: file.type || 'image/jpeg',
    });
    const downloadUrl = await getDownloadURL(snapshot.ref);
    return downloadUrl;
  } catch (error) {
    console.warn('Direct Firebase Storage upload encountered issue, falling back to data URL for seamless preview:', error);
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = () => reject(error);
      reader.readAsDataURL(file);
    });
  }
}

// Helper for deleting image from Firebase Storage
export async function deleteProductImageByUrl(imageUrl: string): Promise<void> {
  try {
    if (imageUrl && imageUrl.includes('firebasestorage.googleapis.com')) {
      const imgRef = storageRef(storage, imageUrl);
      await deleteObject(imgRef);
    }
  } catch (err) {
    console.warn('Could not remove file from storage (may already be deleted or external URL):', err);
  }
}

// Known Owner / Super Admin Email
export const OWNER_EMAIL = 'adeluolabraham@gmail.com';

// Google Provider setup
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Test connection on boot per Firebase guidelines
export async function testConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firebase client is offline or network unreachable.');
      return false;
    }
    // Missing document is normal and indicates successful connection to Firestore
    return true;
  }
}

// Test connection immediately on module load
testConnection().catch(() => {});

// Helper to sign in with Google
export async function loginWithGoogle(): Promise<User> {
  try {
    const res = await signInWithPopup(auth, googleProvider);
    return res.user;
  } catch (err) {
    console.error('Google Sign-In failed:', err);
    throw err;
  }
}

// Helper to sign in with email/password
export async function loginWithEmail(email: string, pass: string): Promise<User> {
  const res = await signInWithEmailAndPassword(auth, email.trim(), pass);
  return res.user;
}

// Helper to register the initial administrator account securely
export async function registerAdminUser(email: string, pass: string): Promise<User> {
  const normalizedEmail = email.trim().toLowerCase();
  
  // Security gate: only the designated 3KO brand owner is authorized to self-register as admin
  if (normalizedEmail !== OWNER_EMAIL.toLowerCase()) {
    throw new Error(
      `Unauthorized: Only the designated brand owner (${OWNER_EMAIL}) may register administrative credentials.`
    );
  }

  const res = await createUserWithEmailAndPassword(auth, normalizedEmail, pass);
  const user = res.user;

  // Immediately persist administrator record to /admins/{uid} in Firestore
  try {
    await setDoc(doc(db, 'admins', user.uid), {
      email: normalizedEmail,
      role: 'super_admin',
      uid: user.uid,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }, { merge: true });
  } catch (err) {
    console.warn('Note: Could not write admin document immediately (will sync on auth state change):', err);
  }

  return user;
}

// Helper to sign out
export async function logoutUser(): Promise<void> {
  await signOut(auth);
}

// Check if a user has admin privileges and ensure their Firestore admin doc is synced
export async function checkUserIsAdmin(user: User | null): Promise<boolean> {
  if (!user) return false;

  const normalizedUserEmail = user.email ? user.email.trim().toLowerCase() : '';
  const isOwnerEmail = normalizedUserEmail === OWNER_EMAIL.toLowerCase();

  // 1. Direct email match with 3KO owner: AUTHORIZE IMMEDIATELY
  if (isOwnerEmail) {
    // Non-blocking background sync of the /admins/{uid} Firestore record
    const adminDocRef = doc(db, 'admins', user.uid);
    setDoc(adminDocRef, {
      email: normalizedUserEmail,
      role: 'super_admin',
      uid: user.uid,
      updatedAt: new Date().toISOString(),
    }, { merge: true }).catch((err) => {
      console.warn('Background admin doc sync notification:', err);
    });

    return true;
  }

  // 2. Check /admins collection for other authorized administrative UIDs
  try {
    const adminDoc = await getDoc(doc(db, 'admins', user.uid));
    if (adminDoc.exists()) {
      const data = adminDoc.data();
      if (data && (data.role === 'admin' || data.role === 'super_admin')) {
        return true;
      }
    }
  } catch (e) {
    console.warn('Error verifying admin document for UID:', e);
  }

  return false;
}

export interface AuthDiagnostic {
  title: string;
  message: string;
  actionHint?: string;
}

export function formatAuthErrorMessage(error: any): AuthDiagnostic {
  const code = error?.code || '';
  const rawMsg = error?.message || String(error);

  if (code === 'auth/operation-not-allowed') {
    return {
      title: 'Authentication Provider Disabled in Firebase',
      message: 'The sign-in method you tried to use (Email/Password or Google) is currently disabled in your Firebase Project console.',
      actionHint: 'Open Firebase Console > Authentication > Sign-in method, click on "Email/Password" and toggle Enable, then click Save.',
    };
  }

  if (code === 'auth/unauthorized-domain') {
    const currentDomain = typeof window !== 'undefined' ? window.location.hostname : 'your current domain';
    return {
      title: 'Domain Not Authorized in Firebase Auth',
      message: `The domain "${currentDomain}" is not in the Authorized Domains list for your Firebase project.`,
      actionHint: `Open Firebase Console > Authentication > Settings > Authorized domains > Add domain, and add "${currentDomain}".`,
    };
  }

  if (code === 'auth/popup-blocked') {
    return {
      title: 'Google Sign-In Popup Blocked',
      message: 'Your browser or iframe preview environment blocked the Google sign-in popup.',
      actionHint: 'Please allow popups for this site, or use the direct Email & Password administrator login form below.',
    };
  }

  if (code === 'auth/popup-closed-by-user' || code === 'auth/cancelled-popup-request') {
    return {
      title: 'Google Sign-In Closed',
      message: 'The Google authentication popup was closed before completing sign-in.',
      actionHint: 'Click "SIGN IN WITH GOOGLE ADMIN" again, or use Email/Password below.',
    };
  }

  if (code === 'auth/user-not-found' || code === 'auth/invalid-credential' || code === 'auth/wrong-password') {
    return {
      title: 'Invalid Credentials or Account Not Found',
      message: 'The email or password does not match an existing Firebase Authentication user.',
      actionHint: 'If you have not created your administrator account yet, switch to "Create Admin Account" below to register it.',
    };
  }

  if (code === 'auth/email-already-in-use') {
    return {
      title: 'Account Already Exists',
      message: 'An account with this email address already exists in Firebase Authentication.',
      actionHint: 'Switch to "Sign In (Existing Admin)" to log into your account with your existing password.',
    };
  }

  if (code === 'auth/weak-password') {
    return {
      title: 'Password Too Weak',
      message: 'Firebase Authentication requires passwords to be at least 6 characters long.',
      actionHint: 'Please enter a password with at least 6 characters.',
    };
  }

  return {
    title: 'Authentication Error',
    message: rawMsg.replace(/^Firebase:\s*/i, '').replace(/\s*\([a-z0-9\/-]+\)\.?$/i, ''),
    actionHint: 'Check your credentials or verify network connection to Firebase.',
  };
}
