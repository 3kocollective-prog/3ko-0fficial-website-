/**
 * 3KO Luxury E-Commerce — Paystack Payment Gateway Integration
 * 
 * Architecture:
 * 1. Backend Authoritative Session Initialization (/api/checkout/initialize)
 * 2. Paystack Inline Popup Execution using authoritative reference & amount
 * 3. Server-side Transaction Verification (/api/paystack/verify) with Idempotency
 * 4. Zero exposure of PAYSTACK_SECRET_KEY in client bundles
 */
import { CartItem, OrderCustomer, Order } from '../types';

declare global {
  interface Window {
    PaystackPop?: {
      setup: (options: {
        key: string;
        email: string;
        amount: number; // in kobo (NGN * 100)
        currency?: string;
        ref: string;
        metadata?: Record<string, any>;
        callback: (response: { reference: string; status: string; trans: string; transaction: string; message: string }) => void;
        onClose: () => void;
      }) => {
        openIframe: () => void;
      };
    };
  }
}

export interface AuthoritativeCheckoutRequest {
  items: CartItem[];
  customer: OrderCustomer;
  shippingMethod: string;
  currency?: string;
  promoCode?: string;
  offerId?: string;
  userId?: string;
  idempotencyKey?: string;
}

export interface AuthoritativeCheckoutResponse {
  success: boolean;
  orderNumber: string;
  orderId: string;
  order?: Order;
  reference?: string | null;
  amountNGN: number;
  amountKobo: number;
  authorizationUrl?: string;
  accessCode?: string;
  publicKey?: string;
  simulated?: boolean;
  isPreOrder?: boolean;
  isNegotiated?: boolean;
  purchaseType?: 'normal' | 'negotiated' | 'preorder';
  paymentStatus?: string;
  orderStatus?: string;
  message?: string;
  error?: string;
}

export function getPaystackPublicKey(): string {
  return import.meta.env.VITE_PAYSTACK_PUBLIC_KEY || '';
}

/**
 * Loads the official Paystack Inline JavaScript library on-demand
 */
export async function loadPaystackScript(): Promise<boolean> {
  if (typeof window !== 'undefined' && window.PaystackPop) {
    return true;
  }

  return new Promise((resolve) => {
    const existing = document.getElementById('paystack-inline-script');
    if (existing) {
      existing.addEventListener('load', () => resolve(true));
      existing.addEventListener('error', () => resolve(false));
      return;
    }

    const script = document.createElement('script');
    script.id = 'paystack-inline-script';
    script.src = 'https://js.paystack.co/v1/inline.js';
    script.async = true;
    script.onload = () => resolve(true);
    script.onerror = () => {
      console.warn('Failed to load Paystack Inline JS script.');
      resolve(false);
    };
    document.body.appendChild(script);
  });
}

/**
 * Initializes Authoritative Checkout on the server
 * Backend calculates subtotal, taxes, shipping, discounts, and locked offer prices.
 */
export async function initializeAuthoritativeCheckout(
  params: AuthoritativeCheckoutRequest
): Promise<AuthoritativeCheckoutResponse> {
  const payload = {
    items: params.items.map((i) => ({
      productId: i.product.id,
      productSlug: i.product.slug,
      selectedSize: i.selectedSize,
      selectedColor: i.selectedColor,
      quantity: i.quantity,
      includeCollectorBox: i.includeCollectorBox,
    })),
    customer: params.customer,
    shippingMethod: params.shippingMethod,
    currency: params.currency || 'NGN',
    promoCode: params.promoCode,
    offerId: params.offerId,
    userId: params.userId,
    idempotencyKey: params.idempotencyKey,
  };

  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (params.idempotencyKey) {
    headers['Idempotency-Key'] = params.idempotencyKey;
  }

  const res = await fetch('/api/checkout/initialize', {
    method: 'POST',
    headers,
    body: JSON.stringify(payload),
  });

  const data = await res.json();
  if (!res.ok || !data.success) {
    throw new Error(data.error || 'Server rejected checkout initialization.');
  }

  return data;
}

/**
 * Executes Paystack Payment using the server's authoritative session
 */
export async function executePaystackCheckout({
  checkoutSession,
  customer,
  onSuccess,
  onClose,
}: {
  checkoutSession: AuthoritativeCheckoutResponse;
  customer: OrderCustomer;
  onSuccess: (reference: string, orderNumber: string) => Promise<void>;
  onClose?: () => void;
}): Promise<void> {
  const publicKey = checkoutSession.publicKey || getPaystackPublicKey();

  // If no public key is present or simulated, provide sandbox flow
  if (!publicKey || checkoutSession.simulated) {
    console.info('[3KO Paystack] Sandbox / Simulated payment flow active.');
    setTimeout(async () => {
      await onSuccess(checkoutSession.reference || checkoutSession.orderNumber, checkoutSession.orderNumber);
    }, 1200);
    return;
  }

  await loadPaystackScript();

  if (!window.PaystackPop) {
    throw new Error('Unable to mount Paystack payment gateway. Please check internet connection.');
  }

  const handler = window.PaystackPop.setup({
    key: publicKey,
    email: customer.email,
    amount: checkoutSession.amountKobo,
    currency: 'NGN',
    ref: checkoutSession.reference || `3KO-${checkoutSession.orderNumber}`,
    metadata: {
      custom_fields: [
        { display_name: 'Customer Name', variable_name: 'customer_name', value: customer.fullName },
        { display_name: 'Customer Phone', variable_name: 'customer_phone', value: customer.phone },
        { display_name: 'Order Number', variable_name: 'order_number', value: checkoutSession.orderNumber },
      ],
    },
    callback: async (response) => {
      console.info('[3KO Paystack] Callback received reference:', response.reference);
      await onSuccess(response.reference, checkoutSession.orderNumber);
    },
    onClose: () => {
      console.info('[3KO Paystack] Modal closed by customer.');
      if (onClose) onClose();
    },
  });

  handler.openIframe();
}

/**
 * Server-side payment verification client helper
 * Calls POST /api/paystack/verify
 */
export async function verifyPaymentReference(
  reference: string,
  orderNumber: string
): Promise<{ success: boolean; message: string; order?: Order }> {
  try {
    const response = await fetch('/api/paystack/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reference, orderNumber }),
    });

    const data = await response.json();

    if (!response.ok || !data.success) {
      return {
        success: false,
        message: data.error || 'Server-side payment verification failed.',
      };
    }

    return {
      success: true,
      message: data.message || 'Payment successfully verified.',
      order: data.order,
    };
  } catch (error) {
    console.error('Verification error:', error);
    return {
      success: false,
      message: error instanceof Error ? error.message : 'Network error during payment verification.',
    };
  }
}
