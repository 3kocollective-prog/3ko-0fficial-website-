import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import {
  Product,
  CartItem,
  Currency,
  Order,
  LagosCollection,
  PromoCode,
  StoreSettings,
  ThemeMode,
  SiteBanners,
  OrderWorkflowStatus,
  PaymentLifecycleStatus,
} from '../types';
import { PRODUCTS } from '../data/products';
import { LAGOS_COLLECTIONS } from '../data/collections';
import {
  auth,
  db,
  loginWithGoogle as fbLoginWithGoogle,
  loginWithEmail as fbLoginWithEmail,
  registerAdminUser as fbRegisterAdminUser,
  logoutUser,
  checkUserIsAdmin,
  handleFirestoreError,
  uploadProductImage as fbUploadProductImage,
  deleteProductImageByUrl as fbDeleteProductImage,
  OperationType,
} from '../lib/firebase';
import { User, onAuthStateChanged } from 'firebase/auth';
import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  updateDoc,
  onSnapshot,
  query,
  orderBy,
  where,
  getDocs,
  serverTimestamp,
} from 'firebase/firestore';
import { verifyPaymentReference } from '../lib/paystack';

export const DEFAULT_PROMOS: PromoCode[] = [
  { code: 'LAGOSFIRST', discountPercentage: 10, description: '10% off Lagos Launch Special', isActive: true },
  { code: '3KO10', discountPercentage: 10, description: '10% off sitewide welcoming gift', isActive: true },
  { code: 'LAGOSVIP', discountPercentage: 15, description: '15% off Collector packaging & items', isActive: true },
  { code: 'CREATIVE', discountPercentage: 20, description: '20% off for verified Lagos creatives', isActive: true },
];

export const DEFAULT_BANNERS: SiteBanners = {
  heroBanner: '/images/brand/hero_bg.jpg',
  heroSlide2: '/images/brand/street_panel.jpg',
  heroSlide3: '/images/brand/form_panel.jpg',
  streetwearBanner: '/images/brand/street_panel.jpg',
  smartwearBanner: '/images/brand/form_panel.jpg',
  packagingBanner: '/images/packaging/box_001_ikoyi.jpg',
  lagosGuideBanner: 'https://images.unsplash.com/photo-1577495508048-b635879837f1?q=80&w=2000&auto=format&fit=crop',
};

export const DEFAULT_SETTINGS: StoreSettings = {
  announcementText: 'COMPLIMENTARY LAGOS METRO DELIVERY ON ORDERS OVER ₦100,000 · WORLDWIDE SHIPPING VIA DHL',
  isAnnouncementActive: true,
  freeShippingThresholdNGN: 100000,
  freeShippingThresholdUSD: 70,
  freeShippingThresholdGBP: 55,
  contactEmail: 'concierge@3ko-lagos.com',
  contactPhone: '+234 1 234 3KO',
  flagshipLocation: '14 Admiralty Way, Lekki Phase 1, Lagos, Nigeria',
  banners: DEFAULT_BANNERS,
};

const INITIAL_ORDERS: Order[] = [
  {
    id: '3KO-LGS-891042',
    orderNumber: '3KO-LGS-891042',
    orderDate: '2026-10-26T14:32:00Z',
    customer: {
      fullName: 'Tunde Balogun',
      email: 'tunde.b@lagosarchive.ng',
      phone: '+234 802 000 1122',
      address: 'Plot 12, Admiralty Way, Lekki Phase 1',
      city: 'Lagos',
      state: 'Lagos State',
      postalCode: '105102',
      country: 'Nigeria',
    },
    items: [
      {
        id: 'lekki-link-tee-L-Black-box',
        product: PRODUCTS[0],
        selectedSize: 'L',
        selectedColor: 'Obsidian Black',
        quantity: 1,
        includeCollectorBox: true,
        boxPriceNGN: 15000,
        boxPriceUSD: 12,
        boxPriceGBP: 10,
      },
    ],
    subtotal: 55000,
    packagingFee: 15000,
    shippingFee: 0,
    discount: 5500,
    total: 64500,
    currency: 'NGN',
    shippingMethod: 'Lagos Same-Day Courier',
    paymentMethod: 'Paystack Card / Transfer',
    paymentReference: '3KO_REF_BALOGUN_001',
    paymentStatus: 'SUCCESS',
    status: 'PROCESSING',
    orderStatus: 'PROCESSING',
    isPreOrder: false,
    createdAt: '2026-10-26T14:32:00Z',
  },
  {
    id: '3KO-LGS-772195',
    orderNumber: '3KO-LGS-772195',
    orderDate: '2026-10-25T11:15:00Z',
    customer: {
      fullName: 'Chioma Adeleke',
      email: 'chioma.a@lagoscreatives.ng',
      phone: '+234 812 000 3344',
      address: 'Ahmadu Bello Way, Victoria Island',
      city: 'Lagos',
      state: 'Lagos State',
      postalCode: '101241',
      country: 'Nigeria',
    },
    items: [
      {
        id: 'national-theatre-hoodie-M-Chalk White-box',
        product: PRODUCTS[1],
        selectedSize: 'M',
        selectedColor: 'Chalk White',
        quantity: 1,
        includeCollectorBox: true,
        boxPriceNGN: 15000,
        boxPriceUSD: 12,
        boxPriceGBP: 10,
      },
    ],
    subtotal: 85000,
    packagingFee: 15000,
    shippingFee: 4500,
    discount: 0,
    total: 104500,
    currency: 'NGN',
    shippingMethod: 'Lagos Express Courier',
    paymentMethod: 'Paystack Bank Transfer',
    paymentReference: '3KO_REF_ADELEKE_002',
    paymentStatus: 'SUCCESS',
    status: 'PAID',
    orderStatus: 'PAID',
    isPreOrder: true,
    createdAt: '2026-10-25T11:15:00Z',
  },
];

interface ShopContextType {
  // Cart
  cart: CartItem[];
  addToCart: (
    product: Product,
    size: string,
    color?: string,
    qty?: number,
    includeCollectorBox?: boolean
  ) => void;
  updateQuantity: (id: string, qty: number) => void;
  toggleCartItemBox: (id: string) => void;
  removeFromCart: (id: string) => void;
  clearCart: () => void;
  totalItems: number;
  subtotal: number;

  // Currency & Pricing
  currency: Currency;
  setCurrency: (c: Currency) => void;
  formatPrice: (priceNGN?: number, priceUSD?: number, priceGBP?: number) => string;
  formatCurrentPrice: (amount: number) => string;
  freeShippingThreshold: number;

  // Wishlist
  wishlist: string[];
  toggleWishlist: (productId: string) => void;

  // UI Modals & Navigation
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;
  isCheckoutOpen: boolean;
  setIsCheckoutOpen: (open: boolean) => void;
  isSizeGuideOpen: boolean;
  setIsSizeGuideOpen: (open: boolean) => void;
  quickViewProduct: Product | null;
  setQuickViewProduct: (product: Product | null) => void;
  toastMessage: string | null;
  showToast: (msg: string) => void;
  currentRoute: string;
  navigateTo: (route: string) => void;

  // Catalog & Store Data
  products: Product[];
  collections: LagosCollection[];
  promoCodes: PromoCode[];
  validatePromoCode: (code: string) => { valid: boolean; discountPercentage: number; description?: string };
  storeSettings: StoreSettings;

  // Orders
  orders: Order[];
  createOrder: (orderData: Partial<Order>) => Promise<Order>;
  verifyPayment: (reference: string, orderNumber: string) => Promise<{ success: boolean; message: string }>;

  // Firebase Auth & Admin Authorization
  currentUser: User | null;
  isAdmin: boolean;
  isAuthLoading: boolean;
  loginWithGoogle: () => Promise<void>;
  loginWithEmail: (email: string, pass: string) => Promise<void>;
  registerAdmin: (email: string, pass: string) => Promise<void>;
  logout: () => Promise<void>;

  // Admin Dashboard Management Functions
  saveProduct: (product: Product) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
  archiveProduct: (id: string, isArchived: boolean) => Promise<void>;
  uploadProductImageFile: (file: File, productId?: string) => Promise<string>;
  deleteImageFile: (url: string) => Promise<void>;
  updateOrderStatus: (orderId: string, status: OrderWorkflowStatus, trackingNumber?: string) => Promise<void>;
  updateOrderPaymentStatus: (orderId: string, paymentStatus: PaymentLifecycleStatus) => Promise<void>;
  saveCollection: (col: LagosCollection) => Promise<void>;
  saveStoreSettings: (settings: StoreSettings) => Promise<void>;
  seedInitialData: () => Promise<void>;

  // Theme
  theme: ThemeMode;
  toggleTheme: () => void;
  setTheme: (t: ThemeMode) => void;
}

const ShopContext = createContext<ShopContextType | undefined>(undefined);

export const ShopProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // 1. Firebase Authentication State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [isAuthLoading, setIsAuthLoading] = useState<boolean>(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      setIsAuthLoading(true);
      if (user) {
        const adminStatus = await checkUserIsAdmin(user);
        setIsAdmin(adminStatus);
      } else {
        setIsAdmin(false);
      }
      setIsAuthLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // 2. Catalog & Products (Firestore sync with local fallback)
  const [products, setProducts] = useState<Product[]>(PRODUCTS);
  const [collections, setCollections] = useState<LagosCollection[]>(LAGOS_COLLECTIONS);
  const [orders, setOrders] = useState<Order[]>(INITIAL_ORDERS);
  const [storeSettings, setStoreSettings] = useState<StoreSettings>(DEFAULT_SETTINGS);
  const [promoCodes] = useState<PromoCode[]>(DEFAULT_PROMOS);

  // Sync Products from Firestore
  useEffect(() => {
    const unsub = onSnapshot(
      collection(db, 'products'),
      (snapshot) => {
        if (!snapshot.empty) {
          const list: Product[] = [];
          snapshot.forEach((docSnap) => {
            list.push({ id: docSnap.id, ...(docSnap.data() as any) });
          });
          setProducts(list);
        }
      },
      (error) => {
        console.warn('Firestore products listener fallback to static catalog:', error.message);
      }
    );

    return () => unsub();
  }, []);

  // Sync Collections from Firestore
  useEffect(() => {
    const unsub = onSnapshot(
      collection(db, 'collections'),
      (snapshot) => {
        if (!snapshot.empty) {
          const list: LagosCollection[] = [];
          snapshot.forEach((docSnap) => {
            list.push({ id: docSnap.id, ...(docSnap.data() as any) });
          });
          // Sort by numberStr
          list.sort((a, b) => a.numberStr.localeCompare(b.numberStr));
          setCollections(list);
        }
      },
      (error) => {
        console.warn('Firestore collections listener fallback to static collections:', error.message);
      }
    );

    return () => unsub();
  }, []);

  // Sync Orders from Firestore
  useEffect(() => {
    // Only fetch orders if authenticated
    if (!currentUser) {
      return;
    }

    let q = query(collection(db, 'orders'), orderBy('createdAt', 'desc'));
    // If not admin, restrict query to the user's own orders
    if (!isAdmin) {
      q = query(collection(db, 'orders'), where('userId', '==', currentUser.uid), orderBy('createdAt', 'desc'));
    }

    const unsub = onSnapshot(
      q,
      (snapshot) => {
        const list: Order[] = [];
        snapshot.forEach((docSnap) => {
          list.push({ id: docSnap.id, ...(docSnap.data() as any) });
        });
        if (list.length > 0) {
          setOrders(list);
        }
      },
      (error) => {
        console.warn('Firestore orders sync notice:', error.message);
      }
    );

    return () => unsub();
  }, [currentUser, isAdmin]);

  // Sync Settings from Firestore
  useEffect(() => {
    const unsub = onSnapshot(
      doc(db, 'settings', 'store'),
      (snap) => {
        if (snap.exists()) {
          setStoreSettings((prev) => ({ ...prev, ...(snap.data() as any) }));
        }
      },
      (error) => {
        console.warn('Firestore settings notice:', error.message);
      }
    );

    return () => unsub();
  }, []);

  // 3. Cart State (persisted)
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('3ko_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('3ko_cart', JSON.stringify(cart));
    } catch {
      // ignore
    }
  }, [cart]);

  // Wishlist state (persisted)
  const [wishlist, setWishlist] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('3ko_wishlist');
      return saved ? JSON.parse(saved) : ['prod-001', 'prod-005'];
    } catch {
      return ['prod-001', 'prod-005'];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('3ko_wishlist', JSON.stringify(wishlist));
    } catch {
      // ignore
    }
  }, [wishlist]);

  // Currency
  const [currency, setCurrencyState] = useState<Currency>(() => {
    try {
      const saved = localStorage.getItem('3ko_currency');
      return (saved as Currency) || 'NGN';
    } catch {
      return 'NGN';
    }
  });

  const setCurrency = (c: Currency) => {
    setCurrencyState(c);
    try {
      localStorage.setItem('3ko_currency', c);
    } catch {
      // ignore
    }
  };

  // Modals & Nav
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isSizeGuideOpen, setIsSizeGuideOpen] = useState(false);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [currentRoute, setCurrentRoute] = useState<string>(() => window.location.pathname || '/');

  // Client-side Router Helper
  const navigateTo = useCallback((route: string) => {
    window.history.pushState({}, '', route);
    setCurrentRoute(route);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  useEffect(() => {
    const handlePopState = () => {
      setCurrentRoute(window.location.pathname || '/');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  }, []);

  // Theme state
  const [theme, setThemeState] = useState<ThemeMode>(() => {
    try {
      const saved = localStorage.getItem('3ko_theme');
      if (saved === 'light' || saved === 'dark') return saved;
      return window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
    } catch {
      return 'dark';
    }
  });

  useEffect(() => {
    const root = document.documentElement;
    root.classList.remove('dark', 'light');
    root.classList.add(theme);
    localStorage.setItem('3ko_theme', theme);
  }, [theme]);

  const toggleTheme = useCallback(() => {
    setThemeState((prev) => (prev === 'dark' ? 'light' : 'dark'));
  }, []);

  const setTheme = useCallback((t: ThemeMode) => {
    setThemeState(t);
  }, []);

  // Pricing Helpers
  const formatPrice = useCallback(
    (priceNGN?: number, priceUSD?: number, priceGBP?: number): string => {
      const ngn = priceNGN ?? 0;
      const usd = priceUSD ?? Math.round(ngn / 1450);
      const gbp = priceGBP ?? Math.round(ngn / 1850);
      if (currency === 'USD') {
        return `$${usd.toLocaleString()}`;
      }
      if (currency === 'GBP') {
        return `£${gbp.toLocaleString()}`;
      }
      return `₦${ngn.toLocaleString()}`;
    },
    [currency]
  );

  const formatCurrentPrice = useCallback(
    (amount: number): string => {
      if (currency === 'USD') {
        return `$${amount.toLocaleString()}`;
      }
      if (currency === 'GBP') {
        return `£${amount.toLocaleString()}`;
      }
      return `₦${amount.toLocaleString()}`;
    },
    [currency]
  );

  const freeShippingThreshold =
    currency === 'USD'
      ? storeSettings.freeShippingThresholdUSD
      : currency === 'GBP'
      ? storeSettings.freeShippingThresholdGBP
      : storeSettings.freeShippingThresholdNGN;

  // Cart Calculations
  const totalItems = cart.reduce((acc, item) => acc + item.quantity, 0);

  const subtotal = cart.reduce((acc, item) => {
    const base =
      currency === 'USD'
        ? item.product.priceUSD
        : currency === 'GBP'
        ? item.product.priceGBP
        : item.product.priceNGN;

    const box = item.includeCollectorBox
      ? currency === 'USD'
        ? item.boxPriceUSD
        : currency === 'GBP'
        ? item.boxPriceGBP
        : item.boxPriceNGN
      : 0;

    return acc + (base + box) * item.quantity;
  }, 0);

  // Cart Mutators
  const addToCart = useCallback(
    (
      product: Product,
      size: string,
      color: string = product.color,
      qty: number = 1,
      includeCollectorBox: boolean = true
    ) => {
      setCart((prev) => {
        const boxNgn = product.boxPackaging?.priceNGN || 15000;
        const boxUsd = product.boxPackaging?.priceUSD || 12;
        const boxGbp = product.boxPackaging?.priceGBP || 10;

        const cartItemId = `${product.id}-${size}-${color}-${includeCollectorBox ? 'box' : 'nobox'}`;
        const existingIndex = prev.findIndex((item) => item.id === cartItemId);

        if (existingIndex > -1) {
          const next = [...prev];
          next[existingIndex] = {
            ...next[existingIndex],
            quantity: next[existingIndex].quantity + qty,
          };
          return next;
        }

        return [
          ...prev,
          {
            id: cartItemId,
            product,
            selectedSize: size,
            selectedColor: color,
            quantity: qty,
            includeCollectorBox,
            boxPriceNGN: boxNgn,
            boxPriceUSD: boxUsd,
            boxPriceGBP: boxGbp,
          },
        ];
      });

      showToast(`Added ${product.name} (${size}) to shopping bag`);
      setIsCartOpen(true);
    },
    [showToast]
  );

  const updateQuantity = useCallback((id: string, qty: number) => {
    if (qty <= 0) {
      setCart((prev) => prev.filter((i) => i.id !== id));
      return;
    }
    setCart((prev) => prev.map((item) => (item.id === id ? { ...item, quantity: qty } : item)));
  }, []);

  const toggleCartItemBox = useCallback((id: string) => {
    setCart((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, includeCollectorBox: !item.includeCollectorBox } : item
      )
    );
  }, []);

  const removeFromCart = useCallback((id: string) => {
    setCart((prev) => prev.filter((item) => item.id !== id));
  }, []);

  const clearCart = useCallback(() => {
    setCart([]);
  }, []);

  const toggleWishlist = useCallback(
    (productId: string) => {
      setWishlist((prev) => {
        const isSaved = prev.includes(productId);
        if (isSaved) {
          showToast('Removed piece from your wishlist');
          return prev.filter((id) => id !== productId);
        } else {
          showToast('Saved piece to your personal wishlist');
          return [...prev, productId];
        }
      });
    },
    [showToast]
  );

  const validatePromoCode = useCallback(
    (code: string) => {
      const clean = code.trim().toUpperCase();
      const match = promoCodes.find((p) => p.code.toUpperCase() === clean && p.isActive);
      if (match) {
        return { valid: true, discountPercentage: match.discountPercentage, description: match.description };
      }
      return { valid: false, discountPercentage: 0 };
    },
    [promoCodes]
  );

  // 4. Order Creation & Verification (Priority 1 & 5: Server Authority)
  const createOrder = useCallback(
    async (orderData: Partial<Order>): Promise<Order> => {
      // The server is authoritative for order creation and totals.
      // Delegating to /api/checkout/initialize or maintaining local state.
      const orderNum = orderData.orderNumber || `3KO-${Date.now().toString().slice(-6)}-${Math.floor(100 + Math.random() * 900)}`;
      const docId = orderData.id || orderNum;

      const stagedOrder: Order = {
        id: docId,
        orderNumber: orderNum,
        items: cart,
        subtotal,
        shippingFee: orderData.shippingFee || 0,
        packagingFee: orderData.packagingFee || 0,
        discount: orderData.discount || 0,
        total: orderData.total || subtotal,
        currency,
        customer: orderData.customer || {
          fullName: 'Valued Client',
          email: 'client@3koofficial.com',
          phone: '',
          address: '',
          city: '',
          state: '',
          country: 'Nigeria',
        },
        shippingMethod: orderData.shippingMethod || 'Lagos Doorstep Courier',
        paymentMethod: orderData.paymentMethod || 'Paystack',
        paymentReference: orderData.paymentReference || '',
        paymentStatus: 'PENDING',
        orderDate: new Date().toISOString(),
        orderStatus: 'PENDING_PAYMENT',
        status: 'PENDING_PAYMENT',
        isPreOrder: cart.some((i) => i.product.isPreOrder),
        userId: currentUser?.uid || '',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      setOrders((prev) => [stagedOrder, ...prev.filter((o) => o.id !== stagedOrder.id)]);
      return stagedOrder;
    },
    [cart, subtotal, currency, currentUser]
  );

  const verifyPayment = useCallback(
    async (reference: string, orderNumber: string) => {
      // Server-side verification is authoritative. The server updates Firestore with Admin authority.
      const res = await verifyPaymentReference(reference, orderNumber);
      if (res.success && res.order) {
        const verifiedOrder = res.order;
        setOrders((prev) =>
          prev.map((o) =>
            o.orderNumber === orderNumber || o.id === orderNumber || o.id === verifiedOrder.id
              ? verifiedOrder
              : o
          )
        );
      }
      return res;
    },
    []
  );

  // 5. Auth Handlers
  const loginWithGoogle = useCallback(async () => {
    try {
      const user = await fbLoginWithGoogle();
      setCurrentUser(user);
      const isAdm = await checkUserIsAdmin(user);
      setIsAdmin(isAdm);
      showToast(`Welcome back, ${user.displayName || user.email}`);
    } catch (err: any) {
      showToast(`Login failed: ${err.message || 'Please try again'}`);
      throw err;
    }
  }, [showToast]);

  const loginWithEmail = useCallback(
    async (email: string, pass: string) => {
      try {
        const user = await fbLoginWithEmail(email, pass);
        setCurrentUser(user);
        const isAdm = await checkUserIsAdmin(user);
        setIsAdmin(isAdm);
        showToast(`Signed in as ${user.email}`);
      } catch (err: any) {
        showToast(`Authentication error: ${err.message}`);
        throw err;
      }
    },
    [showToast]
  );

  const registerAdmin = useCallback(
    async (email: string, pass: string) => {
      try {
        const user = await fbRegisterAdminUser(email, pass);
        setCurrentUser(user);
        const isAdm = await checkUserIsAdmin(user);
        setIsAdmin(isAdm);
        showToast(`Administrator credentials established for ${user.email}`);
      } catch (err: any) {
        showToast(`Registration error: ${err.message}`);
        throw err;
      }
    },
    [showToast]
  );

  const logout = useCallback(async () => {
    await logoutUser();
    setCurrentUser(null);
    setIsAdmin(false);
    showToast('Signed out of 3KO');
  }, [showToast]);

  // 6. Admin Management Actions
  const saveProduct = useCallback(
    async (prod: Product) => {
      const docId = prod.id || `prod-${Date.now()}`;
      const payload: Product = {
        ...prod,
        id: docId,
        updatedAt: new Date().toISOString(),
        createdAt: prod.createdAt || new Date().toISOString(),
      };

      try {
        await setDoc(doc(db, 'products', docId), payload);
        showToast(`Garment "${prod.name}" saved to 3KO catalog`);
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `products/${docId}`);
      }

      setProducts((prev) => {
        const idx = prev.findIndex((p) => p.id === docId);
        if (idx > -1) {
          const next = [...prev];
          next[idx] = payload;
          return next;
        }
        return [payload, ...prev];
      });
    },
    [showToast]
  );

  const deleteProduct = useCallback(
    async (id: string) => {
      try {
        await deleteDoc(doc(db, 'products', id));
        showToast('Garment deleted from catalog');
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `products/${id}`);
      }

      setProducts((prev) => prev.filter((p) => p.id !== id));
    },
    [showToast]
  );

  const archiveProduct = useCallback(
    async (id: string, isArchived: boolean = true) => {
      const updates = {
        isArchived,
        availability: isArchived ? ('archived' as const) : ('in_stock' as const),
        updatedAt: new Date().toISOString(),
      };

      try {
        await updateDoc(doc(db, 'products', id), updates);
        showToast(isArchived ? 'Garment archived from public drops' : 'Garment restored to public catalog');
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `products/${id}`);
      }

      setProducts((prev) =>
        prev.map((p) => (p.id === id ? { ...p, ...updates } : p))
      );
    },
    [showToast]
  );

  const uploadProductImageFile = useCallback(
    async (file: File, productId: string = 'product') => {
      try {
        const url = await fbUploadProductImage(file, productId);
        showToast('Image uploaded successfully to Firebase Storage');
        return url;
      } catch (err) {
        console.error('Image upload failed:', err);
        showToast('Failed to upload image. Please try again.');
        throw err;
      }
    },
    [showToast]
  );

  const deleteImageFile = useCallback(
    async (url: string) => {
      try {
        await fbDeleteProductImage(url);
        showToast('Image removed from storage');
      } catch (err) {
        console.warn('Could not delete image file:', err);
      }
    },
    [showToast]
  );

  const updateOrderStatus = useCallback(
    async (orderId: string, status: OrderWorkflowStatus, trackingNumber?: string) => {
      const updates: any = {
        orderStatus: status,
        status: status,
        updatedAt: new Date().toISOString(),
      };
      if (trackingNumber) {
        updates.trackingNumber = trackingNumber;
      }

      try {
        await updateDoc(doc(db, 'orders', orderId), updates);
        showToast(`Order status updated to ${status.toUpperCase()}`);
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `orders/${orderId}`);
      }

      setOrders((prev) =>
        prev.map((o) => (o.id === orderId ? { ...o, ...updates } : o))
      );

      // Trigger status update email
      const target = orders.find((o) => o.id === orderId);
      if (target) {
        fetch('/api/email/notify', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ type: 'status_update', order: { ...target, ...updates } }),
        }).catch(() => {});
      }
    },
    [orders, showToast]
  );

  const updateOrderPaymentStatus = useCallback(
    async (orderId: string, paymentStatus: PaymentLifecycleStatus) => {
      const updates = {
        paymentStatus,
        updatedAt: new Date().toISOString(),
      };

      try {
        await updateDoc(doc(db, 'orders', orderId), updates);
        showToast(`Payment state set to ${paymentStatus.toUpperCase()}`);
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `orders/${orderId}`);
      }

      setOrders((prev) =>
        prev.map((o) => (o.id === orderId ? { ...o, ...updates } : o))
      );
    },
    [showToast]
  );

  const saveCollection = useCallback(
    async (col: LagosCollection) => {
      try {
        await setDoc(doc(db, 'collections', col.id), col);
        showToast(`Collection "${col.name}" updated`);
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `collections/${col.id}`);
      }

      setCollections((prev) => {
        const idx = prev.findIndex((c) => c.id === col.id);
        if (idx > -1) {
          const next = [...prev];
          next[idx] = col;
          return next;
        }
        return [...prev, col];
      });
    },
    [showToast]
  );

  const saveStoreSettings = useCallback(
    async (settings: StoreSettings) => {
      try {
        await setDoc(doc(db, 'settings', 'store'), settings);
        showToast('Storefront settings updated');
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, 'settings/store');
      }

      setStoreSettings(settings);
    },
    [showToast]
  );

  // Helper for admin to seed all 3KO garments into Firestore in one click
  const seedInitialData = useCallback(async () => {
    try {
      showToast('Seeding initial 3KO catalog to Firestore...');
      for (const prod of PRODUCTS) {
        await setDoc(doc(db, 'products', prod.id), prod);
      }
      for (const col of LAGOS_COLLECTIONS) {
        await setDoc(doc(db, 'collections', col.id), col);
      }
      await setDoc(doc(db, 'settings', 'store'), DEFAULT_SETTINGS);
      showToast('3KO catalog seeded into Firestore database!');
    } catch (err) {
      console.error('Seeding error:', err);
      showToast('Failed to seed catalog. Check admin permissions.');
    }
  }, [showToast]);

  return (
    <ShopContext.Provider
      value={{
        cart,
        addToCart,
        updateQuantity,
        toggleCartItemBox,
        removeFromCart,
        clearCart,
        totalItems,
        subtotal,
        currency,
        setCurrency,
        formatPrice,
        formatCurrentPrice,
        freeShippingThreshold,
        wishlist,
        toggleWishlist,
        isCartOpen,
        setIsCartOpen,
        isSearchOpen,
        setIsSearchOpen,
        isCheckoutOpen,
        setIsCheckoutOpen,
        isSizeGuideOpen,
        setIsSizeGuideOpen,
        quickViewProduct,
        setQuickViewProduct,
        toastMessage,
        showToast,
        currentRoute,
        navigateTo,
        products,
        collections,
        promoCodes,
        validatePromoCode,
        storeSettings,
        orders,
        createOrder,
        verifyPayment,
        currentUser,
        isAdmin,
        isAuthLoading,
        loginWithGoogle,
        loginWithEmail,
        registerAdmin,
        logout,
        saveProduct,
        deleteProduct,
        archiveProduct,
        uploadProductImageFile,
        deleteImageFile,
        updateOrderStatus,
        updateOrderPaymentStatus,
        saveCollection,
        saveStoreSettings,
        seedInitialData,
        theme,
        toggleTheme,
        setTheme,
      }}
    >
      {children}
    </ShopContext.Provider>
  );
};

export const useShop = (): ShopContextType => {
  const context = useContext(ShopContext);
  if (!context) {
    throw new Error('useShop must be used within a ShopProvider');
  }
  return context;
};
