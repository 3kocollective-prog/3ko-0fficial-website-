import React from 'react';
import { Hero } from '../components/Hero';
import { StreetFormSection } from '../components/StreetFormSection';
import { LagosCollectionsSection } from '../components/LagosCollectionsSection';
import { CitySection } from '../components/CitySection';
import { PackagingSection } from '../components/PackagingSection';
import { SocialSection } from '../components/SocialSection';
import { InteractiveClothingRail } from '../components/InteractiveClothingRail';
import { ProductCard } from '../components/ProductCard';
import { useShop } from '../context/ShopContext';
import { ArrowRight, Sparkles } from 'lucide-react';

export const HomePage: React.FC = () => {
  const { navigateTo, products, theme } = useShop();
  const [activeFilter, setActiveFilter] = React.useState<'all' | 'street' | 'form'>('all');

  // Filtered drops for immediate product discovery with generous editorial breathing room (max 6 pieces)
  const filteredProducts = React.useMemo(() => {
    const active = products.filter((p) => !p.isArchived);
    if (activeFilter === 'street') {
      return active.filter((p) => p.line === 'street').slice(0, 6);
    }
    if (activeFilter === 'form') {
      return active.filter((p) => p.line === 'form').slice(0, 6);
    }
    return active.filter((p) => p.isFeatured || p.isNew).slice(0, 6);
  }, [products, activeFilter]);

  const isDark = theme === 'dark';

  return (
    <div className={`w-full flex flex-col transition-colors duration-300 ${isDark ? 'bg-[#080808]' : 'bg-[#F9F8F5]'}`}>
      {/* 01 — HERO (3KO / LAGOS IN EVERY THREAD. / Statement / SHOP STREET & SHOP FORM CTAs) */}
      <Hero />

      {/* 02 — THE TWO WORLDS (3KO STREET: Bold/urban/expressive vs 3KO FORM: Clean/refined/versatile) */}
      <StreetFormSection />

      {/* 03 — CURRENT DROPS (Restrained, spacious 6-piece product grid with generous breathing room) */}
      <section className={`w-full py-16 sm:py-24 px-6 sm:px-10 lg:px-12 border-b transition-colors ${
        isDark ? 'bg-[#0c0c0c] text-white border-white/10' : 'bg-white text-neutral-900 border-black/10'
      }`}>
        <div className="max-w-[1440px] mx-auto">
          {/* Section Header */}
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
            <div>
              <div className="flex items-center gap-2 text-xs font-mono font-bold tracking-[0.25em] uppercase text-neutral-400 mb-2">
                <Sparkles className="w-3.5 h-3.5 text-lime-400" />
                <span>FIRST EDITION WARDROBE · IN STOCK</span>
              </div>
              <h2 className="font-display font-black text-3xl sm:text-4xl lg:text-5xl uppercase tracking-tight">
                CURRENT DROPS
              </h2>
            </div>

            {/* Category Filter for uncrowded discovery */}
            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={() => setActiveFilter('all')}
                className={`px-4 py-2 text-xs font-mono font-bold tracking-wider uppercase transition-all cursor-pointer border ${
                  activeFilter === 'all'
                    ? isDark
                      ? 'bg-white text-black border-white'
                      : 'bg-black text-white border-black'
                    : isDark
                    ? 'border-white/15 text-neutral-400 hover:text-white hover:border-white/40'
                    : 'border-black/15 text-neutral-600 hover:text-black hover:border-black/40'
                }`}
              >
                All Drops ({products.length})
              </button>
              <button
                onClick={() => setActiveFilter('street')}
                className={`px-4 py-2 text-xs font-mono font-bold tracking-wider uppercase transition-all cursor-pointer border ${
                  activeFilter === 'street'
                    ? isDark
                      ? 'bg-white text-black border-white'
                      : 'bg-black text-white border-black'
                    : isDark
                    ? 'border-white/15 text-neutral-400 hover:text-white hover:border-white/40'
                    : 'border-black/15 text-neutral-600 hover:text-black hover:border-black/40'
                }`}
              >
                3KO Street
              </button>
              <button
                onClick={() => setActiveFilter('form')}
                className={`px-4 py-2 text-xs font-mono font-bold tracking-wider uppercase transition-all cursor-pointer border ${
                  activeFilter === 'form'
                    ? isDark
                      ? 'bg-white text-black border-white'
                      : 'bg-black text-white border-black'
                    : isDark
                    ? 'border-white/15 text-neutral-400 hover:text-white hover:border-white/40'
                    : 'border-black/15 text-neutral-600 hover:text-black hover:border-black/40'
                }`}
              >
                3KO Form
              </button>
            </div>
          </div>

          {/* Product Grid: Spacious 3-column layout eliminating crowding */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 sm:gap-10 lg:gap-12">
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>

          {/* Bottom Catalog Discovery Bar */}
          <div className={`mt-14 pt-8 border-t flex flex-col sm:flex-row items-center justify-between gap-4 ${
            isDark ? 'border-white/10' : 'border-black/10'
          }`}>
            <span className={`text-xs font-mono ${isDark ? 'text-neutral-400' : 'text-neutral-600'}`}>
              ✓ All First Edition pieces arrive in the signature 1200 GSM architectural collector box.
            </span>
            <button
              onClick={() => navigateTo('/shop')}
              className={`inline-flex items-center gap-2 text-xs font-mono font-bold tracking-widest uppercase hover:underline transition-all cursor-pointer ${
                isDark ? 'text-white' : 'text-black'
              }`}
            >
              <span>EXPLORE COMPLETE APPAREL CATALOG</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* 04 — 3KO 001–009 (Numbered Lagos chapters 3KO 001 .. 3KO 009) */}
      <LagosCollectionsSection />

      {/* 05 — LAGOS EDITORIAL ('More than a city. A culture. A movement. / LAGOS IN EVERY THREAD.') */}
      <CitySection />

      {/* 06 — UNBOX LAGOS / PACKAGING (Simplified presentation creating desire & curiosity) */}
      <PackagingSection />

      {/* Interactive Rail Showroom (Accessible via anchor and secondary exploration) */}
      <InteractiveClothingRail />

      {/* 07 — CAMPAIGN / COMMUNITY (Editorial / social moments) */}
      <SocialSection />
    </div>
  );
};
