import React, { useState } from 'react';
import { PRODUCTS } from '../data/products';
import { LAGOS_COLLECTIONS } from '../data/collections';
import { ProductCard } from '../components/ProductCard';
import { useShop } from '../context/ShopContext';
import {
  ArrowLeft,
  ArrowRight,
  Heart,
  Ruler,
  Truck,
  RotateCcw,
  Sparkles,
  Package,
  Share2,
  CheckCircle2,
} from 'lucide-react';

interface ProductDetailPageProps {
  slug: string;
}

export const ProductDetailPage: React.FC<ProductDetailPageProps> = ({ slug }) => {
  const {
    addToCart,
    formatPrice,
    currency,
    navigateTo,
    setIsSizeGuideOpen,
    setIsCheckoutOpen,
    wishlist,
    toggleWishlist,
    showToast,
    products,
    collections,
    theme,
  } = useShop();

  const isDark = theme === 'dark';

  const product = products.find((p) => p.slug === slug) || products[0];
  const collection = collections.find((c) => c.id === product?.collectionId);

  const [activeImageIndex, setActiveImageIndex] = useState(product?.primaryImageIndex || 0);

  // Sync activeImageIndex if product changes
  React.useEffect(() => {
    if (product?.primaryImageIndex !== undefined) {
      setActiveImageIndex(product.primaryImageIndex);
    } else {
      setActiveImageIndex(0);
    }
  }, [product?.id]);
  const [selectedSize, setSelectedSize] = useState<string>(product?.sizes?.[0] || 'M');
  const [selectedColor, setSelectedColor] = useState<string>(product?.color || 'Black');
  const [selectedColorTheme, setSelectedColorTheme] = useState<string>('');
  const [quantity, setQuantity] = useState(1);
  const [includeBox, setIncludeBox] = useState<boolean>(true); // Recommended by default

  const isSaved = product ? wishlist.includes(product.id) : false;

  // Recommendations: spacious curated 3 pieces
  const relatedProducts = products.filter((p) => p.id !== product?.id).slice(0, 3);

  const boxPrice = product.boxPackaging?.available
    ? currency === 'USD'
      ? product.boxPackaging.priceUSD
      : currency === 'GBP'
      ? product.boxPackaging.priceGBP
      : product.boxPackaging.priceNGN
    : 0;

  const basePrice =
    currency === 'USD'
      ? product.priceUSD
      : currency === 'GBP'
      ? product.priceGBP
      : product.priceNGN;

  const effectivePrice = basePrice + (includeBox ? boxPrice : 0);

  const handleColorSelect = (c: { name: string; hex: string; image?: string; theme?: string }) => {
    setSelectedColor(c.name);
    if (c.theme) setSelectedColorTheme(c.theme);
    if (c.image) {
      const idx = product.images.indexOf(c.image);
      if (idx !== -1) {
        setActiveImageIndex(idx);
      } else {
        // Prepend temporarily
        setActiveImageIndex(0);
      }
    }
  };

  const handleAddToCart = () => {
    addToCart(product, selectedSize, selectedColor, quantity, includeBox);
  };

  const handleBuyNow = () => {
    addToCart(product, selectedSize, selectedColor, quantity, includeBox);
    setIsCheckoutOpen(true);
  };

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      showToast('Product link copied to clipboard');
    }
  };

  const [isZoomOpen, setIsZoomOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'shipping' | 'returns' | 'care'>('shipping');

  return (
    <div className={`w-full pt-24 pb-20 px-4 sm:px-8 lg:px-12 transition-colors duration-300 ${
      isDark ? 'bg-[#080808] text-white' : 'bg-[#F9F8F5] text-neutral-900'
    }`}>
      <div className="max-w-[1440px] mx-auto">
        {/* Breadcrumb Navigation */}
        <div className={`flex items-center gap-2 text-xs font-mono mb-6 pb-4 border-b flex-wrap ${
          isDark ? 'text-neutral-400 border-white/10' : 'text-neutral-600 border-black/10'
        }`}>
          <button
            onClick={() => navigateTo('/shop')}
            className={`flex items-center gap-1 cursor-pointer hover:underline ${isDark ? 'hover:text-white' : 'hover:text-black'}`}
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>CATALOG</span>
          </button>
          <span>/</span>
          <button
            onClick={() => navigateTo(product.line === 'street' ? '/street' : '/form')}
            className={`uppercase cursor-pointer hover:underline ${isDark ? 'hover:text-white' : 'hover:text-black'}`}
          >
            3KO {product.line.toUpperCase()}
          </button>
          <span>/</span>
          {collection && (
            <>
              <button
                onClick={() => navigateTo(`/collections/${collection.slug}`)}
                className={`uppercase cursor-pointer hidden sm:inline hover:underline ${isDark ? 'hover:text-white' : 'hover:text-black'}`}
              >
                {collection.name}
              </button>
              <span className="hidden sm:inline">/</span>
            </>
          )}
          <span className={`uppercase font-bold truncate max-w-[220px] ${isDark ? 'text-white' : 'text-black'}`}>
            {product.name}
          </span>
        </div>

        {/* Contiguous Product Layout: Left Gallery + Right Sticky Module */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-14 items-start mb-20">
          {/* LEFT: Multi-image Gallery */}
          <div className="lg:col-span-7 flex flex-col-reverse md:flex-row gap-4">
            {/* Thumbnails */}
            <div className="flex md:flex-col gap-2.5 overflow-x-auto md:overflow-visible shrink-0 pb-2 md:pb-0 no-scrollbar">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImageIndex(idx)}
                  className={`relative w-16 h-20 md:w-20 md:h-24 bg-neutral-900 border transition-all cursor-pointer overflow-hidden shrink-0 ${
                    activeImageIndex === idx
                      ? 'border-white ring-1 ring-white'
                      : 'border-white/15 opacity-70 hover:opacity-100'
                  }`}
                >
                  <img
                    src={img}
                    alt={`${product.name} view ${idx + 1}`}
                    className="w-full h-full object-cover object-center"
                  />
                </button>
              ))}
              {/* Highlight matching packaging box thumbnail */}
              {product.boxPackaging?.available && (
                <button
                  onClick={() => setActiveImageIndex(0)}
                  className="relative w-16 h-20 md:w-20 md:h-24 bg-neutral-900 border border-amber-400/40 opacity-85 hover:opacity-100 transition-all cursor-pointer overflow-hidden shrink-0"
                  title="Designed Collector Box Packaging"
                >
                  <img
                    src={product.boxPackaging.boxImage}
                    alt="Packaging box preview"
                    className="w-full h-full object-cover object-center"
                  />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                    <span className="text-[8px] font-mono uppercase bg-amber-500 text-black px-1 font-bold">
                      BOX
                    </span>
                  </div>
                </button>
              )}
            </div>

            {/* Large Primary Image Container with Zoom trigger */}
            <div
              onClick={() => setIsZoomOpen(true)}
              className="relative flex-1 aspect-[3/4] bg-[#121212] border border-white/10 overflow-hidden group cursor-zoom-in"
            >
              <img
                src={product.images[activeImageIndex] || product.images[0]}
                alt={product.name}
                className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />

              {/* Click to zoom indicator */}
              <div className="absolute bottom-4 right-4 bg-black/70 backdrop-blur-md px-3 py-1 text-[10px] font-mono text-neutral-300 border border-white/15 opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1.5 pointer-events-none">
                <span>CLICK TO ENLARGE & INSPECT WEAVE</span>
              </div>

              {/* Wishlist and Share Floating Buttons */}
              <div
                onClick={(e) => e.stopPropagation()}
                className="absolute top-4 right-4 flex flex-col gap-2 z-10"
              >
                <button
                  onClick={() => toggleWishlist(product.id)}
                  className={`p-2.5 rounded-full backdrop-blur-md transition-colors cursor-pointer ${
                    isSaved ? 'bg-white text-red-600 shadow-md' : 'bg-black/60 text-white hover:bg-black'
                  }`}
                  aria-label={isSaved ? 'Saved to wishlist' : 'Save to wishlist'}
                >
                  <Heart className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
                </button>
                <button
                  onClick={handleShare}
                  className="p-2.5 bg-black/60 text-white hover:bg-black rounded-full backdrop-blur-md transition-colors cursor-pointer"
                  aria-label="Share product"
                >
                  <Share2 className="w-4 h-4" />
                </button>
              </div>

              {/* Location Stamp Badge */}
              <div className="absolute bottom-4 left-4 bg-black/85 backdrop-blur-xs px-3 py-1.5 border border-white/15 text-[10px] font-mono uppercase tracking-widest text-neutral-300">
                {product.collectionName}
              </div>
            </div>
          </div>

          {/* RIGHT: Editorial Purchase Module */}
          <div className="lg:col-span-5 flex flex-col justify-start lg:sticky lg:top-24 space-y-6">
            <div>
              <div className="flex items-center justify-between text-xs font-mono text-neutral-400 mb-2">
                <span className="uppercase tracking-widest">
                  {product.line} ARCHIVE {product.sku ? `· SKU: ${product.sku}` : ''}
                </span>
                {product.availability === 'out_of_stock' ? (
                  <span className="text-red-400 font-bold">● SOLD OUT</span>
                ) : product.availability === 'low_stock' ? (
                  <span className="text-amber-400 font-bold">● LOW STOCK (FEW REMAINING)</span>
                ) : product.isPreOrder ? (
                  <span className="text-cyan-400 font-bold">● PRE-ORDER ALLOCATION</span>
                ) : (
                  <span className="text-lime-400 font-bold">● IN STOCK (READY TO SHIP)</span>
                )}
              </div>

              <h1 className="font-display font-black text-2xl sm:text-3xl lg:text-4xl uppercase tracking-tight text-white mb-1">
                {product.name}
              </h1>

              <p className="text-sm text-neutral-400 font-sans">{product.subtitle}</p>

              {/* Price display with compare-at reference and bundled packaging standard */}
              <div className="mt-4 flex flex-wrap items-baseline gap-3">
                <span className="font-mono text-2xl sm:text-3xl font-bold text-white">
                  {formatPrice(
                    product.priceNGN - (!includeBox ? 5000 : 0),
                    product.priceUSD - (!includeBox ? 5 : 0),
                    product.priceGBP - (!includeBox ? 4 : 0)
                  )}
                </span>
                {product.compareAtPriceNGN && product.compareAtPriceNGN > product.priceNGN && (
                  <span className="font-mono text-base text-neutral-500 line-through">
                    {formatPrice(
                      product.compareAtPriceNGN,
                      product.compareAtPriceUSD,
                      product.compareAtPriceGBP
                    )}
                  </span>
                )}
                <span className="text-xs text-lime-400 font-mono font-bold">
                  {includeBox ? '✓ Signature Collector Box Included' : 'Eco-Mailer Option (-₦5,000)'}
                </span>
              </div>
            </div>

            {/* Pre-order Allocation Progress if enabled */}
            {product.isPreOrder && (
              <div className="p-3.5 bg-cyan-950/40 border border-cyan-500/30 text-xs font-mono space-y-1.5">
                <div className="flex items-center justify-between text-cyan-300 font-bold uppercase tracking-wider">
                  <span>Atelier Stage: {product.productionStatus || 'Pattern Drafting'}</span>
                  <span>{product.preOrderCount || 0} / {product.preOrderLimit || 50} Reserved</span>
                </div>
                <div className="w-full bg-cyan-950 h-1.5 overflow-hidden">
                  <div
                    className="bg-cyan-400 h-full transition-all"
                    style={{
                      width: `${Math.min(100, Math.round(((product.preOrderCount || 0) / (product.preOrderLimit || 50)) * 100))}%`,
                    }}
                  />
                </div>
                <p className="text-neutral-300 text-[11px]">
                  Estimated Delivery: {product.estimatedDelivery || 'Within 2–3 weeks across Nigeria & Global'}
                </p>
              </div>
            )}

            {/* Editorial Description */}
            <div className="border-t border-b border-white/10 py-4 space-y-2">
              <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed font-sans">
                {product.description}
              </p>
              {selectedColorTheme && (
                <p className="text-xs text-amber-300 font-mono tracking-wider">
                  THEME: {selectedColorTheme}
                </p>
              )}
            </div>

            {/* Color Variations */}
            {product.secondaryColors && product.secondaryColors.length > 0 && (
              <div>
                <div className="flex items-center justify-between text-xs font-mono mb-2">
                  <span className="text-neutral-400 uppercase">
                    COLORWAY: <strong className="text-white">{selectedColor}</strong>
                  </span>
                  <span className="text-neutral-500 text-[10px]">
                    {product.secondaryColors.length} AVAILABLE
                  </span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {product.secondaryColors.map((c) => (
                    <button
                      key={c.name}
                      onClick={() => handleColorSelect(c)}
                      className={`flex items-center gap-2 p-1.5 px-3 border transition-all cursor-pointer ${
                        selectedColor === c.name
                          ? 'border-white bg-white/15 text-white font-bold ring-1 ring-white'
                          : 'border-white/15 text-neutral-300 hover:text-white hover:border-white/40'
                      }`}
                    >
                      <span
                        className="w-3.5 h-3.5 rounded-full border border-white/20 shrink-0"
                        style={{ backgroundColor: c.hex }}
                      />
                      <span className="text-xs font-mono">{c.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Size Selector with Model Metrics */}
            <div>
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="font-mono text-neutral-400 uppercase">
                  SIZE: <strong className="text-white">{selectedSize}</strong>
                </span>
                <button
                  onClick={() => setIsSizeGuideOpen(true)}
                  className="text-neutral-300 hover:text-white flex items-center gap-1.5 underline cursor-pointer text-xs"
                >
                  <Ruler className="w-3.5 h-3.5" />
                  <span>Size & Fit Guide</span>
                </button>
              </div>

              <div className="grid grid-cols-5 gap-2">
                {product.sizes.map((size) => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`py-2.5 text-xs font-mono font-bold uppercase border transition-all cursor-pointer ${
                      selectedSize === size
                        ? 'border-white bg-white text-[#080808]'
                        : 'border-white/15 text-neutral-300 hover:border-white/40'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>

              {/* Model Height & Fit Metric */}
              <div className="mt-2.5 flex items-center justify-between text-[11px] font-mono text-neutral-400 bg-neutral-900/60 p-2 border border-white/5">
                <span>Model: 6'1" (185cm) · 78kg wearing size L</span>
                <span className="text-lime-400 font-bold uppercase">Only 4 left in {selectedSize}</span>
              </div>
            </div>

            {/* Bundled Signature Collector Box Packaging */}
            {product.boxPackaging?.available && (
              <div className="p-4 bg-gradient-to-br from-[#161616] to-[#101010] border border-amber-500/40 relative overflow-hidden shadow-xl">
                <div className="flex items-start gap-3.5">
                  <img
                    src={product.boxPackaging.boxImage}
                    alt={product.boxPackaging.boxName}
                    className="w-16 h-16 sm:w-20 sm:h-20 object-cover border border-white/20 shrink-0 bg-neutral-900"
                  />
                  <div className="flex-1">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <span className="text-[10px] font-mono uppercase tracking-widest text-amber-300 font-bold flex items-center gap-1">
                        <Sparkles className="w-3 h-3 text-amber-400" />
                        SIGNATURE COLLECTOR BOX
                      </span>
                      <span className="text-[10px] font-mono text-lime-400 font-bold uppercase">
                        COMPLIMENTARY
                      </span>
                    </div>

                    <h4 className="font-display font-bold text-xs uppercase text-white mb-0.5">
                      {product.boxPackaging.boxName}
                    </h4>

                    <p className="text-[11px] text-neutral-300 leading-relaxed font-sans mb-2.5">
                      Rigid 1200 GSM collector box with architectural bridge elevation, serialized registry certificate, and coordinates seal ({product.boxPackaging.coordinates}).
                    </p>

                    <label className="flex items-center gap-2 cursor-pointer text-xs font-mono text-neutral-300 hover:text-white">
                      <input
                        type="checkbox"
                        checked={includeBox}
                        onChange={(e) => setIncludeBox(e.target.checked)}
                        className="w-4 h-4 accent-amber-400 cursor-pointer"
                      />
                      <span>{includeBox ? '✓ Include Signature Box (Recommended)' : 'Eco-friendly minimal packaging (-₦5,000)'}</span>
                    </label>
                  </div>
                </div>
              </div>
            )}

            {/* Quantity Selector */}
            <div className="flex items-center gap-4">
              <span className="text-xs font-mono uppercase text-neutral-400">QUANTITY:</span>
              <div className="flex items-center border border-white/20 bg-[#141414]">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-3 py-1.5 text-neutral-400 hover:text-white text-sm cursor-pointer"
                  aria-label="Decrease quantity"
                >
                  -
                </button>
                <span className="px-4 text-xs font-mono font-bold">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="px-3 py-1.5 text-neutral-400 hover:text-white text-sm cursor-pointer"
                  aria-label="Increase quantity"
                >
                  +
                </button>
              </div>
            </div>

            {/* Action Buttons: ADD TO CART & BUY NOW */}
            <div className="space-y-3 pt-2">
              <button
                onClick={handleAddToCart}
                className="w-full bg-white text-[#080808] font-bold py-4 text-xs uppercase tracking-widest hover:bg-neutral-200 transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-xl"
              >
                <span>ADD TO SHOPPING BAG</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={handleBuyNow}
                className="w-full border border-white/30 bg-[#161616] text-white font-bold py-3.5 text-xs uppercase tracking-widest hover:bg-white/10 hover:border-white transition-colors cursor-pointer"
              >
                BUY IT NOW — DIRECT CHECKOUT
              </button>
            </div>

            {/* Interactive Shipping SLAs & Guarantee Tabs */}
            <div className="border-t border-white/10 pt-4">
              <div className="flex items-center gap-4 border-b border-white/10 pb-2 mb-3 text-xs font-mono uppercase">
                <button
                  onClick={() => setActiveTab('shipping')}
                  className={`pb-1 transition-colors cursor-pointer ${
                    activeTab === 'shipping' ? 'text-white border-b-2 border-white font-bold' : 'text-neutral-400'
                  }`}
                >
                  Delivery Lead Times
                </button>
                <button
                  onClick={() => setActiveTab('returns')}
                  className={`pb-1 transition-colors cursor-pointer ${
                    activeTab === 'returns' ? 'text-white border-b-2 border-white font-bold' : 'text-neutral-400'
                  }`}
                >
                  14-Day Exchanges
                </button>
                <button
                  onClick={() => setActiveTab('care')}
                  className={`pb-1 transition-colors cursor-pointer ${
                    activeTab === 'care' ? 'text-white border-b-2 border-white font-bold' : 'text-neutral-400'
                  }`}
                >
                  Care & Wash
                </button>
              </div>

              {activeTab === 'shipping' && (
                <div className="space-y-2 text-xs font-sans text-neutral-300 leading-relaxed">
                  <div className="flex items-start gap-2">
                    <Truck className="w-4 h-4 text-lime-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-white block font-mono text-[11px]">LAGOS METRO (ISLAND & MAINLAND):</strong>
                      <span>Same-Day or 24–48 Hours express delivery. Complimentary on orders over ₦100,000.</span>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <Package className="w-4 h-4 text-lime-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-white block font-mono text-[11px]">NATIONWIDE EXPRESS (NIGERIA):</strong>
                      <span>2–4 business days via verified ground courier. Tracking number sent via SMS and Email.</span>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-lime-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-white block font-mono text-[11px]">INTERNATIONAL (UK, US, CANADA, EU):</strong>
                      <span>3–5 business days via DHL Express Worldwide. Duties and customs clearly calculated.</span>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'returns' && (
                <div className="text-xs font-sans text-neutral-300 leading-relaxed space-y-1.5">
                  <p>
                    We offer a <strong>14-day hassle-free exchange</strong> on all unworn garments with original security tags, coordinates seal, and collector box intact.
                  </p>
                  <p className="text-neutral-400 text-[11px]">
                    To initiate a size exchange or credit, reach out via our WhatsApp VIP concierge (+234 1 234 3KO) or concierge@3ko-lagos.com.
                  </p>
                </div>
              )}

              {activeTab === 'care' && (
                <div className="text-xs font-mono text-neutral-300 space-y-1">
                  {product.careInstructions.map((inst, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <span className="text-lime-400">●</span>
                      <span>{inst}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Full-Screen Image Lightbox Modal for High-Res Inspection */}
        {isZoomOpen && (
          <div
            onClick={() => setIsZoomOpen(false)}
            className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center p-4 cursor-zoom-out animate-in fade-in"
          >
            <div className="relative max-w-4xl max-h-[90vh] flex flex-col items-center">
              <img
                src={product.images[activeImageIndex] || product.images[0]}
                alt={product.name}
                className="max-w-full max-h-[85vh] object-contain shadow-2xl border border-white/10"
              />
              <div className="mt-3 text-xs font-mono tracking-widest uppercase text-neutral-300 text-center">
                {product.name} · TEXTURE & PUFF PRINT INSPECTION (CLICK OUTSIDE TO CLOSE)
              </div>
            </div>
          </div>
        )}

        {/* Specifications Section */}
        <div className="border-t border-white/10 pt-16 mb-20">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="space-y-3">
              <span className="text-xs uppercase tracking-widest font-mono text-neutral-400 block">
                FABRIC & CRAFT
              </span>
              <h3 className="font-display font-bold text-lg uppercase text-white">
                Material Architecture
              </h3>
              <ul className="space-y-2 text-xs text-neutral-300 font-sans leading-relaxed">
                {product.fabricDetails.map((detail, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-white mt-0.5">•</span>
                    <span>{detail}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="space-y-3">
              <span className="text-xs uppercase tracking-widest font-mono text-neutral-400 block">
                GARMENT CARE
              </span>
              <h3 className="font-display font-bold text-lg uppercase text-white">
                Maintenance Guide
              </h3>
              <ul className="space-y-2 text-xs text-neutral-300 font-sans leading-relaxed">
                {product.careInstructions.map((care, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-white mt-0.5">•</span>
                    <span>{care}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="space-y-3 bg-[#121212] p-6 border border-white/10">
              <div className="flex items-center gap-2 text-xs font-mono uppercase text-amber-300">
                <Package className="w-4 h-4" />
                <span>COLLECTOR BOX SYSTEM</span>
              </div>
              <h3 className="font-display font-bold text-lg uppercase text-white">
                Unbox {collection ? collection.name : 'Lagos'}
              </h3>
              <p className="text-xs text-neutral-300 font-sans leading-relaxed">
                {product.packagingNote}
              </p>
              {product.boxPackaging?.available && (
                <div className="pt-2 text-xs font-mono text-neutral-400">
                  <span>GPS Registry: {product.boxPackaging.coordinates}</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Related Drops: Spacious 3-column layout */}
        <div className={`border-t pt-16 ${isDark ? 'border-white/10' : 'border-black/10'}`}>
          <div className="flex items-center justify-between mb-8">
            <h3 className={`font-display font-black text-2xl uppercase tracking-tight ${
              isDark ? 'text-white' : 'text-neutral-900'
            }`}>
              COMPLETE THE LAGOS LOOK
            </h3>
            <button
              onClick={() => navigateTo('/shop')}
              className={`text-xs font-mono uppercase flex items-center gap-1 cursor-pointer hover:underline ${
                isDark ? 'text-neutral-400 hover:text-white' : 'text-neutral-600 hover:text-black'
              }`}
            >
              <span>View All Items</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 sm:gap-10">
            {relatedProducts.map((rel) => (
              <ProductCard key={rel.id} product={rel} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
