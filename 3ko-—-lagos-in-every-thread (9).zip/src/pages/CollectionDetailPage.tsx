import React from 'react';
import { LAGOS_COLLECTIONS } from '../data/collections';
import { PRODUCTS } from '../data/products';
import { ProductCard } from '../components/ProductCard';
import { useShop } from '../context/ShopContext';
import { ArrowLeft, ArrowRight, MapPin, Compass, Package, ChevronRight } from 'lucide-react';

interface CollectionDetailPageProps {
  slug: string;
}

export const CollectionDetailPage: React.FC<CollectionDetailPageProps> = ({ slug }) => {
  const { navigateTo, theme } = useShop();
  const isDark = theme === 'dark';

  const collection = LAGOS_COLLECTIONS.find((c) => c.slug === slug) || LAGOS_COLLECTIONS[4]; // default Tarkwa Bay
  const collectionProducts = PRODUCTS.filter((p) => p.collectionId === collection.id);

  // Find adjacent collections
  const currentIndex = LAGOS_COLLECTIONS.findIndex((c) => c.id === collection.id);
  const prevCol = LAGOS_COLLECTIONS[(currentIndex - 1 + LAGOS_COLLECTIONS.length) % LAGOS_COLLECTIONS.length];
  const nextCol = LAGOS_COLLECTIONS[(currentIndex + 1) % LAGOS_COLLECTIONS.length];

  return (
    <div className={`w-full pt-20 pb-20 transition-colors duration-300 ${
      isDark ? 'bg-[#080808] text-white' : 'bg-[#F9F8F5] text-neutral-900'
    }`}>
      {/* Editorial Hero Header for the Location */}
      <section className="relative w-full min-h-[480px] lg:min-h-[560px] flex items-end pb-12 sm:pb-16 px-6 sm:px-10 lg:px-12 bg-neutral-950 overflow-hidden border-b border-white/10">
        <div className="absolute inset-0 z-0">
          <img
            src={collection.image}
            alt={collection.fullName}
            className="w-full h-full object-cover object-center filter brightness-[0.75]"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#080808] via-[#080808]/60 to-transparent" />
        </div>

        <div className="relative z-10 max-w-[1440px] mx-auto w-full">
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 text-xs font-mono text-neutral-400 mb-4">
            <button
              onClick={() => navigateTo('/collections')}
              className="hover:text-white flex items-center gap-1 cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>COLLECTIONS</span>
            </button>
            <span>/</span>
            <span className="text-white uppercase">{collection.numberStr}</span>
          </div>

          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
            <div className="max-w-2xl">
              <div className="flex items-center gap-3 mb-2">
                <span
                  className="px-2.5 py-0.5 text-xs font-bold uppercase tracking-wider text-black font-mono"
                  style={{ backgroundColor: collection.colorHex === '#FFFFFF' ? '#E5E5E5' : collection.colorHex, color: collection.colorHex === '#FFFFFF' || collection.colorHex === '#38BDF8' ? '#000' : '#FFF' }}
                >
                  COLLECTION {collection.numberStr}
                </span>
                <span className="text-xs uppercase font-mono text-neutral-300 tracking-wider">
                  COLOR IDENTITY: {collection.colorName}
                </span>
              </div>

              <h1 className="font-display font-black text-4xl sm:text-6xl lg:text-7xl uppercase tracking-tight text-white mb-4">
                {collection.name}
              </h1>

              <div className="flex flex-wrap items-center gap-4 text-xs font-mono text-neutral-300">
                <div className="flex items-center gap-1.5">
                  <Compass className="w-4 h-4 text-neutral-400" />
                  <span>{collection.coordinates}</span>
                </div>
                <span>·</span>
                <div className="flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-neutral-400" />
                  <span>{collection.landmark}</span>
                </div>
              </div>
            </div>

            {/* Personality Tag */}
            <div className="bg-black/60 backdrop-blur-md border border-white/15 p-4 max-w-xs">
              <span className="text-[10px] uppercase tracking-widest text-neutral-400 font-mono block mb-1">
                LOCATION PERSONALITY
              </span>
              <p className="font-display font-bold text-sm uppercase tracking-wide text-white">
                {collection.personality}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Narrative & Lore Section */}
      <section className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-12 py-16 border-b border-white/10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          <div className="lg:col-span-7 space-y-4">
            <span className="text-xs uppercase tracking-[0.25em] text-neutral-400 font-semibold block">
              LOCATION CHRONICLE
            </span>
            <h2 className="font-display font-extrabold text-2xl sm:text-3xl uppercase tracking-tight text-white">
              The Story of {collection.name}
            </h2>
            <p className="text-neutral-300 text-base leading-relaxed font-normal">
              {collection.fullStory}
            </p>
            <p className="text-neutral-400 text-sm leading-relaxed font-normal pt-2">
              Every detail in {collection.fullName} has been sampled directly from this environment: from the weave density formulated for the coastal microclimate, to color dyes matched to local architectural masonry and natural harbor light.
            </p>
          </div>

          <div className="lg:col-span-5 bg-[#121212] border border-white/10 p-6 sm:p-8 space-y-6">
            <div>
              <span className="text-xs uppercase tracking-widest text-neutral-400 font-mono block mb-2">
                PALETTE FORMULATION
              </span>
              <p className="text-sm text-neutral-200 font-sans leading-relaxed">
                {collection.paletteDescription}
              </p>
              <div className="flex items-center gap-3 mt-4">
                <div
                  className="w-8 h-8 rounded-full border border-white/20 shadow-md"
                  style={{ backgroundColor: collection.colorHex }}
                />
                <div className="text-xs font-mono">
                  <div className="font-bold text-white uppercase">{collection.colorName}</div>
                  <div className="text-neutral-400">{collection.colorHex}</div>
                </div>
              </div>
            </div>

            <div className="pt-6 border-t border-white/10">
              <div className="flex items-center gap-2 text-xs uppercase tracking-wider font-bold text-white mb-2">
                <Package className="w-4 h-4" />
                <span>PACKAGING STANDARD</span>
              </div>
              <p className="text-xs text-neutral-400 font-sans leading-relaxed">
                Shipped in the serialized {collection.colorName} magnetic collector box stamped with {collection.coordinates}.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Collection Products Grid */}
      <section className={`max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-12 py-16 border-b ${
        isDark ? 'border-white/10' : 'border-black/10'
      }`}>
        <div className="flex items-center justify-between mb-8">
          <div>
            <span className={`text-xs uppercase tracking-widest font-mono block mb-1 ${
              isDark ? 'text-neutral-400' : 'text-neutral-500'
            }`}>
              THE APPAREL
            </span>
            <h3 className={`font-display font-black text-2xl sm:text-3xl uppercase tracking-tight ${
              isDark ? 'text-white' : 'text-neutral-900'
            }`}>
              GARMENTS FROM {collection.name} ({collectionProducts.length})
            </h3>
          </div>

          <button
            onClick={() => navigateTo('/shop')}
            className={`text-xs uppercase font-mono flex items-center gap-1 cursor-pointer hover:underline ${
              isDark ? 'text-neutral-400 hover:text-white' : 'text-neutral-600 hover:text-black'
            }`}
          >
            <span>View All Shop</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {collectionProducts.length === 0 ? (
          <div className={`p-12 text-center border ${
            isDark ? 'bg-[#101010] border-white/10' : 'bg-white border-black/10'
          }`}>
            <p className={`text-sm mb-4 ${isDark ? 'text-neutral-400' : 'text-neutral-600'}`}>
              First drop pieces for {collection.name} are currently in limited studio assembly.
            </p>
            <button
              onClick={() => navigateTo('/shop')}
              className={`px-6 py-2.5 text-xs font-bold uppercase tracking-widest transition-colors cursor-pointer ${
                isDark ? 'bg-white text-black hover:bg-neutral-200' : 'bg-black text-white hover:bg-neutral-800'
              }`}
            >
              Browse Available Drops
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 sm:gap-10">
            {collectionProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </section>

      {/* Navigation to Previous & Next Lagos Collections */}
      <section className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-12 pt-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <button
            onClick={() => navigateTo(`/collections/${prevCol.slug}`)}
            className={`p-6 border text-left transition-colors flex items-center justify-between group cursor-pointer shadow-sm ${
              isDark
                ? 'bg-[#111111] border-white/10 hover:border-white/30 text-white'
                : 'bg-white border-black/10 hover:border-black/30 text-neutral-900'
            }`}
          >
            <div>
              <span className={`text-[10px] font-mono uppercase tracking-widest block mb-1 ${
                isDark ? 'text-neutral-500' : 'text-neutral-500'
              }`}>
                PREVIOUS COLLECTION
              </span>
              <h4 className={`font-display font-bold text-lg uppercase transition-colors ${
                isDark ? 'text-white group-hover:text-neutral-200' : 'text-neutral-900 group-hover:text-neutral-700'
              }`}>
                {prevCol.numberStr} — {prevCol.name}
              </h4>
            </div>
            <ArrowLeft className="w-5 h-5 text-neutral-500 group-hover:-translate-x-1 group-hover:text-white transition-all" />
          </button>

          <button
            onClick={() => navigateTo(`/collections/${nextCol.slug}`)}
            className="p-6 bg-[#111111] border border-white/10 hover:border-white/30 text-right transition-colors flex items-center justify-between group cursor-pointer"
          >
            <ArrowRight className="w-5 h-5 text-neutral-500 group-hover:translate-x-1 group-hover:text-white transition-all" />
            <div>
              <span className="text-[10px] font-mono uppercase tracking-widest text-neutral-500 block mb-1">
                NEXT COLLECTION
              </span>
              <h4 className="font-display font-bold text-lg uppercase text-white group-hover:text-neutral-200">
                {nextCol.numberStr} — {nextCol.name}
              </h4>
            </div>
          </button>
        </div>
      </section>
    </div>
  );
};
