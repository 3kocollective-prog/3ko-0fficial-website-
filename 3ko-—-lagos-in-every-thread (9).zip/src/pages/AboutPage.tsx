import React from 'react';
import { useShop } from '../context/ShopContext';
import { ArrowRight, Compass, ShieldCheck, Sparkles, Feather } from 'lucide-react';

export const AboutPage: React.FC = () => {
  const { navigateTo, theme } = useShop();
  const isDark = theme === 'dark';

  return (
    <div className={`w-full pt-24 pb-20 px-6 sm:px-10 lg:px-12 transition-colors duration-300 ${
      isDark ? 'bg-[#080808] text-white' : 'bg-[#F9F8F5] text-neutral-900'
    }`}>
      <div className="max-w-[1440px] mx-auto">
        {/* Hero Banner */}
        <div className="max-w-3xl mb-16">
          <span className={`text-xs uppercase tracking-[0.25em] font-semibold block mb-2 font-mono ${
            isDark ? 'text-neutral-400' : 'text-neutral-500'
          }`}>
            OUR MANIFESTO
          </span>
          <h1 className={`font-display font-black text-4xl sm:text-6xl lg:text-7xl uppercase tracking-tight mb-6 ${
            isDark ? 'text-white' : 'text-neutral-900'
          }`}>
            LAGOS IN EVERY THREAD.
          </h1>
          <p className={`text-base sm:text-lg leading-relaxed font-normal ${
            isDark ? 'text-neutral-300' : 'text-neutral-700'
          }`}>
            3KO was born in the kinetic velocity of Lagos — a city of 20 million dreamers, builders, and iconoclasts. We create contemporary clothing that fuses Nigerian cultural resonance with minimalist precision, competing on the international stage without diluting our identity.
          </p>
        </div>

        {/* Cinematic Imagery Split */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-20">
          <div className="relative aspect-[4/3] bg-neutral-900 border border-white/10 overflow-hidden">
            <img
              src="/images/brand/hero_bg.jpg"
              alt="3KO creative direction on Lekki Ikoyi bridge"
              className="w-full h-full object-cover filter brightness-90"
            />
            <div className="absolute bottom-4 left-4 text-xs font-mono bg-black/60 px-3 py-1 text-white border border-white/10">
              LEKKI-IKOYI BRIDGE · WATERFRONT STUDIO
            </div>
          </div>
          <div className="relative aspect-[4/3] bg-neutral-900 border border-white/10 overflow-hidden">
            <img
              src="/images/brand/city_lagos.jpg"
              alt="Lagos skyline panorama"
              className="w-full h-full object-cover filter grayscale contrast-110"
            />
            <div className="absolute bottom-4 left-4 text-xs font-mono bg-black/60 px-3 py-1 text-white border border-white/10">
              MARINA WATERWAY · MERCHANT PULSE
            </div>
          </div>
        </div>

        {/* The Dual Pillars: Street and Form */}
        <div className={`py-16 border-t border-b mb-20 ${
          isDark ? 'border-white/10' : 'border-black/10'
        }`}>
          <div className="text-center max-w-2xl mx-auto mb-14">
            <span className={`text-xs uppercase tracking-widest font-mono block mb-2 ${
              isDark ? 'text-neutral-400' : 'text-neutral-500'
            }`}>
              DESIGN PHILOSOPHY
            </span>
            <h2 className={`font-display font-black text-3xl sm:text-5xl uppercase tracking-tight ${
              isDark ? 'text-white' : 'text-neutral-900'
            }`}>
              STREET & FORM
            </h2>
            <p className={`text-xs sm:text-sm mt-3 font-sans ${
              isDark ? 'text-neutral-300' : 'text-neutral-600'
            }`}>
              Contemporary Lagos life demands two complementary expressions of self.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className={`p-8 border flex flex-col justify-between ${
              isDark ? 'bg-[#111111] border-white/10' : 'bg-white border-black/10 shadow-sm'
            }`}>
              <div>
                <span className={`text-xs font-mono uppercase tracking-widest block mb-2 ${
                  isDark ? 'text-neutral-400' : 'text-neutral-500'
                }`}>
                  PILLAR 01
                </span>
                <h3 className={`font-display font-extrabold text-2xl uppercase tracking-tight mb-3 ${
                  isDark ? 'text-white' : 'text-neutral-900'
                }`}>
                  3KO STREET
                </h3>
                <p className={`text-sm leading-relaxed font-sans mb-6 ${
                  isDark ? 'text-neutral-300' : 'text-neutral-700'
                }`}>
                  Bold. Urban. Unapologetic. Grounded in heavyweight ringspun cottons, tactile puff prints, and oversized silhouettes that honor the raw electricity of Lagos expressways and neighborhood creativity.
                </p>
              </div>
              <button
                onClick={() => navigateTo('/street')}
                className={`inline-flex items-center gap-2 text-xs font-bold tracking-widest uppercase border-b pb-1 w-fit cursor-pointer ${
                  isDark ? 'text-white border-white hover:text-neutral-300' : 'text-black border-black hover:text-neutral-700'
                }`}
              >
                <span>SHOP 3KO STREET</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className={`p-8 border flex flex-col justify-between ${
              isDark ? 'bg-[#111111] border-white/10' : 'bg-white border-black/10 shadow-sm'
            }`}>
              <div>
                <span className={`text-xs font-mono uppercase tracking-widest block mb-2 ${
                  isDark ? 'text-neutral-400' : 'text-neutral-500'
                }`}>
                  PILLAR 02
                </span>
                <h3 className={`font-display font-extrabold text-2xl uppercase tracking-tight mb-3 ${
                  isDark ? 'text-white' : 'text-neutral-900'
                }`}>
                  3KO FORM
                </h3>
                <p className={`text-sm leading-relaxed font-sans mb-6 ${
                  isDark ? 'text-neutral-300' : 'text-neutral-700'
                }`}>
                  Clean. Refined. Versatile. Smart-casual tailored garments, breathable long-staple piques, and linen trousers designed for tropical boardrooms, diplomatic galleries, and executive evenings.
                </p>
              </div>
              <button
                onClick={() => navigateTo('/form')}
                className={`inline-flex items-center gap-2 text-xs font-bold tracking-widest uppercase border-b pb-1 w-fit cursor-pointer ${
                  isDark ? 'text-white border-white hover:text-neutral-300' : 'text-black border-black hover:text-neutral-700'
                }`}
              >
                <span>SHOP 3KO FORM</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Sustainability & Production Commitment */}
        <div id="sustainability" className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
          <div className={`p-6 border space-y-3 ${
            isDark ? 'bg-[#121212] border-white/10' : 'bg-white border-black/10 shadow-sm'
          }`}>
            <Feather className={`w-5 h-5 ${isDark ? 'text-white' : 'text-black'}`} />
            <h4 className={`font-display font-bold uppercase text-base ${isDark ? 'text-white' : 'text-neutral-900'}`}>
              Organic Long-Staple Fibers
            </h4>
            <p className={`text-xs leading-relaxed font-sans ${isDark ? 'text-neutral-400' : 'text-neutral-600'}`}>
              We exclusively use West African long-staple combed cotton and breathable flax linen blends, avoiding non-biodegradable polyester synthetics.
            </p>
          </div>

          <div className={`p-6 border space-y-3 ${
            isDark ? 'bg-[#121212] border-white/10' : 'bg-white border-black/10 shadow-sm'
          }`}>
            <ShieldCheck className={`w-5 h-5 ${isDark ? 'text-white' : 'text-black'}`} />
            <h4 className={`font-display font-bold uppercase text-base ${isDark ? 'text-white' : 'text-neutral-900'}`}>
              Lagos-Based Artisan Atelier
            </h4>
            <p className={`text-xs leading-relaxed font-sans ${isDark ? 'text-neutral-400' : 'text-neutral-600'}`}>
              Pattern cutting, sampling, and small-batch assembly take place in our Lagos workshops, guaranteeing living wages and skill mastery for local tailors.
            </p>
          </div>

          <div className={`p-6 border space-y-3 ${
            isDark ? 'bg-[#121212] border-white/10' : 'bg-white border-black/10 shadow-sm'
          }`}>
            <Sparkles className={`w-5 h-5 ${isDark ? 'text-white' : 'text-black'}`} />
            <h4 className={`font-display font-bold uppercase text-base ${isDark ? 'text-white' : 'text-neutral-900'}`}>
              Archival Collectible Packaging
            </h4>
            <p className={`text-xs leading-relaxed font-sans ${isDark ? 'text-neutral-400' : 'text-neutral-600'}`}>
              Our packaging is designed never to be thrown away. Every numbered rigid box becomes an art object in your living room or closet.
            </p>
          </div>
        </div>

        {/* Call to Action */}
        <div className={`p-10 sm:p-14 border flex flex-col md:flex-row items-center justify-between gap-6 ${
          isDark ? 'bg-white text-[#080808]' : 'bg-black text-white'
        }`}>
          <div>
            <h3 className="font-display font-black text-2xl sm:text-4xl uppercase tracking-tight">
              CARRY LAGOS WITH YOU.
            </h3>
            <p className={`text-xs sm:text-sm mt-1 ${isDark ? 'text-neutral-700' : 'text-neutral-300'}`}>
              Explore the 9 Lagos collections and wearable contemporary stories.
            </p>
          </div>
          <button
            onClick={() => navigateTo('/collections')}
            className={`font-bold px-8 py-3.5 text-xs uppercase tracking-widest transition-colors flex items-center gap-2 cursor-pointer shrink-0 ${
              isDark ? 'bg-[#080808] text-white hover:bg-neutral-800' : 'bg-white text-black hover:bg-neutral-200'
            }`}
          >
            <span>DISCOVER THE 9 COLLECTIONS</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
