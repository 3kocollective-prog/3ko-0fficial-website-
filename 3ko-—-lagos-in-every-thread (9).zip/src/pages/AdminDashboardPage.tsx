import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import {
  ShieldCheck,
  Package,
  ShoppingBag,
  TrendingUp,
  Search,
  Plus,
  Trash2,
  Edit2,
  ExternalLink,
  CheckCircle,
  Clock,
  Truck,
  RotateCcw,
  Sparkles,
  Lock,
  LogOut,
  ArrowLeft,
  ArrowRight,
  X,
  AlertCircle,
  Database,
  DollarSign,
  Layers,
  MapPin,
  Mail,
  Info,
  HelpCircle,
  Upload,
  Star,
  Archive,
  Eye,
  Tag,
  Check,
} from 'lucide-react';
import {
  Product,
  Order,
  LagosCollection,
  OrderWorkflowStatus,
  PaymentLifecycleStatus,
  normalizePaymentStatus,
  normalizeOrderStatus,
} from '../types';
import { formatAuthErrorMessage, AuthDiagnostic, OWNER_EMAIL } from '../lib/firebase';

export const AdminDashboardPage: React.FC = () => {
  const {
    currentUser,
    isAdmin,
    isAuthLoading,
    loginWithGoogle,
    loginWithEmail,
    registerAdmin,
    logout,
    products,
    orders,
    collections,
    storeSettings,
    saveProduct,
    deleteProduct,
    archiveProduct,
    uploadProductImageFile,
    deleteImageFile,
    updateOrderStatus,
    updateOrderPaymentStatus,
    saveCollection,
    saveStoreSettings,
    seedInitialData,
    navigateTo,
    formatPrice,
    theme,
  } = useShop();

  const isDark = theme === 'dark';

  // Navigation tab inside admin
  const [activeTab, setActiveTab] = useState<'overview' | 'orders' | 'products' | 'collections' | 'settings'>('overview');

  // Login form state
  const [authMode, setAuthMode] = useState<'signin' | 'register'>('signin');
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [diagnostic, setDiagnostic] = useState<AuthDiagnostic | null>(null);
  const [isSubmittingAuth, setIsSubmittingAuth] = useState(false);

  // Orders management filters & modal
  const [orderSearch, setOrderSearch] = useState('');
  const [orderStatusFilter, setOrderStatusFilter] = useState<string>('all');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [trackingNumberInput, setTrackingNumberInput] = useState('');

  // Products management filters & modal
  const [productSearch, setProductSearch] = useState('');
  const [productLineFilter, setProductLineFilter] = useState<'all' | 'street' | 'form' | 'edition'>('all');
  const [productAvailabilityFilter, setProductAvailabilityFilter] = useState<'all' | 'in_stock' | 'low_stock' | 'preorder_only' | 'archived'>('all');
  const [productCollectionFilter, setProductCollectionFilter] = useState<string>('all');
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isNewProductModalOpen, setIsNewProductModalOpen] = useState(false);
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);

  // Form state for product editing
  const [productForm, setProductForm] = useState<Partial<Product>>({});
  const [activeFormTab, setActiveFormTab] = useState<'general' | 'pricing' | 'inventory' | 'preorder' | 'images' | 'details'>('general');
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const [imageUploadError, setImageUploadError] = useState<string | null>(null);
  const [manualImageUrl, setManualImageUrl] = useState('');
  const [newCustomSize, setNewCustomSize] = useState('');

  // Collections editing
  const [editingCollection, setEditingCollection] = useState<LagosCollection | null>(null);

  // ========================================================
  // 1. AUTHENTICATION & SECURITY GUARDS
  // ========================================================

  if (isAuthLoading) {
    return (
      <div className={`min-h-screen flex items-center justify-center ${isDark ? 'bg-[#080808] text-white' : 'bg-[#F9F8F5] text-black'}`}>
        <div className="text-center space-y-4">
          <div className="w-12 h-12 border-2 border-t-white border-white/20 rounded-full animate-spin mx-auto" />
          <p className="font-mono text-xs uppercase tracking-[0.25em] text-neutral-400">
            AUTHENTICATING 3KO CONCIERGE...
          </p>
        </div>
      </div>
    );
  }

  // If user is not authenticated, show private admin login gateway
  if (!currentUser) {
    return (
      <div className={`min-h-screen flex items-center justify-center px-4 py-20 ${isDark ? 'bg-[#080808] text-white' : 'bg-[#F9F8F5] text-black'}`}>
        <div className={`max-w-md w-full border p-8 sm:p-10 shadow-2xl relative ${isDark ? 'bg-[#101010] border-white/15' : 'bg-white border-black/15'}`}>
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-full border border-amber-500/30 bg-amber-500/10 text-amber-400 mb-4">
              <Lock className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-mono uppercase tracking-[0.25em] text-amber-500 dark:text-amber-400 block mb-1 font-bold">
              SECURITY ACCESS GATEWAY
            </span>
            <h1 className="font-display font-black text-2xl uppercase tracking-tight">
              3KO BRAND ADMIN
            </h1>
            <p className="text-xs text-neutral-400 mt-2 font-sans">
              Restricted portal for 3KO owner and executive operations. Sign in with authorized Google or administrative credentials.
            </p>
          </div>

          {/* Diagnostic or Error Box */}
          {diagnostic && (
            <div className="mb-6 p-4 bg-red-950/40 border border-red-500/50 text-xs font-mono space-y-1.5 text-left">
              <div className="flex items-center gap-2 text-red-300 font-bold uppercase tracking-wider text-[11px]">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                <span>{diagnostic.title}</span>
              </div>
              <p className="text-neutral-300 text-[11px] leading-relaxed">
                {diagnostic.message}
              </p>
              {diagnostic.actionHint && (
                <div className="p-2.5 bg-black/60 border border-amber-500/30 text-amber-300 text-[10px] space-y-1 mt-2">
                  <span className="font-bold uppercase tracking-wider block text-amber-400">Resolution Step:</span>
                  <p>{diagnostic.actionHint}</p>
                </div>
              )}
            </div>
          )}

          {/* Primary One-Click Google Admin Sign-In */}
          <button
            onClick={async () => {
              setDiagnostic(null);
              setIsSubmittingAuth(true);
              try {
                await loginWithGoogle();
              } catch (err: any) {
                setDiagnostic(formatAuthErrorMessage(err));
              } finally {
                setIsSubmittingAuth(false);
              }
            }}
            disabled={isSubmittingAuth}
            className="w-full py-3.5 px-4 bg-white text-black hover:bg-neutral-200 transition-colors font-bold text-xs uppercase tracking-widest flex items-center justify-center gap-3 cursor-pointer shadow-md mb-6 disabled:opacity-50"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
              />
            </svg>
            <span>SIGN IN WITH GOOGLE ADMIN</span>
          </button>

          {/* Mode Switcher */}
          <div className="flex border border-white/10 mb-4 text-[10px] font-mono uppercase tracking-wider">
            <button
              type="button"
              onClick={() => {
                setAuthMode('signin');
                setDiagnostic(null);
              }}
              className={`flex-1 py-2 text-center transition-colors cursor-pointer ${
                authMode === 'signin'
                  ? 'bg-white text-black font-bold'
                  : isDark ? 'text-neutral-400 hover:text-white' : 'text-neutral-600 hover:text-black'
              }`}
            >
              Sign In (Existing)
            </button>
            <button
              type="button"
              onClick={() => {
                setAuthMode('register');
                setDiagnostic(null);
              }}
              className={`flex-1 py-2 text-center transition-colors cursor-pointer ${
                authMode === 'register'
                  ? 'bg-white text-black font-bold'
                  : isDark ? 'text-neutral-400 hover:text-white' : 'text-neutral-600 hover:text-black'
              }`}
            >
              Create Admin Account
            </button>
          </div>

          {/* Email / Password Form */}
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              setDiagnostic(null);
              setIsSubmittingAuth(true);

              try {
                if (authMode === 'register') {
                  if (emailInput.trim().toLowerCase() !== OWNER_EMAIL.toLowerCase()) {
                    throw new Error(
                      `Security Policy: Only the designated brand owner (${OWNER_EMAIL}) is permitted to register the initial administrator account.`
                    );
                  }
                  await registerAdmin(emailInput, passwordInput);
                } else {
                  await loginWithEmail(emailInput, passwordInput);
                }
              } catch (err: any) {
                setDiagnostic(formatAuthErrorMessage(err));
              } finally {
                setIsSubmittingAuth(false);
              }
            }}
            className="space-y-4 text-left"
          >
            <div>
              <label className="block text-[10px] font-mono uppercase tracking-wider text-neutral-400 mb-1">
                Admin Email Address
              </label>
              <input
                type="email"
                value={emailInput}
                onChange={(e) => setEmailInput(e.target.value)}
                placeholder="Enter administrator email address"
                required
                className={`w-full px-3 py-2 text-xs font-mono border focus:outline-none ${
                  isDark ? 'bg-black/40 border-white/20 text-white focus:border-white' : 'bg-white border-black/20 text-black focus:border-black'
                }`}
              />
              {authMode === 'register' && (
                <span className="block text-[9px] text-neutral-400 font-mono mt-1">
                  Must match authorized brand owner address: <strong className="text-amber-400">{OWNER_EMAIL}</strong>
                </span>
              )}
            </div>

            <div>
              <label className="block text-[10px] font-mono uppercase tracking-wider text-neutral-400 mb-1">
                Password
              </label>
              <input
                type="password"
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                placeholder="Enter your administrative password"
                required
                minLength={6}
                className={`w-full px-3 py-2 text-xs font-mono border focus:outline-none ${
                  isDark ? 'bg-black/40 border-white/20 text-white focus:border-white' : 'bg-white border-black/20 text-black focus:border-black'
                }`}
              />
            </div>

            <button
              type="submit"
              disabled={isSubmittingAuth}
              className={`w-full py-2.5 border text-xs font-mono font-bold uppercase tracking-wider transition-colors cursor-pointer disabled:opacity-50 ${
                isDark ? 'border-white/30 text-white hover:bg-white/10' : 'border-black/30 text-black hover:bg-black/10'
              }`}
            >
              {isSubmittingAuth
                ? 'VERIFYING CREDENTIALS...'
                : authMode === 'register'
                ? 'CREATE SUPER-ADMIN ACCOUNT'
                : 'SIGN IN TO MANAGEMENT'}
            </button>
          </form>

          {/* Current Domain Diagnostic Reference */}
          <div className="mt-6 pt-4 border-t border-white/10 text-left text-[10px] font-mono text-neutral-400 space-y-1">
            <div className="flex items-center gap-1.5 text-neutral-300">
              <Info className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>Current Hostname: <strong>{typeof window !== 'undefined' ? window.location.hostname : 'localhost'}</strong></span>
            </div>
            <p className="text-[9px] text-neutral-500 leading-normal">
              If Google Sign-In gives an unauthorized-domain error, ensure this hostname is listed under Firebase Console &gt; Authentication &gt; Settings &gt; Authorized domains.
            </p>
          </div>

          <div className="mt-8 pt-4 border-t border-white/10 text-center">
            <button
              onClick={() => navigateTo('/')}
              className="text-[11px] font-mono uppercase text-neutral-400 hover:text-white transition-colors flex items-center justify-center gap-1.5 mx-auto"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to 3KO Storefront</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // If user is authenticated but NOT an authorized admin, reject access
  if (!isAdmin) {
    return (
      <div className={`min-h-screen flex items-center justify-center px-4 py-20 ${isDark ? 'bg-[#080808] text-white' : 'bg-[#F9F8F5] text-black'}`}>
        <div className={`max-w-md w-full border p-8 text-center shadow-2xl ${isDark ? 'bg-[#121212] border-red-500/40' : 'bg-white border-red-500/40'}`}>
          <div className="w-12 h-12 bg-red-500/20 text-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <AlertCircle className="w-6 h-6" />
          </div>
          <h2 className="font-display font-black text-2xl uppercase tracking-tight mb-2">
            UNAUTHORIZED ACCESS (403)
          </h2>
          <p className="text-xs text-neutral-400 leading-relaxed font-sans mb-4">
            Signed in as <strong className="text-white font-mono">{currentUser.email}</strong>. This account does not possess administrator credentials for the 3KO management dashboard.
          </p>
          <div className="p-3 bg-neutral-900 border border-white/10 text-[11px] font-mono text-neutral-300 text-left mb-6">
            Authorized Owner Email: <span className="text-amber-400">adeluolabraham@gmail.com</span>
          </div>
          <div className="flex flex-col gap-3">
            <button
              onClick={() => logout()}
              className="w-full py-2.5 bg-red-600 hover:bg-red-700 text-white font-mono text-xs uppercase tracking-wider cursor-pointer"
            >
              Sign Out & Switch Account
            </button>
            <button
              onClick={() => navigateTo('/')}
              className={`w-full py-2.5 border text-xs font-mono uppercase tracking-wider cursor-pointer ${
                isDark ? 'border-white/20 text-white hover:bg-white/10' : 'border-black/20 text-black hover:bg-black/10'
              }`}
            >
              Return to Storefront
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ========================================================
  // 2. AUTHORIZED ADMIN DASHBOARD MAIN VIEW
  // ========================================================

  // Quick Metrics
  const totalRevenueNGN = orders
    .filter((o) => o.paymentStatus === 'success' || o.orderStatus !== 'cancelled')
    .reduce((acc, o) => acc + (o.total || 0), 0);

  const pendingOrdersCount = orders.filter(
    (o) => o.orderStatus === 'paid' || o.orderStatus === 'processing'
  ).length;

  const preOrdersCount = products.filter((p) => p.isPreOrder).length;

  // Filtered orders
  const filteredOrders = orders.filter((o) => {
    if (orderStatusFilter !== 'all' && normalizeOrderStatus(o.orderStatus) !== normalizeOrderStatus(orderStatusFilter)) return false;
    if (orderSearch) {
      const q = orderSearch.toLowerCase();
      const matchNum = o.orderNumber?.toLowerCase().includes(q);
      const matchName = o.customer?.fullName?.toLowerCase().includes(q);
      const matchEmail = o.customer?.email?.toLowerCase().includes(q);
      return matchNum || matchName || matchEmail;
    }
    return true;
  });

  // Filtered products with collection, availability, and SKU searching
  const filteredProducts = products.filter((p) => {
    if (productLineFilter !== 'all' && p.line !== productLineFilter) return false;
    if (productCollectionFilter !== 'all' && p.collectionId !== productCollectionFilter) return false;
    
    if (productAvailabilityFilter === 'archived') {
      if (!p.isArchived) return false;
    } else {
      // By default for non-archived tabs, hide archived unless specifically asked
      if (p.isArchived) return false;
      if (productAvailabilityFilter === 'in_stock' && (p.stockQuantity ?? 10) <= 0) return false;
      if (productAvailabilityFilter === 'low_stock' && ((p.stockQuantity ?? 10) > 5 || (p.stockQuantity ?? 10) <= 0)) return false;
      if (productAvailabilityFilter === 'preorder_only' && !p.isPreOrder) return false;
    }

    if (productSearch) {
      const q = productSearch.toLowerCase().trim();
      const matchName = p.name?.toLowerCase().includes(q);
      const matchCategory = p.category?.toLowerCase().includes(q);
      const matchSlug = p.slug?.toLowerCase().includes(q);
      const matchSku = p.sku?.toLowerCase().includes(q);
      const matchColor = p.color?.toLowerCase().includes(q);
      return matchName || matchCategory || matchSlug || matchSku || matchColor;
    }
    return true;
  });

  return (
    <div className={`min-h-screen pt-20 pb-28 px-4 sm:px-8 lg:px-12 transition-colors duration-300 ${isDark ? 'bg-[#080808] text-white' : 'bg-[#F9F8F5] text-neutral-900'}`}>
      <div className="max-w-[1540px] mx-auto">
        {/* Top Management Header Bar */}
        <div className={`py-6 border-b flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8 ${isDark ? 'border-white/10' : 'border-black/10'}`}>
          <div>
            <div className="flex items-center gap-2 text-xs font-mono text-lime-400 font-bold uppercase tracking-widest mb-1">
              <ShieldCheck className="w-4 h-4" />
              <span>AUTHENTICATED 3KO STORE OWNER · LIVE FIREBASE BACKEND</span>
            </div>
            <h1 className="font-display font-black text-3xl sm:text-4xl uppercase tracking-tight">
              3KO ATELIER DASHBOARD
            </h1>
            <p className={`text-xs font-mono ${isDark ? 'text-neutral-400' : 'text-neutral-500'}`}>
              Signed in as: <strong className="text-white">{currentUser.email}</strong> · Full administrative privileges
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => seedInitialData()}
              className="px-4 py-2 border border-amber-500/40 text-amber-300 hover:bg-amber-500/10 text-xs font-mono uppercase tracking-wider flex items-center gap-1.5 cursor-pointer"
              title="Populates all 3KO garments into your Firestore database"
            >
              <Database className="w-3.5 h-3.5" />
              <span>Seed Catalog</span>
            </button>
            <button
              onClick={() => navigateTo('/')}
              className={`px-4 py-2 border text-xs font-mono uppercase tracking-wider flex items-center gap-1.5 cursor-pointer ${
                isDark ? 'border-white/20 text-white hover:bg-white/10' : 'border-black/20 text-black hover:bg-black/10'
              }`}
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>View Storefront</span>
            </button>
            <button
              onClick={() => logout()}
              className="px-3.5 py-2 bg-red-600/80 hover:bg-red-600 text-white text-xs font-mono uppercase tracking-wider flex items-center gap-1.5 cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>

        {/* Dashboard Navigation Tabs */}
        <div className={`flex flex-wrap items-center gap-2 mb-8 pb-4 border-b ${isDark ? 'border-white/10' : 'border-black/10'}`}>
          {[
            { id: 'overview', label: 'Overview & Metrics', icon: TrendingUp },
            { id: 'orders', label: `Orders (${orders.length})`, icon: ShoppingBag },
            { id: 'products', label: `Garments & Pre-Orders (${products.length})`, icon: Package },
            { id: 'collections', label: `Lagos 001–009 (${collections.length})`, icon: MapPin },
            { id: 'settings', label: 'Store Settings & Gateway', icon: Layers },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2.5 text-xs font-mono font-bold uppercase tracking-wider border flex items-center gap-2 cursor-pointer transition-all ${
                  isActive
                    ? isDark
                      ? 'border-white bg-white text-black'
                      : 'border-black bg-black text-white'
                    : isDark
                    ? 'border-white/10 bg-[#121212] text-neutral-400 hover:text-white'
                    : 'border-black/10 bg-white text-neutral-600 hover:text-black'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* ==================================================== */}
        {/* TAB 1: OVERVIEW & KEY METRICS */}
        {/* ==================================================== */}
        {activeTab === 'overview' && (
          <div className="space-y-8 animate-in fade-in duration-200">
            {/* Top Metrics Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className={`p-6 border ${isDark ? 'bg-[#111111] border-white/15' : 'bg-white border-black/15 shadow-sm'}`}>
                <span className="text-[10px] font-mono uppercase tracking-widest text-neutral-400 block mb-1">
                  TOTAL RECORDED REVENUE
                </span>
                <div className="font-display font-black text-2xl sm:text-3xl text-lime-400">
                  ₦{totalRevenueNGN.toLocaleString()}
                </div>
                <span className="text-[10px] font-mono text-neutral-500 mt-2 block">
                  Across {orders.length} total client transactions
                </span>
              </div>

              <div className={`p-6 border ${isDark ? 'bg-[#111111] border-white/15' : 'bg-white border-black/15 shadow-sm'}`}>
                <span className="text-[10px] font-mono uppercase tracking-widest text-neutral-400 block mb-1">
                  PENDING ATELIER FULFILLMENT
                </span>
                <div className="font-display font-black text-2xl sm:text-3xl text-amber-400">
                  {pendingOrdersCount}
                </div>
                <span className="text-[10px] font-mono text-neutral-500 mt-2 block">
                  Paid orders awaiting dispatch / packaging
                </span>
              </div>

              <div className={`p-6 border ${isDark ? 'bg-[#111111] border-white/15' : 'bg-white border-black/15 shadow-sm'}`}>
                <span className="text-[10px] font-mono uppercase tracking-widest text-neutral-400 block mb-1">
                  ACTIVE PRE-ORDER DROPS
                </span>
                <div className="font-display font-black text-2xl sm:text-3xl text-cyan-400">
                  {preOrdersCount}
                </div>
                <span className="text-[10px] font-mono text-neutral-500 mt-2 block">
                  Garments currently in production runs
                </span>
              </div>

              <div className={`p-6 border ${isDark ? 'bg-[#111111] border-white/15' : 'bg-white border-black/15 shadow-sm'}`}>
                <span className="text-[10px] font-mono uppercase tracking-widest text-neutral-400 block mb-1">
                  TOTAL CATALOG PIECES
                </span>
                <div className="font-display font-black text-2xl sm:text-3xl text-white">
                  {products.length}
                </div>
                <span className="text-[10px] font-mono text-neutral-500 mt-2 block">
                  STREET & FORM luxury wardrobe items
                </span>
              </div>
            </div>

            {/* Quick Actions & Recent Orders Preview */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              <div className={`lg:col-span-8 p-6 border ${isDark ? 'bg-[#111111] border-white/15' : 'bg-white border-black/15 shadow-sm'}`}>
                <div className="flex items-center justify-between mb-6 pb-3 border-b border-white/10">
                  <h3 className="font-display font-bold text-lg uppercase tracking-tight">
                    RECENT CLIENT ORDERS
                  </h3>
                  <button
                    onClick={() => setActiveTab('orders')}
                    className="text-xs font-mono text-neutral-400 hover:text-white uppercase flex items-center gap-1"
                  >
                    <span>View All Orders →</span>
                  </button>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-mono">
                    <thead className="text-[10px] uppercase text-neutral-400 border-b border-white/10 pb-2">
                      <tr>
                        <th className="py-2">Order #</th>
                        <th>Customer</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Payment</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {orders.slice(0, 5).map((ord) => (
                        <tr
                          key={ord.id}
                          onClick={() => {
                            setSelectedOrder(ord);
                            setTrackingNumberInput(ord.trackingNumber || '');
                          }}
                          className="hover:bg-white/5 cursor-pointer transition-colors"
                        >
                          <td className="py-3 font-bold">{ord.orderNumber}</td>
                          <td>{ord.customer?.fullName}</td>
                          <td>₦{ord.total?.toLocaleString()}</td>
                          <td>
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-white/10 text-neutral-200">
                              {ord.orderStatus || ord.status}
                            </span>
                          </td>
                          <td>
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                                ord.paymentStatus === 'success' ? 'bg-lime-900/60 text-lime-300' : 'bg-amber-900/60 text-amber-300'
                              }`}
                            >
                              {ord.paymentStatus}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Quick Admin Actions Box */}
              <div className={`lg:col-span-4 p-6 border space-y-4 ${isDark ? 'bg-[#111111] border-white/15' : 'bg-white border-black/15 shadow-sm'}`}>
                <h3 className="font-display font-bold text-lg uppercase tracking-tight mb-2">
                  STORE MANAGEMENT ACTIONS
                </h3>
                <button
                  onClick={() => {
                    setEditingProduct(null);
                    setProductForm({
                      name: '',
                      slug: '',
                      subtitle: '',
                      line: 'street',
                      category: 'shirts',
                      collectionId: '001',
                      collectionName: 'LAGOS 001 — IKOYI',
                      priceNGN: 55000,
                      priceUSD: 38,
                      priceGBP: 30,
                      color: 'Obsidian Black',
                      colorHex: '#080808',
                      sizes: ['S', 'M', 'L', 'XL'],
                      stockQuantity: 20,
                      isPreOrder: false,
                      preOrderLimit: 50,
                      preOrderCount: 0,
                      productionStatus: 'Ready for Atelier Cutting',
                      images: ['/images/apparel/look_001_ikoyi_tee_cap.jpg'],
                      description: 'Engineered in Lagos, Nigeria.',
                      packagingNote: 'Signature 1200 GSM rigid collector box included.',
                    });
                    setIsNewProductModalOpen(true);
                  }}
                  className="w-full py-3 bg-white text-black font-bold text-xs uppercase tracking-wider hover:bg-neutral-200 transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-md"
                >
                  <Plus className="w-4 h-4" />
                  <span>ADD NEW GARMENT DROP</span>
                </button>

                <button
                  onClick={() => seedInitialData()}
                  className="w-full py-3 border border-white/20 text-neutral-300 hover:text-white hover:border-white font-mono text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Database className="w-4 h-4 text-amber-400" />
                  <span>SYNC ALL 3KO GARMENTS TO FIRESTORE</span>
                </button>

                <div className="p-4 bg-black/40 border border-white/10 space-y-2 text-xs font-mono text-neutral-300">
                  <div className="text-[10px] text-amber-400 uppercase font-bold">Paystack Integration Status:</div>
                  <p className="text-[11px] text-neutral-400">
                    Active on public key: {import.meta.env.VITE_PAYSTACK_PUBLIC_KEY ? 'CONFIGURED' : 'DEVELOPMENT TEST MODE'}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ==================================================== */}
        {/* TAB 2: ORDERS MANAGEMENT */}
        {/* ==================================================== */}
        {activeTab === 'orders' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            {/* Filter & Search Bar */}
            <div className={`p-4 border flex flex-col md:flex-row md:items-center justify-between gap-4 ${isDark ? 'bg-[#111111] border-white/15' : 'bg-white border-black/15 shadow-sm'}`}>
              <div className="relative flex-1 max-w-md">
                <Search className="w-4 h-4 absolute left-3 top-3 text-neutral-400" />
                <input
                  type="text"
                  value={orderSearch}
                  onChange={(e) => setOrderSearch(e.target.value)}
                  placeholder="Search by order #, customer name, email..."
                  className={`w-full pl-9 pr-4 py-2 text-xs font-mono border focus:outline-none ${
                    isDark ? 'bg-black border-white/20 text-white focus:border-white' : 'bg-neutral-50 border-black/20 text-black focus:border-black'
                  }`}
                />
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-neutral-400">STATUS:</span>
                <select
                  value={orderStatusFilter}
                  onChange={(e) => setOrderStatusFilter(e.target.value)}
                  className={`px-3 py-1.5 text-xs font-mono border focus:outline-none ${
                    isDark ? 'bg-black border-white/20 text-white' : 'bg-white border-black/20 text-black'
                  }`}
                >
                  <option value="all">All Statuses ({orders.length})</option>
                  <option value="pending_payment">Pending Payment</option>
                  <option value="paid">Paid</option>
                  <option value="processing">Processing</option>
                  <option value="ready">Ready to Ship</option>
                  <option value="shipped">Shipped</option>
                  <option value="delivered">Delivered</option>
                  <option value="cancelled">Cancelled</option>
                  <option value="refunded">Refunded</option>
                </select>
              </div>
            </div>

            {/* Orders Table */}
            <div className={`border overflow-x-auto ${isDark ? 'bg-[#111111] border-white/15' : 'bg-white border-black/15 shadow-sm'}`}>
              <table className="w-full text-left text-xs font-mono">
                <thead className={`text-[10px] uppercase border-b ${isDark ? 'bg-neutral-900 border-white/10 text-neutral-400' : 'bg-neutral-100 border-black/10 text-neutral-600'}`}>
                  <tr>
                    <th className="py-3 px-4">Order Number</th>
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4">Customer Details</th>
                    <th className="py-3 px-4">Items</th>
                    <th className="py-3 px-4">Total Amount</th>
                    <th className="py-3 px-4">Payment</th>
                    <th className="py-3 px-4">Order Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {filteredOrders.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-12 text-center text-neutral-500">
                        No orders match current criteria.
                      </td>
                    </tr>
                  ) : (
                    filteredOrders.map((ord) => (
                      <tr key={ord.id} className="hover:bg-white/5 transition-colors">
                        <td className="py-3.5 px-4 font-bold text-white flex items-center gap-1.5">
                          <span>{ord.orderNumber}</span>
                          {ord.isPreOrder && (
                            <span className="text-[9px] px-1.5 py-0.2 bg-cyan-900/60 text-cyan-300 rounded font-mono">
                              PRE-ORDER
                            </span>
                          )}
                        </td>
                        <td className="py-3.5 px-4 text-neutral-400">
                          {new Date(ord.orderDate || ord.createdAt || '').toLocaleDateString()}
                        </td>
                        <td className="py-3.5 px-4">
                          <div className="font-bold text-white">{ord.customer?.fullName}</div>
                          <div className="text-[11px] text-neutral-400">{ord.customer?.email}</div>
                          <div className="text-[11px] text-neutral-500">{ord.customer?.phone}</div>
                        </td>
                        <td className="py-3.5 px-4">
                          <span className="font-bold">{ord.items?.length || 0}</span> pieces
                        </td>
                        <td className="py-3.5 px-4 font-bold text-white">
                          ₦{ord.total?.toLocaleString()}
                        </td>
                        <td className="py-3.5 px-4">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                              ord.paymentStatus === 'success'
                                ? 'bg-lime-900/50 text-lime-300 border border-lime-500/30'
                                : ord.paymentStatus === 'failed'
                                ? 'bg-red-900/50 text-red-300 border border-red-500/30'
                                : 'bg-amber-900/50 text-amber-300 border border-amber-500/30'
                            }`}
                          >
                            {ord.paymentStatus}
                          </span>
                        </td>
                        <td className="py-3.5 px-4">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-white/10 text-neutral-200">
                            {ord.orderStatus || ord.status}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-right">
                          <button
                            onClick={() => {
                              setSelectedOrder(ord);
                              setTrackingNumberInput(ord.trackingNumber || '');
                            }}
                            className="px-3 py-1 bg-white/10 hover:bg-white hover:text-black transition-colors rounded text-[11px] font-bold uppercase cursor-pointer"
                          >
                            Manage Order
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ==================================================== */}
        {/* TAB 3: PRODUCTS & PRE-ORDER INVENTORY */}
        {/* ==================================================== */}
        {/* ==================================================== */}
        {/* TAB 3: PRODUCTS & PRE-ORDER INVENTORY */}
        {/* ==================================================== */}
        {activeTab === 'products' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            {/* Action Bar */}
            <div className={`p-4 sm:p-5 border flex flex-col gap-4 ${isDark ? 'bg-[#111111] border-white/15' : 'bg-white border-black/15 shadow-sm'}`}>
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                <div className="flex-1 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                  {/* Search Bar */}
                  <div className="relative flex-1 max-w-md">
                    <Search className="w-4 h-4 absolute left-3 top-3 text-neutral-400" />
                    <input
                      type="text"
                      value={productSearch}
                      onChange={(e) => setProductSearch(e.target.value)}
                      placeholder="Search by name, SKU, slug, category, color..."
                      className={`w-full pl-9 pr-4 py-2 text-xs font-mono border focus:outline-none ${
                        isDark ? 'bg-black border-white/20 text-white' : 'bg-neutral-50 border-black/20 text-black'
                      }`}
                    />
                  </div>

                  {/* Chapter Select */}
                  <div className="shrink-0">
                    <select
                      value={productCollectionFilter}
                      onChange={(e) => setProductCollectionFilter(e.target.value)}
                      className={`py-2 px-3 text-xs font-mono border uppercase focus:outline-none ${
                        isDark ? 'bg-black border-white/20 text-white' : 'bg-neutral-50 border-black/20 text-black'
                      }`}
                    >
                      <option value="all">All Chapters (001–009 + Core)</option>
                      {collections.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.fullName}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Add Garment Button */}
                <button
                  onClick={() => {
                    setEditingProduct(null);
                    setProductForm({
                      name: '',
                      sku: `3KO-STR-001-${Math.floor(100 + Math.random() * 900)}`,
                      slug: '',
                      subtitle: '3KO Contemporary Fashion Piece',
                      line: 'street',
                      category: 'shirts',
                      collectionId: '001',
                      collectionName: '3KO 001 — IKOYI',
                      priceNGN: 55000,
                      priceUSD: 38,
                      priceGBP: 30,
                      compareAtPriceNGN: undefined,
                      compareAtPriceUSD: undefined,
                      compareAtPriceGBP: undefined,
                      color: 'Obsidian Black',
                      colorHex: '#080808',
                      sizes: ['S', 'M', 'L', 'XL'],
                      stockQuantity: 15,
                      availability: 'in_stock',
                      isArchived: false,
                      allowNegotiation: false,
                      minOfferPercentage: 80,
                      isPreOrder: false,
                      preOrderLimit: 50,
                      preOrderCount: 0,
                      productionStatus: 'Atelier Pattern Drafting',
                      estimatedDelivery: 'Ships within 3–5 business days',
                      images: ['/images/apparel/look_001_ikoyi_tee_cap.jpg'],
                      description: 'Engineered in Lagos, Nigeria. Architectural tailoring crafted for contemporary velocity.',
                      editorialNote: 'First Edition 3KO Archive.',
                      fabricDetails: ['100% heavyweight ringspun cotton (280 GSM)', 'Tactile high-density puff ink illustration'],
                      careInstructions: ['Dry clean or wash cold inside out', 'Line dry only; do not iron directly on print'],
                      fit: 'Relaxed contemporary oversized cut with dropped shoulders',
                      packagingNote: 'Signature 1200 GSM architectural collector box included.',
                      isFeatured: false,
                      isNew: true,
                      isBestSeller: false,
                    });
                    setActiveFormTab('general');
                    setImageUploadError(null);
                    setIsNewProductModalOpen(true);
                  }}
                  className="px-5 py-2.5 bg-white text-black font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer shadow-md hover:bg-neutral-200 transition-colors shrink-0"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Garment Piece</span>
                </button>
              </div>

              {/* Segmented Filter Controls */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-white/10 text-xs font-mono">
                {/* Line Filter */}
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-[10px] uppercase text-neutral-400 mr-1">System:</span>
                  {(['all', 'street', 'form', 'edition'] as const).map((l) => (
                    <button
                      key={l}
                      onClick={() => setProductLineFilter(l)}
                      className={`px-2.5 py-1 text-[11px] uppercase font-bold border transition-colors cursor-pointer ${
                        productLineFilter === l
                          ? isDark ? 'bg-white text-black border-white' : 'bg-black text-white border-black'
                          : isDark ? 'border-white/10 text-neutral-400 hover:text-white' : 'border-black/10 text-neutral-600 hover:text-black'
                      }`}
                    >
                      {l === 'all' ? 'All Lines' : l === 'street' ? '3KO STREET' : l === 'form' ? '3KO FORM' : 'Packaging'}
                    </button>
                  ))}
                </div>

                {/* Availability Filter */}
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-[10px] uppercase text-neutral-400 mr-1">Status:</span>
                  {(['all', 'in_stock', 'low_stock', 'preorder_only', 'archived'] as const).map((status) => {
                    const archivedCount = products.filter((p) => p.isArchived).length;
                    return (
                      <button
                        key={status}
                        onClick={() => setProductAvailabilityFilter(status)}
                        className={`px-2.5 py-1 text-[11px] uppercase font-bold border transition-colors cursor-pointer flex items-center gap-1 ${
                          productAvailabilityFilter === status
                            ? status === 'archived'
                              ? 'bg-amber-400 text-black border-amber-400'
                              : isDark ? 'bg-white text-black border-white' : 'bg-black text-white border-black'
                            : isDark ? 'border-white/10 text-neutral-400 hover:text-white' : 'border-black/10 text-neutral-600 hover:text-black'
                        }`}
                      >
                        {status === 'archived' && <Archive className="w-3 h-3" />}
                        <span>
                          {status === 'all'
                            ? `Active (${products.filter((p) => !p.isArchived).length})`
                            : status === 'in_stock'
                            ? 'In Stock'
                            : status === 'low_stock'
                            ? 'Low Stock (<5)'
                            : status === 'preorder_only'
                            ? 'Pre-Orders'
                            : `Archived (${archivedCount})`}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Products Table */}
            <div className={`border overflow-x-auto ${isDark ? 'bg-[#111111] border-white/15' : 'bg-white border-black/15 shadow-sm'}`}>
              <table className="w-full text-left text-xs font-mono">
                <thead className={`text-[10px] uppercase border-b ${isDark ? 'bg-neutral-900 border-white/10 text-neutral-400' : 'bg-neutral-100 border-black/10 text-neutral-600'}`}>
                  <tr>
                    <th className="py-3 px-4">Garment & SKU</th>
                    <th className="py-3 px-4">System / Chapter</th>
                    <th className="py-3 px-4">Price (NGN / USD / GBP)</th>
                    <th className="py-3 px-4">Inventory & State</th>
                    <th className="py-3 px-4">Badges & Negotiation</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {filteredProducts.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-12 text-center text-neutral-400">
                        No garments match your active filters. Try resetting search or status filters.
                      </td>
                    </tr>
                  ) : (
                    filteredProducts.map((p) => (
                      <tr key={p.id} className="hover:bg-white/5 transition-colors">
                        {/* Garment Thumbnail, Name & SKU */}
                        <td className="py-3.5 px-4 flex items-center gap-3">
                          <div className="relative w-12 h-14 bg-black border border-white/10 shrink-0 overflow-hidden">
                            <img
                              src={p.images?.[0] || '/images/apparel/look_001_ikoyi_tee_cap.jpg'}
                              alt={p.name}
                              className="w-full h-full object-cover"
                            />
                            {p.images && p.images.length > 1 && (
                              <span className="absolute bottom-0 right-0 bg-black/80 text-[8px] font-mono px-1 text-white">
                                +{p.images.length - 1}
                              </span>
                            )}
                          </div>
                          <div>
                            <div className="font-bold text-white text-sm line-clamp-1">{p.name}</div>
                            <div className="flex items-center gap-2 mt-0.5 text-[10px] text-neutral-400">
                              <span className="font-mono text-neutral-300">{p.sku || p.slug}</span>
                              <span>·</span>
                              <div className="flex items-center gap-1">
                                <span className="w-2 h-2 rounded-full border border-white/20" style={{ backgroundColor: p.colorHex }} />
                                <span>{p.color}</span>
                              </div>
                            </div>
                            {p.isArchived && (
                              <span className="inline-block mt-1 px-1.5 py-0.2 text-[9px] font-mono uppercase bg-amber-500/20 text-amber-300 border border-amber-500/30">
                                ARCHIVED
                              </span>
                            )}
                          </div>
                        </td>

                        {/* System / Chapter */}
                        <td className="py-3.5 px-4">
                          <div className="font-bold uppercase text-white">
                            {p.line === 'street' ? '3KO STREET' : p.line === 'form' ? '3KO FORM' : 'SPECIAL'}
                          </div>
                          <div className="text-[10px] text-neutral-400">
                            {p.collectionName || 'Core Collection'}
                          </div>
                        </td>

                        {/* Pricing (with Compare-At if set) */}
                        <td className="py-3.5 px-4">
                          <div className="flex items-baseline gap-2">
                            <span className="font-bold text-white">₦{p.priceNGN?.toLocaleString()}</span>
                            {p.compareAtPriceNGN && p.compareAtPriceNGN > p.priceNGN && (
                              <span className="text-[10px] line-through text-neutral-500">
                                ₦{p.compareAtPriceNGN.toLocaleString()}
                              </span>
                            )}
                          </div>
                          <div className="text-[10px] text-neutral-400">
                            ${p.priceUSD} · £{p.priceGBP}
                          </div>
                        </td>

                        {/* Inventory & State */}
                        <td className="py-3.5 px-4">
                          {p.isPreOrder ? (
                            <div>
                              <span className="px-2 py-0.5 text-[9px] font-bold uppercase bg-cyan-950 text-cyan-300 border border-cyan-500/40 rounded inline-block">
                                PRE-ORDER ({p.preOrderCount || 0}/{p.preOrderLimit || 50})
                              </span>
                              <div className="text-[10px] text-neutral-400 mt-0.5">
                                {p.productionStatus || 'In Production'}
                              </div>
                            </div>
                          ) : (
                            <div>
                              <span
                                className={`font-bold ${
                                  (p.stockQuantity ?? 15) <= 0
                                    ? 'text-red-400'
                                    : (p.stockQuantity ?? 15) <= 5
                                    ? 'text-amber-400'
                                    : 'text-emerald-400'
                                }`}
                              >
                                {(p.stockQuantity ?? 15) <= 0
                                  ? 'Sold Out (0)'
                                  : `${p.stockQuantity ?? 15} in stock`}
                              </span>
                              <div className="text-[10px] text-neutral-400 mt-0.5">
                                Sizes: {p.sizes?.join(', ')}
                              </div>
                            </div>
                          )}
                        </td>

                        {/* Badges & Negotiation */}
                        <td className="py-3.5 px-4">
                          <div className="flex flex-wrap gap-1">
                            {p.isFeatured && (
                              <span className="px-1.5 py-0.5 text-[9px] font-mono bg-lime-400/20 text-lime-400 border border-lime-400/30 uppercase">
                                Featured
                              </span>
                            )}
                            {p.isNew && (
                              <span className="px-1.5 py-0.5 text-[9px] font-mono bg-blue-400/20 text-blue-300 border border-blue-400/30 uppercase">
                                New Drop
                              </span>
                            )}
                            {p.allowNegotiation && (
                              <span className="px-1.5 py-0.5 text-[9px] font-mono bg-purple-400/20 text-purple-300 border border-purple-400/30 uppercase">
                                Offers ({p.minOfferPercentage || 80}%)
                              </span>
                            )}
                          </div>
                        </td>

                        {/* Actions: Edit / Archive / Delete */}
                        <td className="py-3.5 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            {/* Edit Button */}
                            <button
                              onClick={() => {
                                setEditingProduct(p);
                                setProductForm({ ...p });
                                setActiveFormTab('general');
                                setImageUploadError(null);
                                setIsNewProductModalOpen(true);
                              }}
                              className="p-1.5 hover:text-white text-neutral-400 hover:bg-white/10 transition-colors cursor-pointer"
                              title="Edit Garment"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>

                            {/* Archive / Restore Button */}
                            <button
                              onClick={() => archiveProduct(p.id, !p.isArchived)}
                              className={`p-1.5 transition-colors cursor-pointer ${
                                p.isArchived
                                  ? 'text-amber-400 hover:text-amber-300 hover:bg-amber-400/10'
                                  : 'text-neutral-400 hover:text-amber-400 hover:bg-white/10'
                              }`}
                              title={p.isArchived ? 'Restore to active catalog' : 'Archive garment safely'}
                            >
                              <Archive className="w-4 h-4" />
                            </button>

                            {/* Delete Button (Opens Safe Protocol) */}
                            <button
                              onClick={() => setProductToDelete(p)}
                              className="p-1.5 hover:text-red-400 text-neutral-500 hover:bg-red-400/10 transition-colors cursor-pointer"
                              title="Delete Garment"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ==================================================== */}
        {/* TAB 4: LAGOS COLLECTIONS (001–009) */}
        {/* ==================================================== */}
        {activeTab === 'collections' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {collections.map((col) => (
                <div key={col.id} className={`p-5 border flex flex-col justify-between ${isDark ? 'bg-[#111111] border-white/15' : 'bg-white border-black/15 shadow-sm'}`}>
                  <div>
                    <div className="relative aspect-[16/9] overflow-hidden mb-3 border border-white/10">
                      <img src={col.image} alt={col.name} className="w-full h-full object-cover" />
                      <div className="absolute top-2 left-2 px-2 py-0.5 text-[10px] font-mono font-bold bg-black text-white">
                        {col.numberStr}
                      </div>
                    </div>
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="font-display font-bold text-lg uppercase text-white">{col.fullName}</h4>
                      <div className="w-4 h-4 rounded-full border border-white/20" style={{ backgroundColor: col.colorHex }} />
                    </div>
                    <p className="text-xs font-mono text-neutral-400 mb-2">{col.coordinates} · {col.landmark}</p>
                    <p className="text-xs text-neutral-300 font-sans line-clamp-2">{col.shortDesc}</p>
                  </div>

                  <div className="pt-4 border-t border-white/10 mt-4 flex items-center justify-between">
                    <span className="text-[10px] font-mono text-neutral-400 uppercase">THEME: {col.personality}</span>
                    <button
                      onClick={() => setEditingCollection(col)}
                      className="px-3 py-1 bg-white/10 hover:bg-white hover:text-black transition-colors rounded text-xs font-mono uppercase"
                    >
                      Edit Chapter
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ==================================================== */}
        {/* TAB 5: SETTINGS & GATEWAY CONFIGURATION */}
        {/* ==================================================== */}
        {activeTab === 'settings' && (
          <div className="space-y-8 animate-in fade-in duration-200">
            <div className={`p-6 sm:p-8 border space-y-6 ${isDark ? 'bg-[#111111] border-white/15' : 'bg-white border-black/15 shadow-sm'}`}>
              <h3 className="font-display font-bold text-xl uppercase tracking-tight">
                STOREFRONT OPERATIONAL SETTINGS
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-mono uppercase text-neutral-400 mb-1">
                    Announcement Ticker Text
                  </label>
                  <input
                    type="text"
                    value={storeSettings.announcementText}
                    onChange={(e) =>
                      saveStoreSettings({ ...storeSettings, announcementText: e.target.value })
                    }
                    className={`w-full p-2.5 text-xs font-mono border focus:outline-none ${
                      isDark ? 'bg-black border-white/20 text-white' : 'bg-white border-black/20 text-black'
                    }`}
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono uppercase text-neutral-400 mb-1">
                    Free Delivery Threshold (NGN)
                  </label>
                  <input
                    type="number"
                    value={storeSettings.freeShippingThresholdNGN}
                    onChange={(e) =>
                      saveStoreSettings({
                        ...storeSettings,
                        freeShippingThresholdNGN: parseInt(e.target.value, 10) || 0,
                      })
                    }
                    className={`w-full p-2.5 text-xs font-mono border focus:outline-none ${
                      isDark ? 'bg-black border-white/20 text-white' : 'bg-white border-black/20 text-black'
                    }`}
                  />
                </div>
              </div>

              {/* Gateway Check */}
              <div className="pt-6 border-t border-white/10">
                <h4 className="font-display font-bold text-base uppercase mb-2">BACKEND INTEGRATION STATUS</h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-mono">
                  <div className="p-3 bg-black/40 border border-white/10">
                    <div className="text-lime-400 font-bold mb-1">✓ FIREBASE FIRESTORE</div>
                    <div className="text-neutral-400 text-[11px]">Database active and provisioned. Security rules deployed.</div>
                  </div>
                  <div className="p-3 bg-black/40 border border-white/10">
                    <div className="text-lime-400 font-bold mb-1">✓ PAYSTACK CHECKOUT</div>
                    <div className="text-neutral-400 text-[11px]">Inline popup gateway + server-side verification proxy ready.</div>
                  </div>
                  <div className="p-3 bg-black/40 border border-white/10">
                    <div className="text-lime-400 font-bold mb-1">✓ TRANSACTIONAL EMAILS</div>
                    <div className="text-neutral-400 text-[11px]">Server endpoint /api/email/notify ready for dispatch.</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ==================================================== */}
        {/* MODAL 1: ORDER MANAGEMENT DRAWER */}
        {/* ==================================================== */}
        {selectedOrder && (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className={`max-w-2xl w-full border p-6 sm:p-8 max-h-[90vh] overflow-y-auto ${isDark ? 'bg-[#121212] border-white/20 text-white' : 'bg-white border-black/20 text-neutral-900 shadow-2xl'}`}>
              <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-6">
                <div>
                  <span className="text-[10px] font-mono uppercase text-amber-400 font-bold">
                    ORDER MANAGEMENT · {selectedOrder.orderNumber}
                  </span>
                  <h3 className="font-display font-black text-2xl uppercase">
                    Client Purchase Record
                  </h3>
                </div>
                <button
                  onClick={() => setSelectedOrder(null)}
                  className="p-2 hover:bg-white/10 rounded cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Order Content */}
              <div className="space-y-6 text-xs font-mono">
                {/* Customer Info */}
                <div className="p-4 bg-white/5 border border-white/10 space-y-1">
                  <div className="font-bold text-white text-sm mb-1">{selectedOrder.customer?.fullName}</div>
                  <div>Email: {selectedOrder.customer?.email}</div>
                  <div>Phone: {selectedOrder.customer?.phone}</div>
                  <div>
                    Delivery: {selectedOrder.customer?.address || 'Standard Address'},{' '}
                    {selectedOrder.customer?.city || 'Lagos'}
                  </div>
                </div>

                {/* Items */}
                <div className="space-y-2">
                  <span className="text-neutral-400 uppercase text-[10px] font-bold">Ordered Pieces:</span>
                  {selectedOrder.items?.map((it, idx) => (
                    <div key={idx} className="flex items-center justify-between p-3 border border-white/10 bg-black/30">
                      <div>
                        <div className="font-bold text-white">{it.product?.name}</div>
                        <div className="text-[11px] text-neutral-400">
                          Size: {it.selectedSize} · Color: {it.selectedColor} · Qty: {it.quantity}
                        </div>
                        {it.includeCollectorBox && (
                          <div className="text-[10px] text-amber-300">✓ 1200 GSM Collector Box included</div>
                        )}
                      </div>
                      <div className="font-bold text-white">
                        ₦{((it.product?.priceNGN + (it.includeCollectorBox ? it.boxPriceNGN : 0)) * it.quantity).toLocaleString()}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Status Transitions */}
                <div className="pt-4 border-t border-white/10 space-y-4">
                  <div>
                    <label className="block text-[10px] uppercase text-neutral-400 mb-1">
                      Update Order Fulfillment Workflow:
                    </label>
                    <select
                      value={normalizeOrderStatus(selectedOrder.orderStatus)}
                      onChange={(e) => {
                        const newStatus = e.target.value as OrderWorkflowStatus;
                        updateOrderStatus(selectedOrder.id, newStatus, trackingNumberInput);
                        setSelectedOrder({ ...selectedOrder, orderStatus: newStatus });
                      }}
                      className="w-full p-2.5 bg-black border border-white/20 text-white font-mono text-xs"
                    >
                      <option value="PENDING_PAYMENT">1. PENDING_PAYMENT (Awaiting Payment)</option>
                      <option value="PAID">2. PAID (Verified by Paystack)</option>
                      <option value="PROCESSING">3. PROCESSING (Atelier Production / Packaging)</option>
                      <option value="READY">4. READY (Awaiting Courier Dispatch)</option>
                      <option value="SHIPPED">5. SHIPPED (In Transit with Tracking)</option>
                      <option value="DELIVERED">6. DELIVERED (Client Received)</option>
                      <option value="CANCELLED">CANCELLED</option>
                      <option value="REFUNDED">REFUNDED</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase text-neutral-400 mb-1">
                      Courier Tracking Number (DHL / Lagos Courier):
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={trackingNumberInput}
                        onChange={(e) => setTrackingNumberInput(e.target.value)}
                        placeholder="e.g. DHL-99482104"
                        className="flex-1 p-2 bg-black border border-white/20 text-white font-mono text-xs"
                      />
                      <button
                        onClick={() => {
                          updateOrderStatus(selectedOrder.id, selectedOrder.orderStatus, trackingNumberInput);
                          setSelectedOrder({ ...selectedOrder, trackingNumber: trackingNumberInput });
                        }}
                        className="px-4 py-2 bg-white text-black font-bold text-xs uppercase cursor-pointer"
                      >
                        Save Tracking
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase text-neutral-400 mb-1">
                      Payment Verification State:
                    </label>
                    <select
                      value={normalizePaymentStatus(selectedOrder.paymentStatus)}
                      onChange={(e) => {
                        const newPayStatus = e.target.value as PaymentLifecycleStatus;
                        updateOrderPaymentStatus(selectedOrder.id, newPayStatus);
                        setSelectedOrder({ ...selectedOrder, paymentStatus: newPayStatus });
                      }}
                      className="w-full p-2.5 bg-black border border-white/20 text-white font-mono text-xs"
                    >
                      <option value="PENDING">PENDING</option>
                      <option value="SUCCESS">SUCCESS (Verified)</option>
                      <option value="FAILED">FAILED</option>
                      <option value="REFUNDED">REFUNDED</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ==================================================== */}
        {/* MODAL 2: ADD / EDIT GARMENT MODAL (FULL CRUD + STORAGE) */}
        {/* ==================================================== */}
        {isNewProductModalOpen && (
          <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
            <div className={`max-w-4xl w-full border max-h-[92vh] flex flex-col shadow-2xl ${isDark ? 'bg-[#0f0f0f] border-white/20 text-white' : 'bg-white border-black/20 text-neutral-900'}`}>
              {/* Modal Header */}
              <div className="flex items-center justify-between p-5 sm:p-6 border-b border-white/10 shrink-0">
                <div>
                  <div className="flex items-center gap-2 text-[10px] font-mono uppercase text-lime-400 font-bold tracking-widest">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>3KO ATELIER CATALOG MANAGEMENT</span>
                  </div>
                  <h3 className="font-display font-black text-2xl uppercase tracking-tight mt-0.5">
                    {editingProduct ? `EDIT: ${editingProduct.name}` : 'CREATE NEW GARMENT DROP'}
                  </h3>
                </div>
                <button
                  onClick={() => setIsNewProductModalOpen(false)}
                  className="p-2 hover:bg-white/10 rounded cursor-pointer transition-colors"
                  aria-label="Close modal"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Form Navigation Tabs */}
              <div className="flex border-b border-white/10 overflow-x-auto no-scrollbar bg-black/40 text-xs font-mono shrink-0">
                {[
                  { id: 'general', label: '1. Identity & System' },
                  { id: 'pricing', label: '2. Pricing & Offers' },
                  { id: 'inventory', label: '3. Sizes & Inventory' },
                  { id: 'preorder', label: '4. Pre-Order & Status' },
                  { id: 'images', label: `5. Images (${productForm.images?.length || 0})` },
                  { id: 'details', label: '6. Craft & Packaging' },
                ].map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => setActiveFormTab(t.id as any)}
                    className={`py-3 px-4 font-bold uppercase transition-colors whitespace-nowrap cursor-pointer border-b-2 ${
                      activeFormTab === t.id
                        ? 'border-lime-400 text-lime-400 bg-white/5'
                        : 'border-transparent text-neutral-400 hover:text-white'
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>

              {/* Modal Body / Tab Content */}
              <form
                id="garment-product-form"
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (!productForm.name || !productForm.priceNGN) {
                    setActiveFormTab('general');
                    return;
                  }

                  const slug = (productForm.slug || productForm.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, ''));
                  const finalImages = productForm.images?.length
                    ? productForm.images
                    : ['/images/apparel/look_001_ikoyi_tee_cap.jpg'];

                  const finalProduct: Product = {
                    id: editingProduct ? editingProduct.id : `prod-${Date.now()}`,
                    slug,
                    name: productForm.name || 'Untitled Piece',
                    sku: productForm.sku || `3KO-${(productForm.line || 'STR').toUpperCase().substring(0, 3)}-001`,
                    subtitle: productForm.subtitle || '3KO Contemporary Fashion Piece',
                    line: productForm.line || 'street',
                    category: productForm.category || 'shirts',
                    collectionId: productForm.collectionId || '',
                    collectionName: productForm.collectionName || 'Core Collection',
                    priceNGN: Number(productForm.priceNGN) || 55000,
                    priceUSD: Number(productForm.priceUSD) || 38,
                    priceGBP: Number(productForm.priceGBP) || 30,
                    compareAtPriceNGN: productForm.compareAtPriceNGN ? Number(productForm.compareAtPriceNGN) : undefined,
                    compareAtPriceUSD: productForm.compareAtPriceUSD ? Number(productForm.compareAtPriceUSD) : undefined,
                    compareAtPriceGBP: productForm.compareAtPriceGBP ? Number(productForm.compareAtPriceGBP) : undefined,
                    color: productForm.color || 'Obsidian Black',
                    colorHex: productForm.colorHex || '#080808',
                    sizes: productForm.sizes?.length ? productForm.sizes : ['S', 'M', 'L', 'XL'],
                    stockQuantity: Number(productForm.stockQuantity ?? 15),
                    availability: productForm.availability || 'in_stock',
                    isArchived: !!productForm.isArchived,
                    allowNegotiation: !!productForm.allowNegotiation,
                    minOfferPercentage: productForm.minOfferPercentage ? Number(productForm.minOfferPercentage) : 80,
                    isPreOrder: !!productForm.isPreOrder,
                    preOrderLimit: Number(productForm.preOrderLimit) || 50,
                    preOrderCount: Number(productForm.preOrderCount) || 0,
                    productionStatus: productForm.productionStatus || 'Atelier Pattern Drafting',
                    estimatedDelivery: productForm.estimatedDelivery || 'Ships within 3–5 business days',
                    description: productForm.description || 'Engineered in Lagos, Nigeria.',
                    editorialNote: productForm.editorialNote || 'First Edition 3KO Archive.',
                    fabricDetails: productForm.fabricDetails?.length ? productForm.fabricDetails : ['100% heavyweight ringspun cotton (280 GSM)', 'Tactile puff ink illustration'],
                    careInstructions: productForm.careInstructions?.length ? productForm.careInstructions : ['Dry clean or wash cold inside out'],
                    fit: productForm.fit || 'Relaxed contemporary silhouette',
                    images: finalImages,
                    primaryImageIndex: 0,
                    packagingNote: productForm.packagingNote || 'Signature 1200 GSM architectural collector box included.',
                    boxPackaging: productForm.boxPackaging || {
                      available: true,
                      boxName: `3KO Collector Box`,
                      collectionId: productForm.collectionId || '001',
                      boxImage: '/images/packaging/box_001_ikoyi.jpg',
                      priceNGN: 15000,
                      priceUSD: 12,
                      priceGBP: 10,
                      coordinates: 'Lagos, Nigeria',
                      description: 'Architectural rigid box included.',
                    },
                    isFeatured: !!productForm.isFeatured,
                    isNew: !!productForm.isNew,
                    isBestSeller: !!productForm.isBestSeller,
                  };

                  await saveProduct(finalProduct);
                  setIsNewProductModalOpen(false);
                }}
                className="p-5 sm:p-7 overflow-y-auto flex-1 space-y-6 text-xs font-mono"
              >
                {/* ================= TAB 1: GENERAL IDENTITY ================= */}
                {activeFormTab === 'general' && (
                  <div className="space-y-4">
                    <div>
                      <label className="block text-[10px] uppercase text-neutral-400 mb-1 font-bold">
                        Garment Piece Title *
                      </label>
                      <input
                        type="text"
                        required
                        value={productForm.name || ''}
                        onChange={(e) => setProductForm({ ...productForm, name: e.target.value })}
                        placeholder="e.g. 3KO — LAGOS 001 BRIDGE GRAPHIC TEE"
                        className="w-full p-2.5 bg-black border border-white/20 text-white font-sans text-sm focus:border-white focus:outline-none"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* SKU with Auto-generate */}
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-[10px] uppercase text-neutral-400 font-bold">SKU (Stock Keeping Unit)</label>
                          <button
                            type="button"
                            onClick={() => {
                              const pfx = productForm.line === 'form' ? '3KO-FRM' : '3KO-STR';
                              const colStr = productForm.collectionId ? `00${productForm.collectionId}`.slice(-3) : 'GEN';
                              const catStr = (productForm.category || 'TEE').substring(0, 3).toUpperCase();
                              const autoSku = `${pfx}-${colStr}-${catStr}-${Math.floor(100 + Math.random() * 900)}`;
                              setProductForm({ ...productForm, sku: autoSku });
                            }}
                            className="text-[9px] text-lime-400 uppercase hover:underline"
                          >
                            Auto-Generate SKU
                          </button>
                        </div>
                        <input
                          type="text"
                          value={productForm.sku || ''}
                          onChange={(e) => setProductForm({ ...productForm, sku: e.target.value.toUpperCase() })}
                          placeholder="3KO-STR-001-TEE"
                          className="w-full p-2.5 bg-black border border-white/20 text-white uppercase focus:border-white focus:outline-none"
                        />
                      </div>

                      {/* URL Slug */}
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-[10px] uppercase text-neutral-400 font-bold">URL Slug *</label>
                          <button
                            type="button"
                            onClick={() => {
                              if (productForm.name) {
                                const s = productForm.name
                                  .toLowerCase()
                                  .replace(/[^a-z0-9]+/g, '-')
                                  .replace(/^-+|-+$/g, '');
                                setProductForm({ ...productForm, slug: s });
                              }
                            }}
                            className="text-[9px] text-lime-400 uppercase hover:underline"
                          >
                            From Name
                          </button>
                        </div>
                        <input
                          type="text"
                          required
                          value={productForm.slug || ''}
                          onChange={(e) => setProductForm({ ...productForm, slug: e.target.value.toLowerCase().replace(/[^a-z0-9-]+/g, '-') })}
                          placeholder="lagos-001-bridge-tee"
                          className="w-full p-2.5 bg-black border border-white/20 text-white focus:border-white focus:outline-none"
                        />
                      </div>
                    </div>

                    {/* Subtitle / Kicker */}
                    <div>
                      <label className="block text-[10px] uppercase text-neutral-400 mb-1 font-bold">
                        Subtitle / Editorial Kicker
                      </label>
                      <input
                        type="text"
                        value={productForm.subtitle || ''}
                        onChange={(e) => setProductForm({ ...productForm, subtitle: e.target.value })}
                        placeholder="Heavyweight Signature Back-Graphic T-Shirt"
                        className="w-full p-2.5 bg-black border border-white/20 text-white focus:border-white focus:outline-none"
                      />
                    </div>

                    {/* Line & Category & Numbered Chapter */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                      <div>
                        <label className="block text-[10px] uppercase text-neutral-400 mb-1 font-bold">
                          Brand System (Line) *
                        </label>
                        <select
                          value={productForm.line || 'street'}
                          onChange={(e) => setProductForm({ ...productForm, line: e.target.value as any })}
                          className="w-full p-2.5 bg-black border border-white/20 text-white uppercase focus:border-white focus:outline-none"
                        >
                          <option value="street">3KO STREET</option>
                          <option value="form">3KO FORM</option>
                          <option value="edition">Packaging & Special</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[10px] uppercase text-neutral-400 mb-1 font-bold">
                          Numbered Chapter (001–009)
                        </label>
                        <select
                          value={productForm.collectionId || ''}
                          onChange={(e) => {
                            const cId = e.target.value;
                            const target = collections.find((c) => c.id === cId);
                            setProductForm({
                              ...productForm,
                              collectionId: cId,
                              collectionName: target ? target.fullName : 'Core Unassigned',
                            });
                          }}
                          className="w-full p-2.5 bg-black border border-white/20 text-white focus:border-white focus:outline-none"
                        >
                          <option value="">Core / Unassigned Chapter</option>
                          {collections.map((c) => (
                            <option key={c.id} value={c.id}>
                              {c.fullName}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-[10px] uppercase text-neutral-400 mb-1 font-bold">
                          Apparel Category *
                        </label>
                        <select
                          value={productForm.category || 'shirts'}
                          onChange={(e) => setProductForm({ ...productForm, category: e.target.value as any })}
                          className="w-full p-2.5 bg-black border border-white/20 text-white focus:border-white focus:outline-none"
                        >
                          <option value="shirts">Shirts & Graphic Tees</option>
                          <option value="hoodies">Hoodies & Sweaters</option>
                          <option value="joggers">Joggers & Shorts</option>
                          <option value="polos">Smart Tailored Polos</option>
                          <option value="trousers">Trousers & Chinos</option>
                          <option value="tailoring">Blazers & Overshirts</option>
                          <option value="caps">Caps & Headwear</option>
                          <option value="jerseys">Football Jerseys</option>
                          <option value="packaging">Collector Boxes</option>
                        </select>
                      </div>
                    </div>

                    {/* Status Toggles: Featured, New Drop, Best Seller */}
                    <div className="pt-3 border-t border-white/10 flex flex-wrap items-center gap-6">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={!!productForm.isFeatured}
                          onChange={(e) => setProductForm({ ...productForm, isFeatured: e.target.checked })}
                          className="w-4 h-4 accent-lime-400"
                        />
                        <span className="text-xs uppercase text-neutral-300">Feature on Homepage</span>
                      </label>

                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={!!productForm.isNew}
                          onChange={(e) => setProductForm({ ...productForm, isNew: e.target.checked })}
                          className="w-4 h-4 accent-blue-400"
                        />
                        <span className="text-xs uppercase text-neutral-300">Mark as New Drop</span>
                      </label>

                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={!!productForm.isBestSeller}
                          onChange={(e) => setProductForm({ ...productForm, isBestSeller: e.target.checked })}
                          className="w-4 h-4 accent-amber-400"
                        />
                        <span className="text-xs uppercase text-neutral-300">Flag as Best Seller</span>
                      </label>
                    </div>
                  </div>
                )}

                {/* ================= TAB 2: PRICING & NEGOTIATION ================= */}
                {activeFormTab === 'pricing' && (
                  <div className="space-y-6">
                    <div>
                      <h4 className="font-display font-bold text-sm uppercase text-white mb-1">
                        Storefront Selling Prices
                      </h4>
                      <p className="text-[11px] text-neutral-400 mb-3">
                        Enter active customer purchase prices. Nigerian Naira is the primary currency.
                      </p>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <div>
                          <label className="block text-[10px] uppercase text-neutral-400 mb-1 font-bold">
                            Selling Price (NGN ₦) *
                          </label>
                          <input
                            type="number"
                            required
                            value={productForm.priceNGN || ''}
                            onChange={(e) => {
                              const ngn = Number(e.target.value);
                              // Auto calculate approximate USD and GBP if empty
                              setProductForm({
                                ...productForm,
                                priceNGN: ngn,
                                priceUSD: productForm.priceUSD || Math.round(ngn / 1450),
                                priceGBP: productForm.priceGBP || Math.round(ngn / 1850),
                              });
                            }}
                            placeholder="55000"
                            className="w-full p-2.5 bg-black border border-white/20 text-white focus:border-white focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] uppercase text-neutral-400 mb-1 font-bold">
                            Selling Price (USD $)
                          </label>
                          <input
                            type="number"
                            value={productForm.priceUSD || ''}
                            onChange={(e) => setProductForm({ ...productForm, priceUSD: Number(e.target.value) })}
                            placeholder="38"
                            className="w-full p-2.5 bg-black border border-white/20 text-white focus:border-white focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] uppercase text-neutral-400 mb-1 font-bold">
                            Selling Price (GBP £)
                          </label>
                          <input
                            type="number"
                            value={productForm.priceGBP || ''}
                            onChange={(e) => setProductForm({ ...productForm, priceGBP: Number(e.target.value) })}
                            placeholder="30"
                            className="w-full p-2.5 bg-black border border-white/20 text-white focus:border-white focus:outline-none"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Compare-At / Original Reference Prices */}
                    <div className="pt-4 border-t border-white/10">
                      <h4 className="font-display font-bold text-sm uppercase text-white mb-1">
                        Compare-At Prices (Strikethrough Reference)
                      </h4>
                      <p className="text-[11px] text-neutral-400 mb-3">
                        Set higher original prices to display promotional discounts or archival valuation strike-throughs on product pages.
                      </p>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <div>
                          <label className="block text-[10px] uppercase text-neutral-400 mb-1">
                            Compare-At (NGN ₦)
                          </label>
                          <input
                            type="number"
                            value={productForm.compareAtPriceNGN || ''}
                            onChange={(e) => setProductForm({ ...productForm, compareAtPriceNGN: Number(e.target.value) || undefined })}
                            placeholder="e.g. 70000"
                            className="w-full p-2.5 bg-black border border-white/20 text-white focus:border-white focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] uppercase text-neutral-400 mb-1">
                            Compare-At (USD $)
                          </label>
                          <input
                            type="number"
                            value={productForm.compareAtPriceUSD || ''}
                            onChange={(e) => setProductForm({ ...productForm, compareAtPriceUSD: Number(e.target.value) || undefined })}
                            placeholder="e.g. 50"
                            className="w-full p-2.5 bg-black border border-white/20 text-white focus:border-white focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] uppercase text-neutral-400 mb-1">
                            Compare-At (GBP £)
                          </label>
                          <input
                            type="number"
                            value={productForm.compareAtPriceGBP || ''}
                            onChange={(e) => setProductForm({ ...productForm, compareAtPriceGBP: Number(e.target.value) || undefined })}
                            placeholder="e.g. 40"
                            className="w-full p-2.5 bg-black border border-white/20 text-white focus:border-white focus:outline-none"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Price Negotiation Settings */}
                    <div className="p-4 bg-neutral-900 border border-white/10 space-y-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="text-xs uppercase text-white font-bold block">
                            VIP Client Negotiation & Private Offers
                          </span>
                          <span className="text-[11px] text-neutral-400 block mt-0.5">
                            Allows private clients and collectors to submit bespoke price offers for this piece.
                          </span>
                        </div>
                        <input
                          type="checkbox"
                          checked={!!productForm.allowNegotiation}
                          onChange={(e) => setProductForm({ ...productForm, allowNegotiation: e.target.checked })}
                          className="w-4 h-4 accent-lime-400 cursor-pointer"
                        />
                      </div>

                      {productForm.allowNegotiation && (
                        <div className="pt-3 border-t border-white/10 flex flex-wrap items-center gap-4">
                          <label className="text-[10px] uppercase text-neutral-300">
                            Minimum Acceptable Offer (% of Selling Price):
                          </label>
                          <input
                            type="number"
                            min={50}
                            max={100}
                            value={productForm.minOfferPercentage || 80}
                            onChange={(e) => setProductForm({ ...productForm, minOfferPercentage: Number(e.target.value) })}
                            className="w-20 p-2 bg-black border border-white/20 text-white text-center focus:border-white focus:outline-none"
                          />
                          <span className="text-[11px] text-lime-400 font-mono">
                            Minimum Acceptable: ₦{Math.round(((productForm.priceNGN || 55000) * (productForm.minOfferPercentage || 80)) / 100).toLocaleString()}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* ================= TAB 3: INVENTORY & SIZING ================= */}
                {activeFormTab === 'inventory' && (
                  <div className="space-y-6">
                    {/* Stock & Availability */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] uppercase text-neutral-400 mb-1 font-bold">
                          Atelier Stock Quantity
                        </label>
                        <input
                          type="number"
                          value={productForm.stockQuantity ?? 15}
                          onChange={(e) => setProductForm({ ...productForm, stockQuantity: Number(e.target.value) })}
                          className="w-full p-2.5 bg-black border border-white/20 text-white focus:border-white focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] uppercase text-neutral-400 mb-1 font-bold">
                          Availability Status
                        </label>
                        <select
                          value={productForm.availability || 'in_stock'}
                          onChange={(e) => setProductForm({ ...productForm, availability: e.target.value as any })}
                          className="w-full p-2.5 bg-black border border-white/20 text-white focus:border-white focus:outline-none"
                        >
                          <option value="in_stock">In Stock (Available for Dispatch)</option>
                          <option value="low_stock">Low Stock (Scarcity Notification)</option>
                          <option value="out_of_stock">Out of Stock (Sold Out)</option>
                          <option value="preorder_only">Pre-Order Only (Atelier Assembly)</option>
                          <option value="archived">Archived (Safe Hidden State)</option>
                        </select>
                      </div>
                    </div>

                    {/* Color Swatch & Color Name */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] uppercase text-neutral-400 mb-1 font-bold">
                          Primary Color Name
                        </label>
                        <input
                          type="text"
                          value={productForm.color || ''}
                          onChange={(e) => setProductForm({ ...productForm, color: e.target.value })}
                          placeholder="Obsidian Black / Bone White"
                          className="w-full p-2.5 bg-black border border-white/20 text-white focus:border-white focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] uppercase text-neutral-400 mb-1 font-bold">
                          Color Hex (#)
                        </label>
                        <div className="flex gap-2 items-center">
                          <input
                            type="color"
                            value={productForm.colorHex || '#080808'}
                            onChange={(e) => setProductForm({ ...productForm, colorHex: e.target.value })}
                            className="w-10 h-10 border border-white/20 bg-transparent cursor-pointer"
                          />
                          <input
                            type="text"
                            value={productForm.colorHex || '#080808'}
                            onChange={(e) => setProductForm({ ...productForm, colorHex: e.target.value })}
                            className="flex-1 p-2.5 bg-black border border-white/20 text-white uppercase focus:border-white focus:outline-none"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Sizing Tags */}
                    <div>
                      <label className="block text-[10px] uppercase text-neutral-400 mb-1.5 font-bold">
                        Garment Sizes Available
                      </label>
                      <div className="flex flex-wrap gap-1.5 mb-3">
                        {['XS', 'S', 'M', 'L', 'XL', 'XXL', '3XL', 'Custom'].map((sz) => {
                          const active = (productForm.sizes || []).includes(sz);
                          return (
                            <button
                              key={sz}
                              type="button"
                              onClick={() => {
                                const current = productForm.sizes || [];
                                const next = active ? current.filter((s) => s !== sz) : [...current, sz];
                                setProductForm({ ...productForm, sizes: next });
                              }}
                              className={`px-3 py-1.5 text-xs font-mono uppercase font-bold border transition-colors cursor-pointer ${
                                active
                                  ? 'bg-white text-black border-white'
                                  : 'border-white/20 text-neutral-400 hover:text-white hover:border-white/50'
                              }`}
                            >
                              {sz}
                            </button>
                          );
                        })}
                      </div>

                      {/* Add Custom Sizing */}
                      <div className="flex gap-2 max-w-sm">
                        <input
                          type="text"
                          value={newCustomSize}
                          onChange={(e) => setNewCustomSize(e.target.value)}
                          placeholder="Add custom size (e.g. 42R or Tailored)"
                          className="flex-1 p-2 text-xs bg-black border border-white/20 text-white focus:border-white focus:outline-none"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            if (!newCustomSize.trim()) return;
                            const s = newCustomSize.trim().toUpperCase();
                            if (!(productForm.sizes || []).includes(s)) {
                              setProductForm({ ...productForm, sizes: [...(productForm.sizes || []), s] });
                            }
                            setNewCustomSize('');
                          }}
                          className="px-3 py-2 bg-white/10 hover:bg-white hover:text-black text-xs font-bold uppercase transition-colors cursor-pointer"
                        >
                          + Add Size
                        </button>
                      </div>
                    </div>

                    {/* Fit & Silhouette */}
                    <div>
                      <label className="block text-[10px] uppercase text-neutral-400 mb-1 font-bold">
                        Silhouette & Fit Profile
                      </label>
                      <input
                        type="text"
                        value={productForm.fit || ''}
                        onChange={(e) => setProductForm({ ...productForm, fit: e.target.value })}
                        placeholder="Relaxed boxy streetwear cut with dropped shoulders."
                        className="w-full p-2.5 bg-black border border-white/20 text-white focus:border-white focus:outline-none"
                      />
                    </div>
                  </div>
                )}

                {/* ================= TAB 4: PRE-ORDER & PRODUCTION ================= */}
                {activeFormTab === 'preorder' && (
                  <div className="space-y-6">
                    <div className="p-4 bg-cyan-950/40 border border-cyan-500/40 space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="text-xs uppercase text-cyan-300 font-bold block">
                            Atelier Pre-Order Allocation
                          </span>
                          <span className="text-[11px] text-neutral-400 block mt-0.5">
                            Enable limited batch reservations before formal garment cutting and stitching.
                          </span>
                        </div>
                        <input
                          type="checkbox"
                          checked={!!productForm.isPreOrder}
                          onChange={(e) => setProductForm({ ...productForm, isPreOrder: e.target.checked })}
                          className="w-4 h-4 accent-cyan-400 cursor-pointer"
                        />
                      </div>

                      {productForm.isPreOrder && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3 border-t border-cyan-500/20">
                          <div>
                            <label className="block text-[10px] uppercase text-neutral-300 mb-1 font-bold">
                              Maximum Pre-Order Batch Limit
                            </label>
                            <input
                              type="number"
                              value={productForm.preOrderLimit || 50}
                              onChange={(e) => setProductForm({ ...productForm, preOrderLimit: Number(e.target.value) })}
                              className="w-full p-2 bg-black border border-white/20 text-white focus:border-white focus:outline-none"
                            />
                          </div>

                          <div>
                            <label className="block text-[10px] uppercase text-neutral-300 mb-1 font-bold">
                              Current Reserved Count
                            </label>
                            <input
                              type="number"
                              value={productForm.preOrderCount || 0}
                              onChange={(e) => setProductForm({ ...productForm, preOrderCount: Number(e.target.value) })}
                              className="w-full p-2 bg-black border border-white/20 text-white focus:border-white focus:outline-none"
                            />
                          </div>

                          <div>
                            <label className="block text-[10px] uppercase text-neutral-300 mb-1 font-bold">
                              Production Stage Status
                            </label>
                            <select
                              value={productForm.productionStatus || 'Atelier Pattern Drafting'}
                              onChange={(e) => setProductForm({ ...productForm, productionStatus: e.target.value })}
                              className="w-full p-2 bg-black border border-white/20 text-white focus:border-white focus:outline-none"
                            >
                              <option value="Atelier Fabric Sourcing">Atelier Fabric Sourcing</option>
                              <option value="Atelier Pattern Drafting">Atelier Pattern Drafting</option>
                              <option value="Screen Printing & Puff Ink Curing">Screen Printing & Puff Ink Curing</option>
                              <option value="Hand Stitching & Tailoring">Hand Stitching & Tailoring</option>
                              <option value="Rigid Box Packaging & QC">Rigid Box Packaging & QC</option>
                              <option value="Ready for Courier Dispatch">Ready for Courier Dispatch</option>
                            </select>
                          </div>

                          <div>
                            <label className="block text-[10px] uppercase text-neutral-300 mb-1 font-bold">
                              Estimated Delivery Timeline
                            </label>
                            <input
                              type="text"
                              value={productForm.estimatedDelivery || ''}
                              onChange={(e) => setProductForm({ ...productForm, estimatedDelivery: e.target.value })}
                              placeholder="e.g. Ships mid-November 2026"
                              className="w-full p-2 bg-black border border-white/20 text-white focus:border-white focus:outline-none"
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* ================= TAB 5: FIREBASE STORAGE IMAGES ================= */}
                {activeFormTab === 'images' && (
                  <div className="space-y-5">
                    <div>
                      <h4 className="font-display font-bold text-sm uppercase text-white mb-1">
                        Garment Image Management (Firebase Storage)
                      </h4>
                      <p className="text-[11px] text-neutral-400">
                        Upload high-resolution photography. The first image (#1) is automatically used as the <strong>Primary Hero Thumbnail</strong> across the 3KO store catalog.
                      </p>
                    </div>

                    {/* Drag & Drop File Upload Zone */}
                    <div className="border-2 border-dashed border-white/25 hover:border-lime-400 transition-colors p-6 bg-white/5 text-center relative group cursor-pointer">
                      <input
                        type="file"
                        multiple
                        accept="image/*"
                        disabled={isUploadingImage}
                        onChange={async (e) => {
                          const files = e.target.files;
                          if (!files || files.length === 0) return;
                          setIsUploadingImage(true);
                          setImageUploadError(null);
                          try {
                            const uploadedUrls: string[] = [];
                            for (let i = 0; i < files.length; i++) {
                              const url = await uploadProductImageFile(files[i], productForm.slug || 'garment');
                              uploadedUrls.push(url);
                            }
                            setProductForm((prev) => ({
                              ...prev,
                              images: [...(prev.images || []), ...uploadedUrls],
                            }));
                          } catch (err: any) {
                            setImageUploadError('Some files could not be uploaded. Check image formats.');
                          } finally {
                            setIsUploadingImage(false);
                            e.target.value = '';
                          }
                        }}
                        className="absolute inset-0 opacity-0 w-full h-full cursor-pointer z-10"
                      />
                      <div className="flex flex-col items-center justify-center gap-2">
                        <Upload className={`w-8 h-8 ${isUploadingImage ? 'text-lime-400 animate-bounce' : 'text-neutral-400 group-hover:text-white'}`} />
                        <div>
                          {isUploadingImage ? (
                            <span className="text-lime-400 font-bold uppercase tracking-wider">
                              Uploading to Firebase Storage...
                            </span>
                          ) : (
                            <>
                              <span className="font-bold text-white uppercase tracking-wider block">
                                Choose or Drag & Drop Garment Photographs
                              </span>
                              <span className="text-[10px] text-neutral-400 block mt-0.5">
                                Supports multiple PNG, JPG, WEBP. Synchronized to cloud storage.
                              </span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Manual Image URL Adder */}
                    <div className="flex items-center gap-2">
                      <input
                        type="url"
                        value={manualImageUrl}
                        onChange={(e) => setManualImageUrl(e.target.value)}
                        placeholder="Or paste external/existing CDN image URL (e.g. /images/...)"
                        className="flex-1 p-2 text-xs font-mono bg-black border border-white/20 text-white focus:border-white focus:outline-none"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          if (!manualImageUrl.trim()) return;
                          setProductForm((prev) => ({
                            ...prev,
                            images: [...(prev.images || []), manualImageUrl.trim()],
                          }));
                          setManualImageUrl('');
                        }}
                        className="px-4 py-2 bg-white/10 hover:bg-white hover:text-black text-xs font-bold uppercase transition-colors cursor-pointer"
                      >
                        + Add URL
                      </button>
                    </div>

                    {imageUploadError && (
                      <div className="p-3 bg-red-950/60 border border-red-500/40 text-red-300 text-xs flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                        <span>{imageUploadError}</span>
                      </div>
                    )}

                    {/* Image Gallery Thumbnails Grid */}
                    {productForm.images && productForm.images.length > 0 ? (
                      <div className="space-y-2">
                        <div className="text-[10px] uppercase text-neutral-400 tracking-wider">
                          Reorder, Set Primary, or Replace Images:
                        </div>
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                          {productForm.images.map((imgUrl, idx) => {
                            const isPrimary = idx === 0;
                            return (
                              <div
                                key={idx}
                                className={`group/card relative aspect-[3/4] border overflow-hidden flex flex-col justify-between ${
                                  isPrimary ? 'border-lime-400 ring-2 ring-lime-400/50 bg-black' : 'border-white/20 bg-neutral-900'
                                }`}
                              >
                                <img
                                  src={imgUrl}
                                  alt={`Product shot ${idx + 1}`}
                                  className="w-full h-full object-cover"
                                />

                                {/* Badge */}
                                <div className="absolute top-1.5 left-1.5 z-10 flex flex-col gap-1">
                                  {isPrimary ? (
                                    <span className="px-1.5 py-0.5 text-[9px] font-mono font-bold bg-lime-400 text-black uppercase flex items-center gap-1 shadow-md">
                                      <Star className="w-2.5 h-2.5 fill-black" />
                                      <span>PRIMARY</span>
                                    </span>
                                  ) : (
                                    <span className="px-1.5 py-0.5 text-[9px] font-mono bg-black/80 text-neutral-300 border border-white/20">
                                      #{idx + 1}
                                    </span>
                                  )}
                                </div>

                                {/* Quick action bar overlay */}
                                <div className="absolute inset-x-0 bottom-0 p-1.5 bg-black/95 backdrop-blur-xs flex items-center justify-between gap-1 opacity-90 group-hover/card:opacity-100 transition-opacity">
                                  {!isPrimary && (
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setProductForm((prev) => {
                                          const arr = [...(prev.images || [])];
                                          const [sel] = arr.splice(idx, 1);
                                          arr.unshift(sel);
                                          return { ...prev, images: arr };
                                        });
                                      }}
                                      className="p-1 hover:text-lime-300 text-neutral-400 text-[10px] font-mono uppercase"
                                      title="Set as Hero / Primary Image"
                                    >
                                      <Star className="w-3.5 h-3.5" />
                                    </button>
                                  )}

                                  {idx > 0 && (
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setProductForm((prev) => {
                                          const arr = [...(prev.images || [])];
                                          const temp = arr[idx];
                                          arr[idx] = arr[idx - 1];
                                          arr[idx - 1] = temp;
                                          return { ...prev, images: arr };
                                        });
                                      }}
                                      className="p-1 hover:text-white text-neutral-400"
                                      title="Move Left"
                                    >
                                      <ArrowLeft className="w-3.5 h-3.5" />
                                    </button>
                                  )}

                                  {idx < (productForm.images?.length || 0) - 1 && (
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setProductForm((prev) => {
                                          const arr = [...(prev.images || [])];
                                          const temp = arr[idx];
                                          arr[idx] = arr[idx + 1];
                                          arr[idx + 1] = temp;
                                          return { ...prev, images: arr };
                                        });
                                      }}
                                      className="p-1 hover:text-white text-neutral-400"
                                      title="Move Right"
                                    >
                                      <ArrowRight className="w-3.5 h-3.5" />
                                    </button>
                                  )}

                                  {/* Replace Slot */}
                                  <label
                                    className="p-1 hover:text-amber-300 text-neutral-400 cursor-pointer"
                                    title="Replace Image File"
                                  >
                                    <RotateCcw className="w-3.5 h-3.5" />
                                    <input
                                      type="file"
                                      accept="image/*"
                                      className="hidden"
                                      onChange={async (e) => {
                                        const f = e.target.files?.[0];
                                        if (!f) return;
                                        setIsUploadingImage(true);
                                        try {
                                          const newUrl = await uploadProductImageFile(f, productForm.slug || 'garment');
                                          setProductForm((prev) => {
                                            const arr = [...(prev.images || [])];
                                            arr[idx] = newUrl;
                                            return { ...prev, images: arr };
                                          });
                                        } finally {
                                          setIsUploadingImage(false);
                                          e.target.value = '';
                                        }
                                      }}
                                    />
                                  </label>

                                  {/* Delete File */}
                                  <button
                                    type="button"
                                    onClick={async () => {
                                      const targetUrl = productForm.images?.[idx];
                                      if (targetUrl) {
                                        deleteImageFile(targetUrl).catch(() => {});
                                      }
                                      setProductForm((prev) => ({
                                        ...prev,
                                        images: (prev.images || []).filter((_, i) => i !== idx),
                                      }));
                                    }}
                                    className="p-1 hover:text-red-400 text-neutral-400"
                                    title="Delete Image"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    ) : (
                      <div className="py-8 text-center text-xs font-mono text-neutral-500 border border-white/5 bg-black/20">
                        No product images attached. Please upload at least one lookbook photo.
                      </div>
                    )}
                  </div>
                )}

                {/* ================= TAB 6: CRAFT & PACKAGING ================= */}
                {activeFormTab === 'details' && (
                  <div className="space-y-4">
                    <div>
                      <label className="block text-[10px] uppercase text-neutral-400 mb-1 font-bold">
                        Detailed Garment Description
                      </label>
                      <textarea
                        rows={3}
                        value={productForm.description || ''}
                        onChange={(e) => setProductForm({ ...productForm, description: e.target.value })}
                        placeholder="The definitive 3KO graphic shirt. Illustrated with the cable-stayed Lekki-Ikoyi Link Bridge skyline..."
                        className="w-full p-2.5 bg-black border border-white/20 text-white font-sans text-xs focus:border-white focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] uppercase text-neutral-400 mb-1 font-bold">
                        Editorial Campaign Note
                      </label>
                      <input
                        type="text"
                        value={productForm.editorialNote || ''}
                        onChange={(e) => setProductForm({ ...productForm, editorialNote: e.target.value })}
                        placeholder="As seen in the official 3KO campaign overlooking the Ikoyi waterfront."
                        className="w-full p-2.5 bg-black border border-white/20 text-white focus:border-white focus:outline-none"
                      />
                    </div>

                    {/* Fabric Details (1 per line) */}
                    <div>
                      <label className="block text-[10px] uppercase text-neutral-400 mb-1 font-bold">
                        Fabric & Construction Specs (One specification per line)
                      </label>
                      <textarea
                        rows={3}
                        value={(productForm.fabricDetails || []).join('\n')}
                        onChange={(e) =>
                          setProductForm({
                            ...productForm,
                            fabricDetails: e.target.value.split('\n').filter((l) => l.trim()),
                          })
                        }
                        placeholder="100% ringspun organic cotton jersey (280 GSM)&#10;High-density screen print with tactile matte puff ink&#10;Thick 1.25 inch rib collar"
                        className="w-full p-2.5 bg-black border border-white/20 text-white text-xs focus:border-white focus:outline-none"
                      />
                    </div>

                    {/* Care Instructions (1 per line) */}
                    <div>
                      <label className="block text-[10px] uppercase text-neutral-400 mb-1 font-bold">
                        Care Instructions (One instruction per line)
                      </label>
                      <textarea
                        rows={2}
                        value={(productForm.careInstructions || []).join('\n')}
                        onChange={(e) =>
                          setProductForm({
                            ...productForm,
                            careInstructions: e.target.value.split('\n').filter((l) => l.trim()),
                          })
                        }
                        placeholder="Wash inside out in cold water&#10;Line dry only; avoid direct heat"
                        className="w-full p-2.5 bg-black border border-white/20 text-white text-xs focus:border-white focus:outline-none"
                      />
                    </div>

                    {/* Architectural Packaging Note */}
                    <div>
                      <label className="block text-[10px] uppercase text-neutral-400 mb-1 font-bold">
                        Architectural Collector Box Note
                      </label>
                      <input
                        type="text"
                        value={productForm.packagingNote || ''}
                        onChange={(e) => setProductForm({ ...productForm, packagingNote: e.target.value })}
                        placeholder="Optional recommended 1200 GSM Matte Obsidian collector box with serialized certificate."
                        className="w-full p-2.5 bg-black border border-white/20 text-white focus:border-white focus:outline-none"
                      />
                    </div>
                  </div>
                )}

                {/* Modal Footer Controls */}
                <div className="pt-5 border-t border-white/10 flex items-center justify-between">
                  <div className="text-[10px] text-neutral-400 uppercase">
                    Changes are synced immediately to live Firestore
                  </div>
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => setIsNewProductModalOpen(false)}
                      className="px-5 py-2.5 border border-white/20 text-neutral-300 hover:text-white uppercase font-bold text-xs transition-colors cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-7 py-2.5 bg-white text-black font-bold uppercase text-xs hover:bg-neutral-200 transition-colors shadow-lg cursor-pointer"
                    >
                      {editingProduct ? 'Update Garment in Catalog' : 'Publish Garment to Catalog'}
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* ==================================================== */}
        {/* MODAL 3: SAFE DELETION CONFIRMATION PROTOCOL */}
        {/* ==================================================== */}
        {productToDelete && (
          <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
            <div className={`max-w-md w-full border p-6 sm:p-8 shadow-2xl ${isDark ? 'bg-[#121212] border-white/20 text-white' : 'bg-white border-black/20 text-neutral-900'}`}>
              <div className="flex items-center gap-2 text-amber-400 font-mono text-[10px] uppercase tracking-widest font-bold mb-2">
                <AlertCircle className="w-4 h-4" />
                <span>SAFE CATALOG DELETION PROTOCOL</span>
              </div>

              <h3 className="font-display font-black text-xl uppercase tracking-tight mb-2">
                REMOVE &ldquo;{productToDelete.name}&rdquo;?
              </h3>

              <div className="flex items-center gap-3 p-3 bg-white/5 border border-white/10 my-4">
                <img
                  src={productToDelete.images?.[0] || '/images/apparel/look_001_ikoyi_tee_cap.jpg'}
                  alt={productToDelete.name}
                  className="w-12 h-14 object-cover border border-white/10 shrink-0"
                />
                <div className="text-xs font-mono">
                  <strong className="block text-white line-clamp-1">{productToDelete.name}</strong>
                  <span className="text-neutral-400 block text-[10px]">SKU: {productToDelete.sku || productToDelete.slug}</span>
                  <span className="text-neutral-400 block text-[10px]">Price: ₦{productToDelete.priceNGN?.toLocaleString()}</span>
                </div>
              </div>

              <p className="text-xs text-neutral-300 font-sans leading-relaxed mb-6">
                If this piece was previously purchased by customers, permanent deletion will break image links and order references. We strongly recommend <strong>Archiving</strong> instead, which safely hides it from active drops while keeping all records intact.
              </p>

              <div className="space-y-2.5">
                <button
                  type="button"
                  onClick={() => {
                    archiveProduct(productToDelete.id, true);
                    setProductToDelete(null);
                  }}
                  className="w-full py-3 bg-amber-400 hover:bg-amber-300 text-black font-bold font-mono text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer shadow-md"
                >
                  <Archive className="w-4 h-4" />
                  <span>Archive Piece Instead (Recommended)</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    deleteProduct(productToDelete.id);
                    setProductToDelete(null);
                  }}
                  className="w-full py-2.5 border border-red-500/50 text-red-400 hover:bg-red-500/10 font-mono text-xs uppercase tracking-wider transition-colors cursor-pointer"
                >
                  Permanently Delete from Database
                </button>

                <button
                  type="button"
                  onClick={() => setProductToDelete(null)}
                  className="w-full py-2 text-neutral-400 hover:text-white font-mono text-xs uppercase tracking-wider transition-colors cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
