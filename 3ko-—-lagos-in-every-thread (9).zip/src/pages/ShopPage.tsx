import React, { useState, useMemo } from 'react';
import { ProductCard } from '../components/ProductCard';
import { useShop } from '../context/ShopContext';
import { SlidersHorizontal, X } from 'lucide-react';

interface ShopPageProps {
  initialLine?: 'all' | 'street' | 'form' | 'edition';
}

export const ShopPage: React.FC<ShopPageProps> = ({ initialLine = 'all' }) => {
  const { currentRoute, products, collections, theme } = useShop();

  const isDark = theme === 'dark';

  // Determine line filter from route or prop
  const detectedLine = currentRoute === '/street' ? 'street' : currentRoute === '/form' ? 'form' : initialLine;

  const [selectedLine, setSelectedLine] = useState<'all' | 'street' | 'form' | 'edition'>(detectedLine);
  const [selectedCollection, setSelectedCollection] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'featured' | 'price-low' | 'price-high' | 'name'>('featured');
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);

  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      if (p.isArchived) return false;
      if (selectedLine !== 'all' && p.line !== selectedLine) return false;
      if (selectedCollection !== 'all' && p.collectionId !== selectedCollection) return false;
      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-low') return a.priceNGN - b.priceNGN;
      if (sortBy === 'price-high') return b.priceNGN - a.priceNGN;
      if (sortBy === 'name') return a.name.localeCompare(b.name);
      return (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0);
    });
  }, [products, selectedLine, selectedCollection, sortBy]);

  const activeCollectionObj = collections.find((c) => c.id === selectedCollection);

  return (
    <div className={`w-full pt-24 sm:pt-28 pb-24 px-6 sm:px-10 lg:px-12 min-h-screen transition-colors duration-300 ${
      isDark ? 'bg-[#080808] text-white' : 'bg-[#F9F8F5] text-neutral-900'
    }`}>
      <div className="max-w-[1440px] mx-auto">
        {/* Page Editorial Header */}
        <div className={`mb-12 pb-6 border-b flex flex-col md:flex-row md:items-end justify-between gap-6 ${
          isDark ? 'border-white/10' : 'border-black/10'
        }`}>
          <div>
            <span className={`text-xs uppercase tracking-[0.25em] font-semibold block mb-1 font-mono ${
              isDark ? 'text-neutral-400' : 'text-neutral-500'
            }`}>
              THE 3KO ARCHIVE & CATALOG
            </span>
            <h1 className={`font-display font-black text-4xl sm:text-5xl lg:text-6xl uppercase tracking-tight ${
              isDark ? 'text-white' : 'text-neutral-900'
            }`}>
              {selectedLine === 'street'
                ? '3KO STREET'
                : selectedLine === 'form'
                ? '3KO FORM'
                : selectedCollection !== 'all' && activeCollectionObj
                ? activeCollectionObj.fullName
                : 'ALL PIECES'}
            </h1>
            <p className={`text-sm font-normal max-w-xl mt-2 leading-relaxed ${
              isDark ? 'text-neutral-300' : 'text-neutral-600'
            }`}>
              {selectedLine === 'street'
                ? 'Bold. Urban. Unapologetic. Contemporary Lagosian streetwear crafted in ultra-dense natural textiles.'
                : selectedLine === 'form'
                ? 'Clean. Refined. Versatile. Smart-casual tailored silhouettes engineered for tropical poise and global movement.'
                : 'Lagos in every thread. Discover contemporary apparel connecting ancient trade with modern African creative ambition.'}
            </p>
          </div>

          {/* Filter / Sort Row for Desktop */}
          <div className="flex items-center gap-4">
            <div className={`flex items-center gap-2 text-xs font-mono ${
              isDark ? 'text-neutral-400' : 'text-neutral-600'
            }`}>
              <span>SORT:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className={`border px-3 py-1.5 text-xs focus:outline-none font-mono ${
                  isDark
                    ? 'bg-[#141414] border-white/20 text-white focus:border-white'
                    : 'bg-white border-black/20 text-black focus:border-black'
                }`}
              >
                <option value="featured">Featured Drops</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="name">Alphabetical</option>
              </select>
            </div>

            <button
              onClick={() => setMobileFiltersOpen(!mobileFiltersOpen)}
              className={`lg:hidden flex items-center gap-2 text-xs uppercase tracking-wider font-semibold border px-3 py-1.5 ${
                isDark ? 'border-white/20 text-white' : 'border-black/20 text-black'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>Filter</span>
            </button>
          </div>
        </div>

        {/* Filter Bar */}
        <div className="mb-10 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          {/* Line Segmented Controls */}
          <div className="flex flex-wrap items-center gap-2 text-xs uppercase tracking-widest font-semibold">
            {[
              { id: 'all', label: 'All Catalog' },
              { id: 'street', label: '3KO Street' },
              { id: 'form', label: '3KO Form' },
              { id: 'edition', label: 'Packaging & Editions' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setSelectedLine(tab.id as any)}
                className={`px-4 py-2 border transition-all cursor-pointer ${
                  selectedLine === tab.id
                    ? isDark
                      ? 'border-white bg-white text-[#080808] font-bold'
                      : 'border-black bg-black text-white font-bold'
                    : isDark
                    ? 'border-white/10 bg-[#121212] text-neutral-400 hover:text-white hover:border-white/30'
                    : 'border-black/10 bg-neutral-100 text-neutral-600 hover:text-black hover:border-black/30'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Collection Filter Quick Select */}
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
            <button
              onClick={() => setSelectedCollection('all')}
              className={`px-3 py-1 text-[11px] font-mono uppercase tracking-wider shrink-0 transition-colors ${
                selectedCollection === 'all'
                  ? isDark
                    ? 'text-white border-b-2 border-white font-bold'
                    : 'text-black border-b-2 border-black font-bold'
                  : 'text-neutral-500 hover:text-neutral-400'
              }`}
            >
              All Locations
            </button>
            {collections.map((c) => (
              <button
                key={c.id}
                onClick={() => setSelectedCollection(c.id)}
                className={`px-2.5 py-1 text-[11px] font-mono uppercase tracking-wider shrink-0 transition-colors flex items-center gap-1.5 ${
                  selectedCollection === c.id
                    ? isDark
                      ? 'text-white border-b-2 border-white font-bold'
                      : 'text-black border-b-2 border-black font-bold'
                    : 'text-neutral-500 hover:text-neutral-400'
                }`}
              >
                <span
                  className="w-1.5 h-1.5 rounded-full"
                  style={{ backgroundColor: c.colorHex }}
                />
                <span>{c.numberStr} {c.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Active Filter Chips if any */}
        {(selectedLine !== 'all' || selectedCollection !== 'all') && (
          <div className={`flex items-center gap-2 mb-8 text-xs font-mono ${
            isDark ? 'text-neutral-400' : 'text-neutral-600'
          }`}>
            <span>FILTERED BY:</span>
            {selectedLine !== 'all' && (
              <span className={`border px-2.5 py-1 flex items-center gap-1.5 uppercase ${
                isDark ? 'bg-[#181818] border-white/15 text-white' : 'bg-neutral-200 border-black/15 text-black'
              }`}>
                Line: {selectedLine}
                <button onClick={() => setSelectedLine('all')}>
                  <X className="w-3 h-3 hover:text-red-500 cursor-pointer" />
                </button>
              </span>
            )}
            {selectedCollection !== 'all' && activeCollectionObj && (
              <span className={`border px-2.5 py-1 flex items-center gap-1.5 uppercase ${
                isDark ? 'bg-[#181818] border-white/15 text-white' : 'bg-neutral-200 border-black/15 text-black'
              }`}>
                Location: {activeCollectionObj.name}
                <button onClick={() => setSelectedCollection('all')}>
                  <X className="w-3 h-3 hover:text-red-500 cursor-pointer" />
                </button>
              </span>
            )}
            <button
              onClick={() => {
                setSelectedLine('all');
                setSelectedCollection('all');
              }}
              className="text-neutral-500 hover:underline ml-2 cursor-pointer"
            >
              Reset All
            </button>
          </div>
        )}

        {/* Product Grid: Spacious 3-column layout eliminating crowdedness */}
        {filteredProducts.length === 0 ? (
          <div className={`py-20 text-center border ${
            isDark ? 'border-white/10 bg-[#101010]' : 'border-black/10 bg-white'
          }`}>
            <h3 className={`font-display font-bold uppercase text-xl mb-2 ${
              isDark ? 'text-white' : 'text-black'
            }`}>
              No garments found matching filters
            </h3>
            <p className={`text-xs font-sans mb-6 ${
              isDark ? 'text-neutral-400' : 'text-neutral-600'
            }`}>
              Try adjusting your category or location selection to view our other collections.
            </p>
            <button
              onClick={() => {
                setSelectedLine('all');
                setSelectedCollection('all');
              }}
              className={`px-6 py-2.5 text-xs font-bold uppercase tracking-widest transition-colors cursor-pointer ${
                isDark ? 'bg-white text-black hover:bg-neutral-200' : 'bg-black text-white hover:bg-neutral-800'
              }`}
            >
              View All Garments
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 sm:gap-10 lg:gap-12">
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}

        {/* Bottom Catalog Note */}
        <div className={`mt-16 pt-8 border-t text-center text-xs font-mono ${
          isDark ? 'border-white/10 text-neutral-500' : 'border-black/10 text-neutral-500'
        }`}>
          SHOWING {filteredProducts.length} OF {products.length} ITEMS · CRAFTED IN LAGOS, NIGERIA
        </div>
      </div>
    </div>
  );
};
