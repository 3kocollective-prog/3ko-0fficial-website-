import React from 'react';
import { LAGOS_COLLECTIONS } from '../data/collections';
import { useShop } from '../context/ShopContext';
import { ArrowRight, Compass, MapPin } from 'lucide-react';

export const LagosCulturalPage: React.FC = () => {
  const { navigateTo, theme } = useShop();
  const isDark = theme === 'dark';

  return (
    <div className={`w-full pt-24 pb-20 px-6 sm:px-10 lg:px-12 transition-colors duration-300 ${
      isDark ? 'bg-[#080808] text-white' : 'bg-[#F9F8F5] text-neutral-900'
    }`}>
      <div className="max-w-[1440px] mx-auto">
        {/* Cinematic Header */}
        <div className="mb-16">
          <span className={`text-xs uppercase tracking-[0.25em] font-mono block mb-2 font-semibold ${
            isDark ? 'text-neutral-400' : 'text-neutral-500'
          }`}>
            THE CITY ARCHIVE
          </span>
          <h1 className={`font-display font-black text-5xl sm:text-7xl lg:text-8xl uppercase tracking-tight mb-4 ${
            isDark ? 'text-white' : 'text-neutral-900'
          }`}>
            LAGOS
          </h1>
          <p className={`text-lg sm:text-xl font-light max-w-2xl leading-relaxed ${
            isDark ? 'text-neutral-300' : 'text-neutral-700'
          }`}>
            More than a city. A culture. A movement. Nine distinct places. Nine distinct stories. One unapologetic metropolis.
          </p>
        </div>

        {/* Panorama Visual */}
        <div className={`relative w-full aspect-[21/9] bg-neutral-900 border mb-16 overflow-hidden ${
          isDark ? 'border-white/10' : 'border-black/10'
        }`}>
          <img
            src="/images/brand/city_lagos.jpg"
            alt="Lagos Waterfront Panorama"
            className="w-full h-full object-cover filter grayscale contrast-110"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
          <div className="absolute bottom-6 left-6 text-xs font-mono text-neutral-300">
            6.5244° N, 3.3792° E · THE CENTER OF AFRICAN CONTEMPORARY ENERGY
          </div>
        </div>

        {/* All 9 Lagos Locations Grid / Editorial Cards */}
        <div className="space-y-12">
          <div className={`border-b pb-4 flex justify-between items-end ${
            isDark ? 'border-white/10' : 'border-black/10'
          }`}>
            <h2 className={`font-display font-black text-2xl uppercase tracking-tight ${
              isDark ? 'text-white' : 'text-neutral-900'
            }`}>
              THE NINE SANCTUARIES
            </h2>
            <span className={`text-xs font-mono ${isDark ? 'text-neutral-400' : 'text-neutral-500'}`}>001 — 009</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {LAGOS_COLLECTIONS.map((col) => (
              <div
                key={col.id}
                onClick={() => navigateTo(`/collections/${col.slug}`)}
                className={`border transition-all duration-300 group cursor-pointer flex flex-col justify-between overflow-hidden shadow-sm ${
                  isDark
                    ? 'bg-[#121212] border-white/10 hover:border-white/30 text-white'
                    : 'bg-white border-black/10 hover:border-black/30 text-neutral-900'
                }`}
              >
                <div>
                  {/* Photo */}
                  <div className="relative aspect-[16/10] bg-neutral-800 overflow-hidden">
                    <img
                      src={col.image}
                      alt={col.fullName}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div
                      className="absolute top-3 left-3 px-2 py-0.5 text-[10px] font-mono font-bold uppercase tracking-wider text-black"
                      style={{ backgroundColor: col.colorHex === '#FFFFFF' ? '#F0EFEA' : col.colorHex, color: col.colorHex === '#FFFFFF' || col.colorHex === '#38BDF8' ? '#000' : '#FFF' }}
                    >
                      {col.numberStr}
                    </div>
                  </div>

                  {/* Body Text */}
                  <div className="p-6">
                    <div className={`flex items-center gap-1.5 text-[11px] font-mono mb-2 ${
                      isDark ? 'text-neutral-400' : 'text-neutral-500'
                    }`}>
                      <Compass className="w-3.5 h-3.5 opacity-60" />
                      <span>{col.coordinates}</span>
                    </div>

                    <h3 className={`font-display font-extrabold text-2xl uppercase tracking-tight mb-2 transition-colors ${
                      isDark ? 'text-white group-hover:text-neutral-200' : 'text-neutral-900 group-hover:text-neutral-700'
                    }`}>
                      {col.name}
                    </h3>

                    <p className={`text-xs font-mono mb-4 ${isDark ? 'text-neutral-400' : 'text-neutral-500'}`}>
                      {col.personality}
                    </p>

                    <p className={`text-xs line-clamp-3 leading-relaxed font-sans ${
                      isDark ? 'text-neutral-300' : 'text-neutral-700'
                    }`}>
                      {col.shortDesc}
                    </p>
                  </div>
                </div>

                {/* Card Footer with color accent */}
                <div>
                  <div className={`px-6 pb-6 pt-2 flex items-center justify-between text-xs font-bold tracking-widest uppercase transition-colors ${
                    isDark ? 'text-white group-hover:text-neutral-300' : 'text-black group-hover:text-neutral-700'
                  }`}>
                    <span>EXPLORE COLLECTION</span>
                    <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                  </div>
                  <div className="h-1.5 w-full" style={{ backgroundColor: col.colorHex }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
