import React, { useState, useMemo } from 'react';
import { ProductCard } from '../components/ProductCard';
import { useShop } from '../context/ShopContext';
import { Sparkles, Package, Compass, ArrowRight, Check } from 'lucide-react';

type SmartCategory = 'all' | 'polos' | 'trousers' | 'tailoring' | 'packaging';

export const SmartwearPage: React.FC = () => {
  const { navigateTo, formatPrice, addToCart, products, collections, theme } = useShop();
  const [selectedCategory, setSelectedCategory] = useState<SmartCategory>('all');
  const [activeColorwayId, setActiveColorwayId] = useState<string>('005');

  const isDark = theme === 'dark';

  const smartwearProducts = useMemo(() => {
    return products.filter((p) => p.line === 'form' || p.category === 'packaging')
      .filter((p) => (selectedCategory === 'all' ? true : p.category === selectedCategory));
  }, [products, selectedCategory]);

  const activeCol = collections.find((c) => c.id === activeColorwayId) || collections[4] || collections[0];

  const categories = [
    { id: 'all', label: 'All Smartwear' },
    { id: 'polos', label: 'Smart Pique Polos (9 Colors)' },
    { id: 'trousers', label: 'Tailored Trousers & Chinos' },
    { id: 'tailoring', label: 'Blazers & Overshirts' },
    { id: 'packaging', label: 'Collector Box Packaging' },
  ];

  return (
    <div className={`w-full pt-20 pb-24 transition-colors duration-300 ${
      isDark ? 'bg-[#080808] text-white' : 'bg-[#F9F8F5] text-neutral-900'
    }`}>
      {/* Smartwear Hero Header */}
      <section className="relative w-full min-h-[460px] sm:min-h-[520px] flex items-end pb-12 sm:pb-16 px-6 sm:px-10 lg:px-12 bg-[#0d0d0d] border-b border-white/10 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="/images/brand/form_panel.jpg"
            alt="3KO FORM Smartwear Campaign"
            className="w-full h-full object-cover object-center filter brightness-[0.78]"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#080808] via-[#080808]/70 to-transparent" />
        </div>

        <div className="relative z-10 max-w-[1440px] mx-auto w-full">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-[0.25em] text-amber-400 mb-2 font-bold">
              <Package className="w-4 h-4 text-amber-400" />
              <span>THE TAILORED ARCHIVE · SYSTEM II</span>
            </div>
            <h1 className="font-display font-black text-4xl sm:text-6xl lg:text-7xl uppercase tracking-tight text-white mb-3">
              3KO FORM
            </h1>
            <p className="text-sm sm:text-base text-neutral-200 font-normal leading-relaxed max-w-xl mb-4">
              Tailored poise for tropical capitals. Engineered for Victoria Island boardrooms, evening dining, and international itineraries. Double-mercerized Egyptian cottons, structured linens, and unstructured lightweight blazers.
            </p>
            <div className="flex flex-wrap gap-2 text-[11px] font-mono text-neutral-300">
              <span className="bg-white/10 px-2.5 py-1 border border-white/15">Long-Staple Pique</span>
              <span className="bg-white/10 px-2.5 py-1 border border-white/15">French Linen</span>
              <span className="bg-white/10 px-2.5 py-1 border border-white/15">Mother-of-Pearl Buttons</span>
              <span className="bg-white/10 px-2.5 py-1 border border-white/15">Unstructured Shoulders</span>
            </div>
          </div>
        </div>
      </section>

      {/* ==================================================== */}
      {/* 9 COLOR VARIATIONS & THEMES INTERACTIVE MODULE */}
      {/* ==================================================== */}
      <section className={`max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-12 py-12 sm:py-16 border-b ${
        isDark ? 'border-white/10' : 'border-black/10'
      }`}>
        <div className="mb-8">
          <span className="text-xs font-mono uppercase tracking-[0.25em] text-amber-600 dark:text-amber-300 block mb-1 font-bold">
            THE LAGOS COLOR IDENTITY SYSTEM
          </span>
          <h2 className={`font-display font-black text-3xl sm:text-4xl uppercase tracking-tight ${
            isDark ? 'text-white' : 'text-neutral-900'
          }`}>
            Smartwear in Nine Dedicated Location Colors
          </h2>
          <p className={`text-xs sm:text-sm font-sans mt-2 max-w-2xl ${
            isDark ? 'text-neutral-400' : 'text-neutral-600'
          }`}>
            Each variation draws its palette, architectural sketch, and coordinates from one of the nine Lagos cultural sanctuaries.
          </p>
        </div>

        {/* 9 Swatches Button Bar */}
        <div className="grid grid-cols-3 sm:grid-cols-5 lg:grid-cols-9 gap-2 sm:gap-3 mb-10">
          {collections.map((c) => (
            <button
              key={c.id}
              onClick={() => setActiveColorwayId(c.id)}
              className={`p-3 border text-left transition-all cursor-pointer flex flex-col justify-between ${
                activeColorwayId === c.id
                  ? isDark
                    ? 'border-white bg-white/10 ring-1 ring-white'
                    : 'border-black bg-black/5 ring-1 ring-black'
                  : isDark
                  ? 'border-white/10 bg-[#121212] hover:border-white/30'
                  : 'border-black/10 bg-white hover:border-black/30'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className={`text-[10px] font-mono ${isDark ? 'text-neutral-400' : 'text-neutral-500'}`}>{c.numberStr}</span>
                <span
                  className="w-3 h-3 rounded-full border border-black/20"
                  style={{ backgroundColor: c.colorHex }}
                />
              </div>
              <span className={`font-display font-bold text-xs uppercase truncate ${isDark ? 'text-white' : 'text-black'}`}>
                {c.name}
              </span>
              <span className={`text-[10px] font-mono mt-1 truncate ${isDark ? 'text-neutral-400' : 'text-neutral-600'}`}>
                {c.colorName}
              </span>
            </button>
          ))}
        </div>

        {/* Active Colorway Highlight Card with Designed Box Packaging */}
        <div className={`border p-6 sm:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center transition-colors ${
          isDark ? 'bg-[#121212] border-white/15' : 'bg-white border-black/15 shadow-sm'
        }`}>
          {/* Packaging Box Image from the uploaded sheet */}
          <div className="lg:col-span-5 relative aspect-square sm:aspect-[4/3] bg-neutral-900 border border-white/20 overflow-hidden shadow-2xl">
            <img
              src={activeCol.boxImage}
              alt={`${activeCol.fullName} Collector Box Suite`}
              className="w-full h-full object-cover object-center"
            />
            <div className="absolute top-3 left-3 bg-black/80 px-2.5 py-1 text-[10px] font-mono uppercase tracking-widest text-amber-300 border border-amber-500/30">
              RECOMMENDED BOX PACKAGING
            </div>
            <div className="absolute bottom-3 left-3 bg-black/80 px-2.5 py-1 text-[10px] font-mono text-white/90 border border-white/10">
              {activeCol.coordinates}
            </div>
          </div>

          {/* Theme & Garment Pairing Information */}
          <div className="lg:col-span-7 space-y-4">
            <div className="flex items-center gap-2">
              <span
                className="px-2 py-0.5 text-xs font-mono font-bold uppercase tracking-wider text-black"
                style={{ backgroundColor: activeCol.colorHex === '#FFFFFF' ? '#F0EFEA' : activeCol.colorHex, color: activeCol.colorHex === '#FFFFFF' || activeCol.colorHex === '#38BDF8' ? '#000' : '#FFF' }}
              >
                COLLECTION {activeCol.numberStr}
              </span>
              <span className={`text-xs font-mono tracking-wider ${isDark ? 'text-neutral-400' : 'text-neutral-600'}`}>
                THEME: {activeCol.personality}
              </span>
            </div>

            <h3 className={`font-display font-black text-2xl sm:text-4xl uppercase tracking-tight ${
              isDark ? 'text-white' : 'text-neutral-900'
            }`}>
              {activeCol.fullName}
            </h3>

            <p className={`text-xs sm:text-sm leading-relaxed font-sans ${
              isDark ? 'text-neutral-300' : 'text-neutral-700'
            }`}>
              {activeCol.shortDesc}
            </p>

            <div className={`pt-2 border-t space-y-2 text-xs font-mono ${
              isDark ? 'border-white/10 text-neutral-300' : 'border-black/10 text-neutral-700'
            }`}>
              <div className="flex items-center gap-2">
                <Compass className="w-3.5 h-3.5 text-amber-500 dark:text-amber-400" />
                <span>LANDMARK: {activeCol.landmark}</span>
              </div>
              <div className="flex items-center gap-2">
                <Package className="w-3.5 h-3.5 text-amber-500 dark:text-amber-400" />
                <span>PACKAGING: 1200 GSM rigid box with {activeCol.name} architectural sketch</span>
              </div>
            </div>

            <div className="pt-4 flex flex-wrap items-center gap-3">
              <button
                onClick={() => navigateTo(`/product/lagos-005-polo`)}
                className={`px-6 py-2.5 text-xs font-bold uppercase tracking-widest transition-colors flex items-center gap-2 cursor-pointer ${
                  isDark ? 'bg-white text-[#080808] hover:bg-neutral-200' : 'bg-black text-white hover:bg-neutral-800'
                }`}
              >
                <span>ORDER SMART POLO</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => navigateTo(`/collections/${activeCol.slug}`)}
                className={`px-5 py-2.5 text-xs font-semibold uppercase tracking-widest border transition-colors cursor-pointer ${
                  isDark
                    ? 'border-white/20 text-neutral-300 hover:text-white hover:border-white'
                    : 'border-black/20 text-neutral-700 hover:text-black hover:border-black'
                }`}
              >
                VIEW FULL LOCATION ARCHIVE
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ==================================================== */}
      {/* SMARTWEAR PRODUCT CATALOG GRID */}
      {/* ==================================================== */}
      <section className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-12 py-12">
        {/* Category Tabs */}
        <div className={`flex flex-wrap items-center gap-2 mb-10 pb-4 border-b ${
          isDark ? 'border-white/10' : 'border-black/10'
        }`}>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id as SmartCategory)}
              className={`px-4 py-2 text-xs font-mono uppercase tracking-wider border transition-all cursor-pointer ${
                selectedCategory === cat.id
                  ? isDark
                    ? 'border-white bg-white text-[#080808] font-bold'
                    : 'border-black bg-black text-white font-bold'
                  : isDark
                  ? 'border-white/10 bg-[#121212] text-neutral-400 hover:text-white hover:border-white/30'
                  : 'border-black/10 bg-white text-neutral-600 hover:text-black hover:border-black/30'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Product Grid: Spacious 3-column layout */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 sm:gap-10 lg:gap-12">
          {smartwearProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* ==================================================== */}
      {/* HIGHLIGHTED: THE 9 DESIGNED BOX PACKAGING SUITES */}
      {/* ==================================================== */}
      <section className={`max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-12 pt-12 pb-6 border-t ${
        isDark ? 'border-white/10' : 'border-black/10'
      }`}>
        <div className="mb-10 text-center max-w-2xl mx-auto">
          <span className="text-xs font-mono uppercase tracking-[0.25em] text-amber-500 dark:text-amber-300 block mb-2 font-bold">
            ARCHITECTURAL PACKAGING SUITES
          </span>
          <h2 className={`font-display font-black text-3xl sm:text-5xl uppercase tracking-tight mb-3 ${
            isDark ? 'text-white' : 'text-neutral-900'
          }`}>
            The Nine Designed Boxes
          </h2>
          <p className={`text-xs sm:text-sm font-sans leading-relaxed ${
            isDark ? 'text-neutral-300' : 'text-neutral-600'
          }`}>
            Every variation of 3KO Streetwear and Smartwear is engineered to pair with its matching rigid collector box, stamped with local coordinates and hand-drawn architecture.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {collections.map((c) => (
            <div
              key={c.id}
              className={`border p-4 flex flex-col justify-between group transition-all shadow-md ${
                isDark ? 'bg-[#121212] border-white/15 hover:border-white/40' : 'bg-white border-black/15 hover:border-black/40'
              }`}
            >
              <div className="relative aspect-[4/3] bg-neutral-900 border border-white/10 overflow-hidden mb-4">
                <img
                  src={c.boxImage}
                  alt={c.fullName}
                  className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-500"
                />
                <div
                  className="absolute bottom-2 left-2 px-2 py-0.5 text-[9px] font-mono font-bold uppercase tracking-wider text-black"
                  style={{ backgroundColor: c.colorHex === '#FFFFFF' ? '#F0EFEA' : c.colorHex, color: c.colorHex === '#FFFFFF' || c.colorHex === '#38BDF8' ? '#000' : '#FFF' }}
                >
                  {c.numberStr} — {c.name}
                </div>
              </div>

              <div>
                <div className={`flex items-center justify-between text-[11px] font-mono mb-1 ${
                  isDark ? 'text-neutral-400' : 'text-neutral-500'
                }`}>
                  <span>{c.personality}</span>
                  <span className={`font-bold ${isDark ? 'text-white' : 'text-black'}`}>{c.colorName}</span>
                </div>
                <h4 className={`font-display font-bold text-base uppercase truncate mb-1 ${
                  isDark ? 'text-white' : 'text-black'
                }`}>
                  {c.fullName}
                </h4>
                <p className={`text-xs line-clamp-2 font-sans mb-4 ${
                  isDark ? 'text-neutral-400' : 'text-neutral-600'
                }`}>
                  {c.shortDesc}
                </p>
              </div>

              <div className={`pt-3 border-t flex items-center justify-between ${
                isDark ? 'border-white/10' : 'border-black/10'
              }`}>
                <span className="text-xs font-mono font-bold text-amber-500 dark:text-amber-300">
                  {formatPrice(15000, 12, 10)}
                </span>
                <button
                  onClick={() => navigateTo(`/product/lagos-collector-box-suites`)}
                  className={`text-xs font-mono uppercase flex items-center gap-1 cursor-pointer hover:underline ${
                    isDark ? 'text-white hover:text-neutral-300' : 'text-black hover:text-neutral-700'
                  }`}
                >
                  <span>Order Suite</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
