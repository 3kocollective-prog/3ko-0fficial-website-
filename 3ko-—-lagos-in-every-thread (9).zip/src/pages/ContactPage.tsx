import React, { useState } from 'react';
import { MapPin, Phone, Mail, Clock, MessageSquare, Check, ArrowRight } from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const ContactPage: React.FC = () => {
  const { showToast, theme } = useShop();
  const [submitted, setSubmitted] = useState(false);
  const isDark = theme === 'dark';

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: 'General Inquiry',
    orderNumber: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    showToast('Your message has been received by 3KO Client Concierge.');
    setTimeout(() => {
      setSubmitted(false);
      setFormData({
        name: '',
        email: '',
        subject: 'General Inquiry',
        orderNumber: '',
        message: '',
      });
    }, 4000);
  };

  return (
    <div className={`w-full pt-24 pb-20 px-6 sm:px-10 lg:px-12 transition-colors duration-300 ${
      isDark ? 'bg-[#080808] text-white' : 'bg-[#F9F8F5] text-neutral-900'
    }`}>
      <div className="max-w-[1440px] mx-auto">
        {/* Header */}
        <div className="max-w-2xl mb-16">
          <span className={`text-xs uppercase tracking-[0.25em] font-mono block mb-2 font-semibold ${
            isDark ? 'text-neutral-400' : 'text-neutral-600'
          }`}>
            CLIENT CONCIERGE & SHOWROOMS
          </span>
          <h1 className="font-display font-black text-4xl sm:text-6xl uppercase tracking-tight mb-4">
            CONNECT WITH 3KO.
          </h1>
          <p className={`text-sm sm:text-base font-normal leading-relaxed ${
            isDark ? 'text-neutral-300' : 'text-neutral-700'
          }`}>
            Our atelier and customer concierge team are headquartered in Lagos, Nigeria. Reach out for bespoke fittings, order inquiries, private showroom bookings, or press collaborations.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16">
          {/* Left Column: Flagship Showrooms & Hours */}
          <div className="lg:col-span-5 space-y-8">
            {/* Showroom 1: Victoria Island */}
            <div className={`p-6 border space-y-3 transition-colors ${
              isDark ? 'bg-[#121212] border-white/10' : 'bg-white border-black/10 shadow-sm'
            }`}>
              <div className={`flex items-center gap-2 text-xs font-mono uppercase tracking-wider ${
                isDark ? 'text-neutral-400' : 'text-neutral-500'
              }`}>
                <MapPin className="w-4 h-4 text-current" />
                <span>3KO FLAGSHIP SHOWROOM · VI</span>
              </div>
              <h3 className="font-display font-bold text-xl uppercase">
                Victoria Island Atelier
              </h3>
              <p className={`text-xs leading-relaxed font-sans ${
                isDark ? 'text-neutral-300' : 'text-neutral-600'
              }`}>
                28 Ozumba Mbadiwe Avenue, Victoria Island, Lagos, Nigeria
              </p>
              <div className={`flex items-center gap-2 text-xs font-mono pt-2 border-t ${
                isDark ? 'border-white/5 text-neutral-400' : 'border-black/5 text-neutral-500'
              }`}>
                <Clock className="w-3.5 h-3.5" />
                <span>Mon – Sat: 10:00 AM – 8:00 PM (WAT)</span>
              </div>
            </div>

            {/* Showroom 2: Ikoyi */}
            <div className={`p-6 border space-y-3 transition-colors ${
              isDark ? 'bg-[#121212] border-white/10' : 'bg-white border-black/10 shadow-sm'
            }`}>
              <div className={`flex items-center gap-2 text-xs font-mono uppercase tracking-wider ${
                isDark ? 'text-neutral-400' : 'text-neutral-500'
              }`}>
                <MapPin className="w-4 h-4 text-current" />
                <span>3KO DESIGN LAB & ARCHIVE · IKOYI</span>
              </div>
              <h3 className="font-display font-bold text-xl uppercase">
                Old Ikoyi Studio
              </h3>
              <p className={`text-xs leading-relaxed font-sans ${
                isDark ? 'text-neutral-300' : 'text-neutral-600'
              }`}>
                14 Alexander Boulevard, Old Ikoyi, Lagos, Nigeria
              </p>
              <div className={`flex items-center gap-2 text-xs font-mono pt-2 border-t ${
                isDark ? 'border-white/5 text-neutral-400' : 'border-black/5 text-neutral-500'
              }`}>
                <Clock className="w-3.5 h-3.5" />
                <span>By Private Appointment Only</span>
              </div>
            </div>

            {/* Direct WhatsApp Concierge */}
            <div className={`p-6 border ${
              isDark ? 'bg-neutral-900 border-white/15' : 'bg-neutral-100 border-black/10'
            }`}>
              <h4 className="font-display font-bold text-sm uppercase mb-2">
                Instant Lagos WhatsApp Concierge
              </h4>
              <p className={`text-xs mb-4 font-sans leading-relaxed ${
                isDark ? 'text-neutral-400' : 'text-neutral-600'
              }`}>
                Need immediate sizing advice or same-day dispatch status? Chat directly with our private styling concierge.
              </p>
              <a
                href="https://wa.me/2348003333333"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-4 py-2.5 text-xs uppercase tracking-wider transition-colors"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Chat on WhatsApp</span>
              </a>
            </div>
          </div>

          {/* Right Column: Contact Form */}
          <div className={`lg:col-span-7 border p-8 sm:p-10 transition-colors ${
            isDark ? 'bg-[#111111] border-white/10' : 'bg-white border-black/10 shadow-sm'
          }`}>
            <h3 className="font-display font-bold text-2xl uppercase tracking-tight mb-2">
              Send an Inquiry
            </h3>
            <p className={`text-xs mb-6 font-sans ${
              isDark ? 'text-neutral-400' : 'text-neutral-600'
            }`}>
              We respond to all requests within 12 hours.
            </p>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className={`block text-[11px] uppercase tracking-wider mb-1 ${
                    isDark ? 'text-neutral-400' : 'text-neutral-500'
                  }`}>
                    Your Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Enter your full name"
                    className={`w-full border px-3.5 py-2.5 text-xs focus:outline-none transition-colors ${
                      isDark
                        ? 'bg-[#181818] border-white/10 text-white placeholder-neutral-500 focus:border-white'
                        : 'bg-neutral-50 border-black/15 text-black placeholder-neutral-400 focus:border-black'
                    }`}
                  />
                </div>
                <div>
                  <label className={`block text-[11px] uppercase tracking-wider mb-1 ${
                    isDark ? 'text-neutral-400' : 'text-neutral-500'
                  }`}>
                    Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="Enter your email address"
                    className={`w-full border px-3.5 py-2.5 text-xs focus:outline-none transition-colors ${
                      isDark
                        ? 'bg-[#181818] border-white/10 text-white placeholder-neutral-500 focus:border-white'
                        : 'bg-neutral-50 border-black/15 text-black placeholder-neutral-400 focus:border-black'
                    }`}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className={`block text-[11px] uppercase tracking-wider mb-1 ${
                    isDark ? 'text-neutral-400' : 'text-neutral-500'
                  }`}>
                    Inquiry Subject
                  </label>
                  <select
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    className={`w-full border px-3.5 py-2.5 text-xs focus:outline-none transition-colors ${
                      isDark
                        ? 'bg-[#181818] border-white/10 text-white focus:border-white'
                        : 'bg-neutral-50 border-black/15 text-black focus:border-black'
                    }`}
                  >
                    <option value="General Inquiry">General Brand Inquiry</option>
                    <option value="Order Tracking">Order & Delivery Tracking</option>
                    <option value="Sizing Consultation">Sizing & Styling Advice</option>
                    <option value="Private Showroom">Private Showroom Appointment</option>
                    <option value="Wholesale & Press">Wholesale / Press Editorial</option>
                  </select>
                </div>
                <div>
                  <label className={`block text-[11px] uppercase tracking-wider mb-1 ${
                    isDark ? 'text-neutral-400' : 'text-neutral-500'
                  }`}>
                    Order Number (Optional)
                  </label>
                  <input
                    type="text"
                    value={formData.orderNumber}
                    onChange={(e) => setFormData({ ...formData, orderNumber: e.target.value })}
                    placeholder="Enter order reference (optional)"
                    className={`w-full border px-3.5 py-2.5 text-xs focus:outline-none font-mono transition-colors ${
                      isDark
                        ? 'bg-[#181818] border-white/10 text-white placeholder-neutral-500 focus:border-white'
                        : 'bg-neutral-50 border-black/15 text-black placeholder-neutral-400 focus:border-black'
                    }`}
                  />
                </div>
              </div>

              <div>
                <label className={`block text-[11px] uppercase tracking-wider mb-1 ${
                  isDark ? 'text-neutral-400' : 'text-neutral-500'
                }`}>
                  Message *
                </label>
                <textarea
                  required
                  rows={5}
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="How can 3KO Client Concierge assist you?"
                  className={`w-full border p-3.5 text-xs font-sans leading-relaxed focus:outline-none transition-colors ${
                    isDark
                      ? 'bg-[#181818] border-white/10 text-white placeholder-neutral-500 focus:border-white'
                      : 'bg-neutral-50 border-black/15 text-black placeholder-neutral-400 focus:border-black'
                  }`}
                />
              </div>

              <button
                type="submit"
                className={`w-full font-bold py-3.5 text-xs uppercase tracking-widest transition-colors flex items-center justify-center gap-2 cursor-pointer ${
                  isDark
                    ? 'bg-white text-[#080808] hover:bg-neutral-200'
                    : 'bg-black text-white hover:bg-neutral-800'
                }`}
              >
                {submitted ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-500" />
                    <span>MESSAGE TRANSMITTED</span>
                  </>
                ) : (
                  <>
                    <span>SUBMIT INQUIRY</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
