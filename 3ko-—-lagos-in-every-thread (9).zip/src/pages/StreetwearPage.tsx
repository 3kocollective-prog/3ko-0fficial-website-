import React, { useState, useMemo } from 'react';
import { ProductCard } from '../components/ProductCard';
import { useShop } from '../context/ShopContext';
import { Sparkles, ArrowRight, ShieldCheck, Shirt } from 'lucide-react';

type StreetCategory = 'all' | 'shirts' | 'joggers' | 'hoodies' | 'caps' | 'jerseys';

export const StreetwearPage: React.FC = () => {
  const { navigateTo, products, theme } = useShop();
  const [selectedCategory, setSelectedCategory] = useState<StreetCategory>('all');
  const [sortBy, setSortBy] = useState<'featured' | 'price-low' | 'price-high'>('featured');

  const isDark = theme === 'dark';

  const streetwearProducts = useMemo(() => {
    return products.filter((p) => p.line === 'street')
      .filter((p) => (selectedCategory === 'all' ? true : p.category === selectedCategory))
      .sort((a, b) => {
        if (sortBy === 'price-low') return a.priceNGN - b.priceNGN;
        if (sortBy === 'price-high') return b.priceNGN - a.priceNGN;
        return (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0);
      });
  }, [products, selectedCategory, sortBy]);

  const categories = [
    { id: 'all', label: 'All Streetwear', count: products.filter((p) => p.line === 'street').length },
    { id: 'shirts', label: 'Shirts & Tees', count: products.filter((p) => p.line === 'street' && p.category === 'shirts').length },
    { id: 'hoodies', label: 'Hoodies', count: products.filter((p) => p.line === 'street' && p.category === 'hoodies').length },
    { id: 'joggers', label: 'Joggers & Shorts', count: products.filter((p) => p.line === 'street' && p.category === 'joggers').length },
    { id: 'caps', label: 'Caps & Hats', count: products.filter((p) => p.line === 'street' && p.category === 'caps').length },
    { id: 'jerseys', label: 'Football Jerseys (8 Colors)', count: products.filter((p) => p.line === 'street' && p.category === 'jerseys').length },
  ];

  return (
    <div className={`w-full pt-20 pb-24 transition-colors duration-300 ${
      isDark ? 'bg-[#080808] text-white' : 'bg-[#F9F8F5] text-neutral-900'
    }`}>
      {/* Streetwear Hero Header */}
      <section className="relative w-full min-h-[460px] sm:min-h-[520px] flex items-end pb-12 sm:pb-16 px-6 sm:px-10 lg:px-12 bg-black border-b border-white/10 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="/images/brand/street_panel.jpg"
            alt="3KO Streetwear Campaign Look"
            className="w-full h-full object-cover object-center filter brightness-[0.72]"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#080808] via-[#080808]/70 to-transparent" />
        </div>

        <div className="relative z-10 max-w-[1440px] mx-auto w-full">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-[0.25em] text-lime-400 mb-2 font-bold">
              <Shirt className="w-4 h-4 text-lime-400" />
              <span>THE URBAN ARCHIVE · SYSTEM I</span>
            </div>
            <h1 className="font-display font-black text-4xl sm:text-6xl lg:text-7xl uppercase tracking-tight text-white mb-3">
              3KO STREET
            </h1>
            <p className="text-sm sm:text-base text-neutral-200 font-normal leading-relaxed max-w-xl mb-4">
              Velocity and concrete. Bold architectural streetwear engineered for the Nigerian street and global capitals. Heavyweight 280–480 GSM French terry, tactile puff ink elevations, and dropped-shoulder silhouettes.
            </p>
            <div className="flex flex-wrap gap-2 text-[11px] font-mono text-neutral-300">
              <span className="bg-white/10 px-2.5 py-1 border border-white/15">280–480 GSM Organic Cotton</span>
              <span className="bg-white/10 px-2.5 py-1 border border-white/15">Tactile Matte Puff Ink</span>
              <span className="bg-white/10 px-2.5 py-1 border border-white/15">Dropped Shoulder Fit</span>
              <span className="bg-white/10 px-2.5 py-1 border border-white/15">1.25" Dense Rib Collar</span>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Campaign Lookbook Material Strip */}
      <section className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-12 py-12">
        <div className={`border p-6 sm:p-8 flex flex-col lg:flex-row items-center justify-between gap-8 transition-colors ${
          isDark ? 'bg-[#121212] border-white/10' : 'bg-white border-black/10 shadow-sm'
        }`}>
          <div className="max-w-xl">
            <span className="text-[11px] font-mono uppercase tracking-widest text-amber-500 dark:text-amber-300 block mb-1 font-bold">
              OFFICIAL CAMPAIGN MATERIAL
            </span>
            <h2 className={`font-display font-bold text-2xl uppercase mb-2 ${
              isDark ? 'text-white' : 'text-neutral-900'
            }`}>
              Different Places. Same City. One Brand.
            </h2>
            <p className={`text-xs font-sans leading-relaxed ${
              isDark ? 'text-neutral-400' : 'text-neutral-600'
            }`}>
              Explore the six primary streetwear chapters: Lekki-Ikoyi Bridge tees, National Theatre hoodies, Lagos Island green skyline prints, Balogun market street joggers, Tarkwa Bay beach sets, and Victoria Island tailored casuals.
            </p>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            <img
              src="/images/apparel/look_001_ikoyi_tee_cap.jpg"
              alt="Ikoyi Tee"
              className={`w-16 h-20 sm:w-20 sm:h-24 object-cover border ${
                isDark ? 'border-white/20' : 'border-black/20'
              }`}
            />
            <img
              src="/images/apparel/look_002_theatre_hoodies.jpg"
              alt="Theatre Hoodie"
              className={`w-16 h-20 sm:w-20 sm:h-24 object-cover border ${
                isDark ? 'border-white/20' : 'border-black/20'
              }`}
            />
            <img
              src="/images/apparel/look_005_tarkwa_palm_tee_shorts.jpg"
              alt="Tarkwa Shorts"
              className={`w-16 h-20 sm:w-20 sm:h-24 object-cover border ${
                isDark ? 'border-white/20' : 'border-black/20'
              }`}
            />
            <img
              src="/images/jerseys/jersey_black.jpg"
              alt="Football Jersey"
              className={`w-16 h-20 sm:w-20 sm:h-24 object-cover border ${
                isDark ? 'border-white/20' : 'border-black/20'
              }`}
            />
          </div>
        </div>
      </section>

      {/* Main Streetwear Catalog */}
      <section className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-12">
        {/* Category Filter Tabs */}
        <div className={`flex flex-col md:flex-row md:items-center justify-between gap-4 mb-10 pb-4 border-b ${
          isDark ? 'border-white/10' : 'border-black/10'
        }`}>
          <div className="flex flex-wrap items-center gap-2">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id as StreetCategory)}
                className={`px-3.5 py-2 text-xs font-mono uppercase tracking-wider border transition-all cursor-pointer flex items-center gap-2 ${
                  selectedCategory === cat.id
                    ? isDark
                      ? 'border-white bg-white text-[#080808] font-bold'
                      : 'border-black bg-black text-white font-bold'
                    : isDark
                    ? 'border-white/10 bg-[#121212] text-neutral-400 hover:text-white hover:border-white/30'
                    : 'border-black/10 bg-white text-neutral-600 hover:text-black hover:border-black/30'
                }`}
              >
                <span>{cat.label}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                    selectedCategory === cat.id
                      ? isDark ? 'bg-[#080808] text-white' : 'bg-white text-black'
                      : isDark ? 'bg-white/10 text-neutral-400' : 'bg-black/10 text-neutral-600'
                  }`}
                >
                  {cat.count}
                </span>
              </button>
            ))}
          </div>

          <div className={`flex items-center gap-2 text-xs font-mono ${
            isDark ? 'text-neutral-400' : 'text-neutral-600'
          }`}>
            <span>SORT:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className={`border px-3 py-1.5 text-xs focus:outline-none font-mono ${
                isDark
                  ? 'bg-[#141414] border-white/20 text-white focus:border-white'
                  : 'bg-white border-black/20 text-black focus:border-black'
              }`}
            >
              <option value="featured">Featured Drops</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
            </select>
          </div>
        </div>

        {/* Product Grid: Spacious 3-column layout */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 sm:gap-10 lg:gap-12">
          {streetwearProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        {/* Highlight Banner: 3KO Football Jersey Campaign */}
        <div className={`mt-20 p-8 sm:p-12 border ${
          isDark
            ? 'bg-gradient-to-r from-neutral-900 via-neutral-950 to-neutral-900 border-white/15 text-white'
            : 'bg-gradient-to-r from-neutral-100 via-neutral-50 to-neutral-100 border-black/15 text-neutral-900'
        }`}>
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-7">
              <span className="text-xs uppercase tracking-widest font-mono text-amber-500 dark:text-amber-300 block mb-2 font-bold flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>SPECIAL STREETWEAR DROP</span>
              </span>
              <h3 className={`font-display font-black text-3xl sm:text-5xl uppercase tracking-tight mb-4 ${
                isDark ? 'text-white' : 'text-neutral-900'
              }`}>
                3KO FOOTBALL JERSEY
              </h3>
              <p className={`text-xs sm:text-sm leading-relaxed font-sans mb-6 ${
                isDark ? 'text-neutral-300' : 'text-neutral-700'
              }`}>
                Engineered with custom jacquard palm fabric, embroidered Lagos palm shield crest, coordinates (06°27'N 03°24'E), and back squad number 30. Available in all 8 iconic Nigerian colorways: Black Original, White, Green, Red, Navy Blue, Beige/Stone, Purple, and Grey.
              </p>
              <button
                onClick={() => navigateTo('/product/3ko-football-jersey')}
                className={`px-7 py-3 text-xs font-bold uppercase tracking-widest flex items-center gap-2 cursor-pointer transition-colors ${
                  isDark ? 'bg-white text-[#080808] hover:bg-neutral-200' : 'bg-black text-white hover:bg-neutral-800'
                }`}
              >
                <span>SHOP ALL 8 COLORWAYS</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
            <div className="lg:col-span-5 grid grid-cols-4 gap-2">
              <img
                src="/images/jerseys/jersey_black.jpg"
                alt="Black Jersey"
                className={`w-full aspect-[3/4] object-cover border ${
                  isDark ? 'border-white/10' : 'border-black/10'
                }`}
              />
              <img
                src="/images/jerseys/jersey_green.jpg"
                alt="Green Jersey"
                className={`w-full aspect-[3/4] object-cover border ${
                  isDark ? 'border-white/10' : 'border-black/10'
                }`}
              />
              <img
                src="/images/jerseys/jersey_red.jpg"
                alt="Red Jersey"
                className={`w-full aspect-[3/4] object-cover border ${
                  isDark ? 'border-white/10' : 'border-black/10'
                }`}
              />
              <img
                src="/images/jerseys/jersey_navy.jpg"
                alt="Navy Jersey"
                className={`w-full aspect-[3/4] object-cover border ${
                  isDark ? 'border-white/10' : 'border-black/10'
                }`}
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
