import React, { useState, useRef, useEffect } from 'react';
import { useShop } from '../context/ShopContext';
import {
  ChevronLeft,
  ChevronRight,
  ShoppingBag,
  ArrowRight,
  RotateCw,
  X,
  Package,
  Layers,
  Sparkles,
  Maximize2,
  Check,
  Eye,
  Sliders
} from 'lucide-react';

interface RailColorway {
  name: string;
  hex: string;
  frontImage: string;
  backImage: string;
}

interface RailItem {
  id: string;
  slug: string;
  collectionNumber: string;
  collectionName: string;
  title: string;
  subtitle: string;
  line: 'street' | 'form';
  category: string;
  priceNGN: number;
  priceUSD: number;
  priceGBP: number;
  activeColor: string;
  activeColorHex: string;
  colorways: RailColorway[];
  boxImage: string;
  boxName: string;
  coordinates: string;
  description: string;
  badge?: string;
}

const RAIL_ITEMS: RailItem[] = [
  {
    id: 'prod-001-tee',
    slug: 'lagos-001-bridge-tee',
    collectionNumber: '001',
    collectionName: 'IKOYI',
    title: '3KO — 3KO 001 BRIDGE GRAPHIC TEE',
    subtitle: '280 GSM Heavyweight Streetwear Tee with Lekki Bridge Puff Print',
    line: 'street',
    category: 'shirts',
    priceNGN: 55000,
    priceUSD: 38,
    priceGBP: 30,
    activeColor: 'Cream / Bone',
    activeColorHex: '#F4F1EA',
    badge: 'SIGNATURE DROP',
    colorways: [
      {
        name: 'Cream / Bone',
        hex: '#F4F1EA',
        frontImage: '/images/apparel/look_001_ikoyi_tee_cap.jpg',
        backImage: '/images/social/social_1_model_back.jpg',
      },
      {
        name: 'Pitch Black',
        hex: '#0A0A0A',
        frontImage: '/images/brand/street_panel.jpg',
        backImage: '/images/social/social_1_model_back.jpg',
      },
    ],
    boxImage: '/images/packaging/box_001_ikoyi.jpg',
    boxName: '3KO 001 IKOYI COLLECTOR BOX',
    coordinates: '6.4289° N, 3.3672° E',
    description: 'Illustrated with the cable-stayed Lekki-Ikoyi Link Bridge skyline fused with the 3KO bubble emblem on the reverse.',
  },
  {
    id: 'prod-002-hoodie',
    slug: 'lagos-002-theatre-hoodie',
    collectionNumber: '002',
    collectionName: 'NATIONAL THEATRE',
    title: '3KO — 3KO 002 DOME HEAVYWEIGHT HOODIE',
    subtitle: '480 GSM French Terry Dome-Architectural Hoodie',
    line: 'street',
    category: 'hoodies',
    priceNGN: 85000,
    priceUSD: 58,
    priceGBP: 46,
    activeColor: 'Washed Charcoal',
    activeColorHex: '#27272A',
    badge: 'ICONIC HEAVYWEIGHT',
    colorways: [
      {
        name: 'Washed Charcoal',
        hex: '#27272A',
        frontImage: '/images/apparel/look_002_theatre_hoodies.jpg',
        backImage: '/images/collections/002_national_theatre.jpg',
      },
      {
        name: 'Obsidian Black',
        hex: '#0F0F0F',
        frontImage: '/images/apparel/look_004_balogun_hoodie_shorts.jpg',
        backImage: '/images/collections/002_national_theatre.jpg',
      },
    ],
    boxImage: '/images/packaging/box_002_national_theatre.jpg',
    boxName: '3KO 002 THEATRE COLLECTOR BOX',
    coordinates: '6.4716° N, 3.3705° E',
    description: 'Crafted from double-faced 480 GSM French terry featuring the military-hat peak of the National Theatre.',
  },
  {
    id: 'prod-006-jersey',
    slug: 'lagos-006-vi-football-jersey',
    collectionNumber: '006',
    collectionName: 'VICTORIA ISLAND',
    title: '3KO — 3KO 006 VI FOOTBALL JERSEY',
    subtitle: 'Victoria Island Emerald Jacquard Match-Day Kit',
    line: 'street',
    category: 'jerseys',
    priceNGN: 60000,
    priceUSD: 42,
    priceGBP: 33,
    activeColor: 'Emerald Green',
    activeColorHex: '#047857',
    badge: 'BESTSELLER',
    colorways: [
      {
        name: 'Emerald Green',
        hex: '#047857',
        frontImage: '/images/jerseys/jersey_green.jpg',
        backImage: '/images/jerseys/jersey_craft_details.jpg',
      },
      {
        name: 'Lagos Gold',
        hex: '#D97706',
        frontImage: '/images/jerseys/jersey_beige.jpg',
        backImage: '/images/jerseys/jersey_craft_details.jpg',
      },
      {
        name: 'Marina Midnight',
        hex: '#18181B',
        frontImage: '/images/jerseys/jersey_black.jpg',
        backImage: '/images/jerseys/jersey_craft_details.jpg',
      },
      {
        name: 'Harbor White',
        hex: '#F8FAFC',
        frontImage: '/images/jerseys/jersey_white.jpg',
        backImage: '/images/jerseys/jersey_craft_details.jpg',
      },
    ],
    boxImage: '/images/packaging/box_006_victoria_island.jpg',
    boxName: '3KO 006 VI COLLECTOR BOX',
    coordinates: '6.4253° N, 3.4219° E',
    description: 'Bespoke engineered knit pattern inspired by Victoria Island corporate towers and high-society nightlife.',
  },
  {
    id: 'prod-004-jersey',
    slug: 'lagos-004-balogun-red-jersey',
    collectionNumber: '004',
    collectionName: 'BALOGUN MARKET',
    title: '3KO — 3KO 004 ARCHIVAL FOOTBALL JERSEY',
    subtitle: 'Balogun Red Textured Jacquard Streetwear Kit',
    line: 'street',
    category: 'jerseys',
    priceNGN: 60000,
    priceUSD: 42,
    priceGBP: 33,
    activeColor: 'Crimson Red',
    activeColorHex: '#DC2626',
    badge: 'MATCH DAY EDITION',
    colorways: [
      {
        name: 'Crimson Red',
        hex: '#DC2626',
        frontImage: '/images/jerseys/jersey_red.jpg',
        backImage: '/images/jerseys/jersey_craft_details.jpg',
      },
      {
        name: 'Deep Purple',
        hex: '#7E22CE',
        frontImage: '/images/jerseys/jersey_purple.jpg',
        backImage: '/images/jerseys/jersey_craft_details.jpg',
      },
    ],
    boxImage: '/images/packaging/box_004_balogun.jpg',
    boxName: '3KO 004 BALOGUN COLLECTOR BOX',
    coordinates: '6.4552° N, 3.3841° E',
    description: 'Celebrating the bustling energy of West Africa’s fabric trading epicenter with heat-bonded 3KO cresting.',
  },
  {
    id: 'prod-003-polo',
    slug: 'lagos-003-island-polo',
    collectionNumber: '003',
    collectionName: 'LAGOS ISLAND',
    title: '3KO — 3KO 003 MARINA TAILORED POLO',
    subtitle: 'Mercerized Piqué Cotton Smartwear with Micro-Crest',
    line: 'form',
    category: 'polos',
    priceNGN: 62000,
    priceUSD: 44,
    priceGBP: 35,
    activeColor: 'Forest Green',
    activeColorHex: '#14532D',
    badge: '3KO FORM',
    colorways: [
      {
        name: 'Forest Green',
        hex: '#14532D',
        frontImage: '/images/apparel/look_003_lagos_island_tee_polo.jpg',
        backImage: '/images/social/social_2_polo_embroidery.jpg',
      },
      {
        name: 'Harbor Navy',
        hex: '#1E293B',
        frontImage: '/images/jerseys/jersey_navy.jpg',
        backImage: '/images/social/social_2_polo_embroidery.jpg',
      },
    ],
    boxImage: '/images/packaging/box_003_lagos_island.jpg',
    boxName: '3KO 003 MARINA COLLECTOR BOX',
    coordinates: '6.4500° N, 3.3958° E',
    description: 'Crafted from lustrous double-mercerized Egyptian cotton with mother-of-pearl buttons and tailored rib cuffs.',
  },
  {
    id: 'prod-005-palm-tee',
    slug: 'lagos-005-palm-tee',
    collectionNumber: '005',
    collectionName: 'TARKWA BAY',
    title: '3KO — 3KO 005 TARKWA BAY PALM TEE',
    subtitle: 'Warm Sand Coastal Streetwear Shirt',
    line: 'street',
    category: 'shirts',
    priceNGN: 55000,
    priceUSD: 38,
    priceGBP: 30,
    activeColor: 'Warm Sand',
    activeColorHex: '#D7C7B0',
    colorways: [
      {
        name: 'Warm Sand',
        hex: '#D7C7B0',
        frontImage: '/images/apparel/look_005_tarkwa_palm_tee_shorts.jpg',
        backImage: '/images/collections/005_tarkwa_bay.jpg',
      },
      {
        name: 'Lagoon White',
        hex: '#FFFFFF',
        frontImage: '/images/jerseys/jersey_white.jpg',
        backImage: '/images/collections/005_tarkwa_bay.jpg',
      },
    ],
    boxImage: '/images/packaging/box_005_tarkwa_bay.jpg',
    boxName: '3KO 005 TARKWA BAY COLLECTOR BOX',
    coordinates: '6.4014° N, 3.4072° E',
    description: 'Coastal breeze silhouette with subtle screenprinted palms on sun-bleached organic cotton.',
  },
  {
    id: 'prod-006-blazer',
    slug: 'lagos-006-vi-blazer',
    collectionNumber: '006',
    collectionName: 'VICTORIA ISLAND',
    title: '3KO — 3KO 006 UNSTRUCTURED TAILORED SUIT',
    subtitle: 'Lightweight Tropical Wool Smartwear Blazer',
    line: 'form',
    category: 'tailoring',
    priceNGN: 185000,
    priceUSD: 128,
    priceGBP: 102,
    activeColor: 'Obsidian Black',
    activeColorHex: '#18181B',
    badge: 'LUXURY TAILORING',
    colorways: [
      {
        name: 'Obsidian Black',
        hex: '#18181B',
        frontImage: '/images/apparel/look_006_vi_tailored_blazer_suit.jpg',
        backImage: '/images/collections/006_victoria_island.jpg',
      },
    ],
    boxImage: '/images/packaging/box_006_victoria_island.jpg',
    boxName: '3KO 006 VI TAILORED COLLECTOR BOX',
    coordinates: '6.4253° N, 3.4219° E',
    description: 'Unstructured shoulders with horn buttons, designed specifically for tropical climates and evening galas.',
  },
];

export const InteractiveClothingRail: React.FC = () => {
  const { formatPrice, addToCart, navigateTo, theme, products } = useShop();
  const isDark = theme === 'dark';

  // State
  const [selectedItemIndex, setSelectedItemIndex] = useState<number | null>(null);
  const [isBackView, setIsBackView] = useState<boolean>(false);
  const [activeColorIndex, setActiveColorIndex] = useState<number>(0);
  const [selectedSize, setSelectedSize] = useState<string>('L');
  const [includeBox, setIncludeBox] = useState<boolean>(true);
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  const railScrollRef = useRef<HTMLDivElement>(null);
  const isDraggingRef = useRef(false);
  const startXRef = useRef(0);
  const scrollLeftRef = useRef(0);

  const activeItem = selectedItemIndex !== null ? RAIL_ITEMS[selectedItemIndex] : null;

  // When changing focused garment, reset to front view and first colorway
  const handleSelectItem = (index: number) => {
    setSelectedItemIndex(index);
    setIsBackView(false);
    setActiveColorIndex(0);
    setSelectedSize('L');
    setIncludeBox(true);
  };

  const handleCloseFocus = () => {
    setSelectedItemIndex(null);
    setIsBackView(false);
  };

  const handleNextItem = () => {
    if (selectedItemIndex === null) return;
    const nextIdx = (selectedItemIndex + 1) % RAIL_ITEMS.length;
    handleSelectItem(nextIdx);
  };

  const handlePrevItem = () => {
    if (selectedItemIndex === null) return;
    const prevIdx = (selectedItemIndex - 1 + RAIL_ITEMS.length) % RAIL_ITEMS.length;
    handleSelectItem(prevIdx);
  };

  // Scroll buttons for rail
  const scrollRail = (direction: 'left' | 'right') => {
    if (railScrollRef.current) {
      const scrollAmount = 360;
      railScrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth',
      });
    }
  };

  // Mouse drag handling for the rail
  const handleMouseDown = (e: React.MouseEvent) => {
    if (!railScrollRef.current) return;
    isDraggingRef.current = true;
    startXRef.current = e.pageX - railScrollRef.current.offsetLeft;
    scrollLeftRef.current = railScrollRef.current.scrollLeft;
  };

  const handleMouseLeave = () => {
    isDraggingRef.current = false;
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current || !railScrollRef.current) return;
    e.preventDefault();
    const x = e.pageX - railScrollRef.current.offsetLeft;
    const walk = (x - startXRef.current) * 1.5;
    railScrollRef.current.scrollLeft = scrollLeftRef.current - walk;
  };

  // Handle Add To Bag directly from rail focus
  const handleAddToCart = () => {
    if (!activeItem) return;

    // Find actual Product from context to ensure correct inventory and IDs
    const matchedProduct = products.find((p) => p.slug === activeItem.slug) || {
      id: activeItem.id,
      slug: activeItem.slug,
      name: activeItem.title,
      subtitle: activeItem.subtitle,
      line: activeItem.line,
      category: activeItem.category as any,
      collectionId: activeItem.collectionNumber,
      collectionName: activeItem.collectionName,
      priceNGN: activeItem.priceNGN,
      priceUSD: activeItem.priceUSD,
      priceGBP: activeItem.priceGBP,
      color: activeItem.colorways[activeColorIndex]?.name || activeItem.activeColor,
      colorHex: activeItem.colorways[activeColorIndex]?.hex || activeItem.activeColorHex,
      sizes: ['S', 'M', 'L', 'XL', 'XXL'],
      description: activeItem.description,
      editorialNote: 'Virtual Showroom Garment Rack Edition.',
      fabricDetails: ['Premium archival construction', 'Signature 3KO tailoring'],
      careInstructions: ['Dry clean or wash cold'],
      fit: 'Relaxed contemporary silhouette',
      images: [
        activeItem.colorways[activeColorIndex]?.frontImage || activeItem.colorways[0].frontImage,
        activeItem.colorways[activeColorIndex]?.backImage || activeItem.colorways[0].backImage,
      ],
      packagingNote: 'Curated box included.',
      boxPackaging: {
        available: true,
        boxName: activeItem.boxName,
        collectionId: activeItem.collectionNumber,
        boxImage: activeItem.boxImage,
        priceNGN: 15000,
        priceUSD: 12,
        priceGBP: 10,
        coordinates: activeItem.coordinates,
        description: 'Matte rigid collector box.',
      },
    };

    addToCart(
      matchedProduct,
      selectedSize,
      activeItem.colorways[activeColorIndex]?.name || activeItem.activeColor,
      1,
      includeBox
    );
  };

  // Keyboard navigation when focus mode is open
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (selectedItemIndex === null) return;
      if (e.key === 'Escape') handleCloseFocus();
      if (e.key === 'ArrowRight') handleNextItem();
      if (e.key === 'ArrowLeft') handlePrevItem();
      if (e.key === 'f' || e.key === 'F') setIsBackView((prev) => !prev);
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedItemIndex]);

  return (
    <section
      id="clothing-rail-showroom"
      className={`relative w-full overflow-hidden transition-colors duration-500 py-16 sm:py-24 border-b ${
        isDark
          ? 'bg-[#060606] text-white border-white/10'
          : 'bg-[#F5F2EB] text-neutral-900 border-black/10'
      }`}
    >
      {/* Background Architectural Grid Accent */}
      <div
        className={`absolute inset-0 pointer-events-none opacity-[0.03] ${
          isDark ? 'bg-[radial-gradient(#fff_1px,transparent_1px)]' : 'bg-[radial-gradient(#000_1px,transparent_1px)]'
        } [background-size:24px_24px]`}
      />

      {/* Header & Controls Bar */}
      <div className="max-w-[1440px] mx-auto px-5 sm:px-10 lg:px-12 relative z-10 mb-8 sm:mb-12">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 text-[11px] font-mono tracking-[0.2em] uppercase rounded-full mb-3 border shadow-sm backdrop-blur-md bg-opacity-80 transition-colors">
              <span className="w-2 h-2 rounded-full bg-lime-400 animate-pulse" />
              <span className={isDark ? 'text-lime-300' : 'text-lime-700'}>
                INTERACTIVE VIRTUAL SHOWROOM
              </span>
              <span className="opacity-40">|</span>
              <span className="opacity-80">ARCHIVAL CLOTHING RACK</span>
            </div>

            <h2 className="font-display font-black text-3xl sm:text-4xl lg:text-5xl uppercase tracking-tight">
              THE 3KO ARCHIVAL RAIL
            </h2>
            <p
              className={`text-xs sm:text-sm font-mono mt-2 max-w-xl ${
                isDark ? 'text-neutral-400' : 'text-neutral-600'
              }`}
            >
              Browse hanging drops directly on the rail. Pull any piece forward to inspect front & reverse
              craftsmanship, cycle colorway tags, and view coordinated box packaging.
            </p>
          </div>

          {/* Quick Rail Navigation Tools */}
          <div className="flex items-center gap-3">
            <span
              className={`text-[11px] font-mono tracking-widest uppercase hidden sm:inline-block ${
                isDark ? 'text-neutral-400' : 'text-neutral-600'
              }`}
            >
              {selectedItemIndex !== null
                ? `INSPECTING ${selectedItemIndex + 1} OF ${RAIL_ITEMS.length}`
                : 'SLIDE OR DRAG RACK'}
            </span>

            <div className="flex items-center gap-2">
              <button
                onClick={() => (selectedItemIndex !== null ? handlePrevItem() : scrollRail('left'))}
                aria-label="Previous rail piece"
                className={`p-2.5 sm:p-3 rounded-full border transition-all cursor-pointer ${
                  isDark
                    ? 'border-white/20 bg-neutral-900/80 text-white hover:bg-neutral-800 hover:border-white/40'
                    : 'border-black/20 bg-white text-black hover:bg-neutral-100 hover:border-black/40'
                }`}
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={() => (selectedItemIndex !== null ? handleNextItem() : scrollRail('right'))}
                aria-label="Next rail piece"
                className={`p-2.5 sm:p-3 rounded-full border transition-all cursor-pointer ${
                  isDark
                    ? 'border-white/20 bg-neutral-900/80 text-white hover:bg-neutral-800 hover:border-white/40'
                    : 'border-black/20 bg-white text-black hover:bg-neutral-100 hover:border-black/40'
                }`}
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ============================================================== */}
      {/* THE ARCHITECTURAL CHROME CLOTHING RAIL STAGE                  */}
      {/* ============================================================== */}
      <div className="relative w-full select-none">
        {/* Top Metallic Wall Mount Brackets (Left & Right) */}
        <div className="max-w-[1440px] mx-auto px-4 sm:px-8 relative">
          <div className="relative flex items-center justify-between w-full h-8">
            {/* Left Bracket */}
            <div className="flex items-center gap-1 z-20">
              <div
                className={`w-6 sm:w-8 h-10 rounded-sm shadow-lg border border-black/40 flex flex-col justify-between p-1 ${
                  isDark
                    ? 'bg-gradient-to-r from-neutral-600 via-neutral-300 to-neutral-700'
                    : 'bg-gradient-to-r from-neutral-400 via-neutral-100 to-neutral-500'
                }`}
              >
                <span className="w-1.5 h-1.5 rounded-full bg-neutral-900 mx-auto" />
                <span className="w-1.5 h-1.5 rounded-full bg-neutral-900 mx-auto" />
              </div>
              <div
                className={`h-4 w-5 shadow-inner ${
                  isDark
                    ? 'bg-gradient-to-b from-neutral-300 via-neutral-100 to-neutral-500'
                    : 'bg-gradient-to-b from-neutral-400 via-neutral-200 to-neutral-600'
                }`}
              />
            </div>

            {/* Continuous Polished Chrome Hanging Rail Bar */}
            <div className="absolute left-6 right-6 sm:left-10 sm:right-10 top-1/2 -translate-y-1/2 h-3.5 rounded-full shadow-[0_6px_14px_rgba(0,0,0,0.45)] z-10 overflow-hidden flex flex-col justify-center border border-white/30">
              <div
                className={`w-full h-full ${
                  isDark
                    ? 'bg-gradient-to-b from-neutral-400 via-neutral-100 via-white to-neutral-700'
                    : 'bg-gradient-to-b from-neutral-300 via-white to-neutral-500'
                }`}
              />
              <div className="absolute inset-x-0 top-0.5 h-[1.5px] bg-white opacity-90" />
              <div className="absolute inset-x-0 bottom-0.5 h-[1px] bg-neutral-900 opacity-60" />
            </div>

            {/* Right Bracket */}
            <div className="flex items-center gap-1 z-20">
              <div
                className={`h-4 w-5 shadow-inner ${
                  isDark
                    ? 'bg-gradient-to-b from-neutral-300 via-neutral-100 to-neutral-500'
                    : 'bg-gradient-to-b from-neutral-400 via-neutral-200 to-neutral-600'
                }`}
              />
              <div
                className={`w-6 sm:w-8 h-10 rounded-sm shadow-lg border border-black/40 flex flex-col justify-between p-1 ${
                  isDark
                    ? 'bg-gradient-to-r from-neutral-700 via-neutral-300 to-neutral-600'
                    : 'bg-gradient-to-r from-neutral-500 via-neutral-100 to-neutral-400'
                }`}
              >
                <span className="w-1.5 h-1.5 rounded-full bg-neutral-900 mx-auto" />
                <span className="w-1.5 h-1.5 rounded-full bg-neutral-900 mx-auto" />
              </div>
            </div>
          </div>
        </div>

        {/* ============================================================== */}
        {/* HORIZONTAL RAIL SCROLL CONTAINER                              */}
        {/* ============================================================== */}
        <div
          ref={railScrollRef}
          onMouseDown={handleMouseDown}
          onMouseLeave={handleMouseLeave}
          onMouseUp={handleMouseUp}
          onMouseMove={handleMouseMove}
          className="w-full overflow-x-auto no-scrollbar scroll-smooth pt-2 pb-10 px-6 sm:px-12 flex items-start gap-8 sm:gap-14 cursor-grab active:cursor-grabbing"
          style={{ scrollSnapType: 'x proximity' }}
        >
          {RAIL_ITEMS.map((item, index) => {
            const isHovered = hoveredIndex === index;
            const isPulledOut = selectedItemIndex === index;

            return (
              <div
                key={item.id}
                onClick={() => handleSelectItem(index)}
                onMouseEnter={() => setHoveredIndex(index)}
                onMouseLeave={() => setHoveredIndex(null)}
                style={{ scrollSnapAlign: 'center' }}
                className={`relative flex flex-col items-center shrink-0 w-[240px] sm:w-[280px] lg:w-[310px] group transition-all duration-300 ${
                  isPulledOut
                    ? 'opacity-30 scale-95 pointer-events-none'
                    : 'hover:-translate-y-2 cursor-pointer'
                }`}
              >
                {/* 1. ARCHITECTURAL HANGER HOOK & SHOULDER (SVG) */}
                <div className="relative w-40 sm:w-48 h-16 flex flex-col items-center z-10 transition-transform duration-300 group-hover:rotate-1">
                  {/* Chrome Hook looped over the rail */}
                  <svg
                    viewBox="0 0 100 45"
                    className="w-12 h-10 overflow-visible drop-shadow-md"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    {/* Metal Hook Loop */}
                    <path
                      d="M 50 45 L 50 25 C 50 12, 64 6, 60 0 C 56 -6, 42 -4, 40 6 C 39 12, 44 18, 48 20"
                      stroke={isDark ? '#E5E7EB' : '#4B5563'}
                      strokeWidth="3.2"
                      strokeLinecap="round"
                    />
                    {/* Hook highlight */}
                    <path
                      d="M 50 45 L 50 25 C 50 12, 64 6, 60 0"
                      stroke="#FFFFFF"
                      strokeWidth="1.2"
                      strokeLinecap="round"
                      opacity="0.8"
                    />
                  </svg>

                  {/* Contoured Hanger Shoulder (Brushed Wood / Matte Carbon) */}
                  <div
                    className={`w-full h-3 rounded-full -mt-2 shadow-md relative overflow-hidden ${
                      isDark
                        ? 'bg-gradient-to-r from-neutral-800 via-neutral-600 to-neutral-800 border-t border-white/20'
                        : 'bg-gradient-to-r from-amber-900/80 via-amber-700/90 to-amber-900/80 border-t border-amber-500/40'
                    }`}
                  >
                    <div className="absolute inset-0 bg-gradient-to-b from-white/20 to-transparent" />
                    <span className="absolute left-1/2 -translate-x-1/2 top-0.5 text-[7px] font-mono tracking-widest text-neutral-400 font-bold">
                      3KO
                    </span>
                  </div>
                </div>

                {/* 2. THE HANGING GARMENT BODY */}
                <div
                  className={`relative w-full aspect-[3/4] rounded-sm overflow-hidden shadow-2xl transition-all duration-300 border ${
                    isDark
                      ? 'bg-[#121212] border-white/10 group-hover:border-white/30'
                      : 'bg-white border-black/10 group-hover:border-black/30'
                  }`}
                >
                  {/* Collection Pill Tag hanging at corner */}
                  <div className="absolute top-3 left-3 z-10 flex flex-col gap-1 items-start">
                    <span className="px-2 py-0.5 text-[9px] font-mono font-bold tracking-widest uppercase bg-black/85 text-white backdrop-blur-md border border-white/20">
                      {item.collectionNumber} {item.collectionName}
                    </span>
                    {item.badge && (
                      <span className="px-1.5 py-0.5 text-[8px] font-mono tracking-wider uppercase bg-lime-400 text-black font-extrabold shadow-sm">
                        {item.badge}
                      </span>
                    )}
                  </div>

                  {/* Primary Garment Image */}
                  <img
                    src={item.colorways[0].frontImage}
                    alt={item.title}
                    className="w-full h-full object-cover object-top transition-transform duration-500 group-hover:scale-105"
                    loading="lazy"
                  />

                  {/* Soft Vignette / Lighting Overlay for tactile textile depth */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/10 pointer-events-none" />

                  {/* Hover "PULL FROM RACK" Prompt Overlay */}
                  <div
                    className={`absolute inset-0 flex flex-col items-center justify-center p-4 transition-opacity duration-200 backdrop-blur-[2px] ${
                      isHovered ? 'opacity-100 bg-black/40' : 'opacity-0 pointer-events-none'
                    }`}
                  >
                    <div className="px-4 py-2 bg-white text-black font-mono font-bold text-xs uppercase tracking-widest shadow-2xl flex items-center gap-2 transform transition-transform group-hover:scale-105">
                      <Sparkles className="w-3.5 h-3.5 text-lime-600" />
                      <span>PULL FROM RAIL</span>
                    </div>
                    <span className="text-[10px] font-mono tracking-wider uppercase text-neutral-200 mt-2">
                      INSPECT FRONT & BACK
                    </span>
                  </div>

                  {/* Bottom Info Strip inside card */}
                  <div className="absolute bottom-0 inset-x-0 p-3 sm:p-4 text-white z-10 pointer-events-none">
                    <div className="text-[11px] font-bold tracking-wider uppercase truncate">
                      {item.title}
                    </div>
                    <div className="flex items-center justify-between mt-1">
                      <span className="text-xs font-mono font-bold text-lime-400">
                        {formatPrice(item.priceNGN, item.priceUSD, item.priceGBP)}
                      </span>
                      <span className="text-[10px] font-mono opacity-80 uppercase tracking-widest">
                        {item.colorways.length} COLORWAYS
                      </span>
                    </div>
                  </div>
                </div>

                {/* 3. GROUND SHADOW BENEATH GARMENT */}
                <div
                  className="w-44 sm:w-56 h-4 mt-3 rounded-full blur-md opacity-70 transition-all duration-300 group-hover:w-48 group-hover:opacity-90"
                  style={{
                    background: isDark
                      ? 'radial-gradient(ellipse at center, rgba(0,0,0,0.9) 0%, transparent 70%)'
                      : 'radial-gradient(ellipse at center, rgba(0,0,0,0.3) 0%, transparent 70%)',
                  }}
                />

                {/* 4. Floor Coordinate Spec */}
                <div
                  className={`mt-1 text-[9px] font-mono tracking-widest uppercase transition-opacity ${
                    isDark ? 'text-neutral-500' : 'text-neutral-400'
                  }`}
                >
                  {item.coordinates}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ============================================================== */}
      {/* HIGH-FASHION RUNNING ARCHIVAL TICKER STRIP                     */}
      {/* ============================================================== */}
      <div className={`relative w-full overflow-hidden py-3 sm:py-3.5 border-y select-none my-6 ${
        isDark ? 'bg-[#0f0f0f] text-neutral-200 border-white/10 shadow-inner' : 'bg-[#181818] text-[#F4F1EA] border-black/10 shadow-sm'
      }`}>
        <div className="flex items-center whitespace-nowrap animate-marquee">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="flex items-center gap-6 sm:gap-10 text-xs sm:text-[13px] font-mono tracking-[0.24em] uppercase shrink-0 px-4">
              <span className="font-bold text-white">LAGOS IN EVERY THREAD</span>
              <span className="w-1.5 h-1.5 rounded-full bg-lime-400" />
              <span className="text-neutral-300">3KO ARCHIVAL WARDROBE</span>
              <span className="w-1.5 h-1.5 rounded-full bg-white/40" />
              <span>STREETWEAR & SMARTWEAR DUALITY</span>
              <span className="w-1.5 h-1.5 rounded-full bg-lime-400" />
              <span className="text-neutral-300">DISPATCHED FROM LEKKI · WORLDWIDE DHL</span>
              <span className="w-1.5 h-1.5 rounded-full bg-white/40" />
              <span className="font-bold text-white">ARCHITECTURAL BOX PACKAGING INCLUDED</span>
              <span className="w-1.5 h-1.5 rounded-full bg-lime-400" />
            </div>
          ))}
        </div>
      </div>

      {/* ============================================================== */}
      {/* SPOTLIGHT INSPECTION MODAL / OVERLAY (PULLED FROM RAIL)        */}
      {/* ============================================================== */}
      {activeItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 lg:p-8 bg-black/85 backdrop-blur-xl animate-in fade-in duration-300">
          <div
            className={`relative w-full max-w-5xl rounded-sm shadow-2xl overflow-hidden border max-h-[92vh] flex flex-col md:flex-row ${
              isDark ? 'bg-[#0E0E0E] border-white/20 text-white' : 'bg-[#FAFAF9] border-black/20 text-neutral-900'
            }`}
          >
            {/* Top Close & Exit Spotlight */}
            <button
              onClick={handleCloseFocus}
              aria-label="Return to rack"
              className={`absolute top-4 right-4 z-30 p-2.5 rounded-full border transition-all cursor-pointer ${
                isDark
                  ? 'bg-neutral-900 border-white/20 text-white hover:bg-neutral-800'
                  : 'bg-white border-black/20 text-neutral-900 hover:bg-neutral-100'
              }`}
            >
              <X className="w-5 h-5" />
            </button>

            {/* Previous / Next Stepper across garments in spotlight */}
            <div className="absolute top-4 left-4 z-30 flex items-center gap-2">
              <button
                onClick={handlePrevItem}
                className={`p-2 rounded-full border transition-all cursor-pointer ${
                  isDark
                    ? 'bg-neutral-900 border-white/20 text-white hover:bg-neutral-800'
                    : 'bg-white border-black/20 text-neutral-900 hover:bg-neutral-100'
                }`}
                title="Previous Piece"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="px-2.5 py-1 text-[10px] font-mono font-bold tracking-widest uppercase bg-black/70 text-white backdrop-blur-md border border-white/10 rounded-full">
                {selectedItemIndex! + 1} / {RAIL_ITEMS.length}
              </span>
              <button
                onClick={handleNextItem}
                className={`p-2 rounded-full border transition-all cursor-pointer ${
                  isDark
                    ? 'bg-neutral-900 border-white/20 text-white hover:bg-neutral-800'
                    : 'bg-white border-black/20 text-neutral-900 hover:bg-neutral-100'
                }`}
                title="Next Piece"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {/* LEFT / CENTER: THE GARMENT SPOTLIGHT DISPLAY WITH FRONT / BACK TOGGLE */}
            <div
              className={`w-full md:w-1/2 p-6 sm:p-8 flex flex-col items-center justify-center relative border-b md:border-b-0 md:border-r ${
                isDark ? 'bg-neutral-950 border-white/10' : 'bg-neutral-100 border-black/10'
              }`}
            >
              {/* Suspended Hanger Hook Graphic */}
              <div className="w-36 h-10 flex flex-col items-center mb-1">
                <svg
                  viewBox="0 0 100 45"
                  className="w-10 h-8 drop-shadow"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M 50 45 L 50 25 C 50 12, 64 6, 60 0 C 56 -6, 42 -4, 40 6 C 39 12, 44 18, 48 20"
                    stroke={isDark ? '#FFFFFF' : '#374151'}
                    strokeWidth="3.5"
                    strokeLinecap="round"
                  />
                </svg>
                <div
                  className={`w-32 h-2.5 rounded-full -mt-1 shadow-md ${
                    isDark ? 'bg-neutral-700' : 'bg-neutral-400'
                  }`}
                />
              </div>

              {/* Garment Image Container with 3D Flip */}
              <div className="relative w-full max-w-sm aspect-[4/5] rounded-sm overflow-hidden shadow-2xl border border-black/20 bg-black/5">
                <img
                  src={
                    isBackView
                      ? activeItem.colorways[activeColorIndex]?.backImage || activeItem.colorways[0].backImage
                      : activeItem.colorways[activeColorIndex]?.frontImage || activeItem.colorways[0].frontImage
                  }
                  alt={`${activeItem.title} ${isBackView ? 'Back' : 'Front'}`}
                  className="w-full h-full object-cover object-top transition-all duration-500 ease-out"
                />

                {/* Perspective Badge */}
                <div className="absolute top-3 right-3 px-2.5 py-1 text-[10px] font-mono font-bold tracking-widest uppercase bg-black/80 text-white backdrop-blur-md border border-white/20">
                  {isBackView ? 'REVERSE DETAIL' : 'FRONT PROFILE'}
                </div>
              </div>

              {/* FRONT / BACK INTERACTIVE TOGGLE BUTTONS (PROMINENT AS IN VIDEO) */}
              <div className="flex items-center gap-2 mt-4 z-10">
                <button
                  onClick={() => setIsBackView(false)}
                  className={`px-4 py-2 text-xs font-mono font-bold tracking-widest uppercase rounded-sm border transition-all cursor-pointer ${
                    !isBackView
                      ? 'bg-lime-400 text-black border-lime-400 shadow-md scale-105'
                      : isDark
                      ? 'bg-neutral-900 text-neutral-300 border-white/20 hover:text-white'
                      : 'bg-white text-neutral-700 border-black/20 hover:text-black'
                  }`}
                >
                  FRONT VIEW
                </button>
                <button
                  onClick={() => setIsBackView(true)}
                  className={`px-4 py-2 text-xs font-mono font-bold tracking-widest uppercase rounded-sm border transition-all cursor-pointer ${
                    isBackView
                      ? 'bg-lime-400 text-black border-lime-400 shadow-md scale-105'
                      : isDark
                      ? 'bg-neutral-900 text-neutral-300 border-white/20 hover:text-white'
                      : 'bg-white text-neutral-700 border-black/20 hover:text-black'
                  }`}
                >
                  BACK VIEW
                </button>
                <button
                  onClick={() => setIsBackView((prev) => !prev)}
                  className={`p-2 rounded-sm border transition-all cursor-pointer ${
                    isDark
                      ? 'bg-neutral-900 text-neutral-400 border-white/20 hover:text-white'
                      : 'bg-white text-neutral-600 border-black/20 hover:text-black'
                  }`}
                  title="Flip side (Shortcut: 'F')"
                >
                  <RotateCw className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* RIGHT: SPECIFICATIONS, COLORWAY SWATCHES, BOX PACKAGING & CHECKOUT */}
            <div className="w-full md:w-1/2 p-6 sm:p-8 flex flex-col justify-between overflow-y-auto max-h-[85vh]">
              <div>
                {/* Collection Meta */}
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[10px] font-mono tracking-[0.2em] uppercase font-bold text-lime-400">
                    LAGOS COLLECTION {activeItem.collectionNumber}
                  </span>
                  <span className="opacity-40 text-xs">/</span>
                  <span className="text-[10px] font-mono tracking-widest uppercase opacity-75">
                    {activeItem.collectionName}
                  </span>
                </div>

                <h3 className="font-display font-black text-2xl sm:text-3xl uppercase tracking-tight mb-1">
                  {activeItem.title}
                </h3>
                <p className={`text-xs font-mono mb-4 ${isDark ? 'text-neutral-400' : 'text-neutral-600'}`}>
                  {activeItem.subtitle}
                </p>

                {/* Price Display */}
                <div className="flex items-baseline gap-3 pb-4 mb-4 border-b border-white/10">
                  <span className="text-2xl sm:text-3xl font-mono font-black text-lime-400">
                    {formatPrice(activeItem.priceNGN, activeItem.priceUSD, activeItem.priceGBP)}
                  </span>
                  <span className="text-xs font-mono uppercase tracking-widest opacity-60">
                    TAX INCLUDED · WORLDWIDE EXPRESS
                  </span>
                </div>

                {/* 1. HANGING COLORWAY SWATCH TAGS (AS SEEN IN VIDEO) */}
                <div className="mb-5">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] font-mono uppercase tracking-widest font-bold">
                      COLORWAY SELECTION:
                    </span>
                    <span className="text-[11px] font-mono text-lime-400 font-bold uppercase">
                      {activeItem.colorways[activeColorIndex]?.name}
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-3">
                    {activeItem.colorways.map((c, cIdx) => (
                      <button
                        key={c.name}
                        onClick={() => setActiveColorIndex(cIdx)}
                        className={`flex items-center gap-2 px-3 py-1.5 rounded-sm border transition-all cursor-pointer ${
                          activeColorIndex === cIdx
                            ? 'border-lime-400 bg-lime-400/10 shadow-sm'
                            : isDark
                            ? 'border-white/10 bg-neutral-900/60 hover:border-white/30'
                            : 'border-black/10 bg-white hover:border-black/30'
                        }`}
                      >
                        <span
                          className="w-4 h-4 rounded-full border border-black/30 shrink-0"
                          style={{ backgroundColor: c.hex }}
                        />
                        <span className="text-xs font-mono uppercase tracking-wider">{c.name}</span>
                        {activeColorIndex === cIdx && <Check className="w-3.5 h-3.5 text-lime-400" />}
                      </button>
                    ))}
                  </div>
                </div>

                {/* 2. SIZE SELECTION PILLS */}
                <div className="mb-5">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] font-mono uppercase tracking-widest font-bold">
                      SELECT SIZE:
                    </span>
                    <span className="text-[10px] font-mono underline uppercase tracking-wider opacity-70">
                      BOXY CONTEMPORARY FIT
                    </span>
                  </div>

                  <div className="grid grid-cols-5 gap-2">
                    {['S', 'M', 'L', 'XL', 'XXL'].map((sz) => (
                      <button
                        key={sz}
                        onClick={() => setSelectedSize(sz)}
                        className={`py-2 text-xs font-mono font-bold tracking-wider rounded-sm border transition-all cursor-pointer ${
                          selectedSize === sz
                            ? 'bg-lime-400 text-black border-lime-400 shadow-md font-black'
                            : isDark
                            ? 'bg-neutral-900 text-white border-white/10 hover:border-white/40'
                            : 'bg-white text-black border-black/15 hover:border-black/40'
                        }`}
                      >
                        {sz}
                      </button>
                    ))}
                  </div>
                </div>

                {/* 3. SIGNATURE ARCHITECTURAL COLLECTOR BOX PAIRING (AS REQUESTED) */}
                <div
                  className={`p-3.5 rounded-sm border transition-colors mb-5 ${
                    includeBox
                      ? isDark
                        ? 'bg-neutral-900/90 border-lime-400/50'
                        : 'bg-white border-lime-600/50 shadow-sm'
                      : isDark
                      ? 'bg-neutral-900/30 border-white/10'
                      : 'bg-neutral-100 border-black/10'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <img
                      src={activeItem.boxImage}
                      alt={activeItem.boxName}
                      className="w-16 h-16 object-cover rounded-sm border border-black/20 shrink-0"
                    />

                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-mono font-bold tracking-wider uppercase text-lime-400 flex items-center gap-1.5">
                          <Package className="w-3.5 h-3.5" />
                          <span>RECOMMENDED COLLECTOR BOX</span>
                        </span>
                        <input
                          type="checkbox"
                          id="rail-box-toggle"
                          checked={includeBox}
                          onChange={(e) => setIncludeBox(e.target.checked)}
                          className="w-4 h-4 accent-lime-400 cursor-pointer"
                        />
                      </div>

                      <div className="text-xs font-bold uppercase tracking-tight mt-0.5">
                        {activeItem.boxName}
                      </div>
                      <p
                        className={`text-[10px] font-mono mt-0.5 ${
                          isDark ? 'text-neutral-400' : 'text-neutral-600'
                        }`}
                      >
                        1200 GSM rigid box with Lekki architectural elevation sketch + serialized certificate.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Architectural Coordinate Pin */}
                <div
                  className={`text-[10px] font-mono tracking-widest uppercase mb-4 ${
                    isDark ? 'text-neutral-500' : 'text-neutral-400'
                  }`}
                >
                  ARCHIVAL ORIGIN: {activeItem.coordinates}
                </div>
              </div>

              {/* ACTION BUTTONS (ADD TO BAG, VIEW FULL PRODUCT, RETURN TO RAIL) */}
              <div className="flex flex-col gap-2.5 pt-4 border-t border-white/10 mt-2">
                <button
                  onClick={handleAddToCart}
                  className="w-full py-3.5 px-6 bg-lime-400 hover:bg-lime-300 text-black font-display font-black text-sm uppercase tracking-widest shadow-xl flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>
                    ADD TO BAG — {formatPrice(activeItem.priceNGN, activeItem.priceUSD, activeItem.priceGBP)}
                  </span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      navigateTo(`/product/${activeItem.slug}`);
                    }}
                    className={`flex-1 py-2.5 px-4 rounded-sm border font-mono text-xs font-bold tracking-widest uppercase transition-all cursor-pointer flex items-center justify-center gap-2 ${
                      isDark
                        ? 'border-white/20 bg-neutral-900 text-white hover:bg-neutral-800'
                        : 'border-black/20 bg-white text-black hover:bg-neutral-100'
                    }`}
                  >
                    <span>FULL SPECS & SIZING</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={handleCloseFocus}
                    className={`py-2.5 px-4 rounded-sm border font-mono text-xs font-bold tracking-widest uppercase transition-all cursor-pointer ${
                      isDark
                        ? 'border-white/10 text-neutral-400 hover:text-white hover:border-white/30'
                        : 'border-black/10 text-neutral-600 hover:text-black hover:border-black/30'
                    }`}
                  >
                    RETURN TO RAIL
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
