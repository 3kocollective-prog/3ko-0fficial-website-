import React, { useState } from 'react';
import { ArrowRight, Package, Check, Compass } from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const PackagingSection: React.FC = () => {
  const { navigateTo, collections, theme } = useShop();
  const [selectedBoxId, setSelectedBoxId] = useState<string>('001');

  const selectedCol = collections.find((c) => c.id === selectedBoxId) || collections[0];
  const isDark = theme === 'dark';

  return (
    <section className={`w-full py-16 sm:py-20 lg:py-24 px-6 sm:px-10 lg:px-12 border-b transition-colors ${
      isDark ? 'bg-[#0a0a0a] text-white border-white/10' : 'bg-neutral-900 text-white border-black/10'
    }`}>
      <div className="max-w-[1440px] mx-auto">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12 sm:mb-16">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-400/10 border border-amber-400/30 text-amber-300 text-[11px] font-mono uppercase tracking-widest mb-3">
              <Package className="w-3.5 h-3.5" />
              <span>UNBOX LAGOS · COLLECTOR ARCHITECTURE</span>
            </div>
            <h2 className="font-display font-black text-3xl sm:text-4xl lg:text-5xl uppercase tracking-tight text-white">
              THE ARCHITECTURAL BOX
            </h2>
          </div>
          <p className="text-neutral-300 text-xs sm:text-sm max-w-md font-sans leading-relaxed">
            Every garment across both <span className="text-white font-semibold">3KO STREET</span> and{' '}
            <span className="text-white font-semibold">3KO FORM</span> is paired with a corresponding numbered, coordinate-stamped 1200 GSM rigid collector box.
          </p>
        </div>

        {/* Streamlined Showcase: Left Box Viewer, Right Details */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center bg-[#141414] border border-white/10 p-6 sm:p-8 lg:p-10 mb-8 shadow-2xl">
          {/* Box Image with Proportions */}
          <div className="lg:col-span-7 flex flex-col items-center">
            <div className="relative w-full aspect-[4/3] sm:aspect-[16/10] bg-black border border-white/15 overflow-hidden group shadow-2xl">
              <img
                src={selectedCol.boxImage}
                alt={`${selectedCol.name} Box Packaging`}
                className="w-full h-full object-contain p-3 sm:p-5 transition-transform duration-500 group-hover:scale-[1.02]"
              />
              <div className="absolute top-3 left-3 bg-black/85 backdrop-blur-xs border border-white/20 px-2.5 py-1 text-[10px] font-mono text-white uppercase tracking-widest flex items-center gap-1.5">
                <Compass className="w-3 h-3 text-amber-400" />
                <span>{selectedCol.coordinates}</span>
              </div>
              <div className="absolute bottom-3 right-3 bg-black/85 backdrop-blur-xs border border-white/20 px-2.5 py-1 text-[10px] font-mono text-amber-300 uppercase tracking-widest">
                {selectedCol.numberStr} · {selectedCol.colorName}
              </div>
            </div>
          </div>

          {/* Box Specs & Actions */}
          <div className="lg:col-span-5 flex flex-col justify-between h-full space-y-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span
                  className="w-3 h-3 rounded-full border border-white/40"
                  style={{ backgroundColor: selectedCol.colorHex }}
                />
                <span className="text-xs font-mono uppercase tracking-widest text-neutral-400">
                  {selectedCol.numberStr} — {selectedCol.colorName}
                </span>
              </div>
              <h3 className="font-display font-black text-2xl sm:text-3xl uppercase tracking-tight text-white mb-2">
                {selectedCol.name} EDITION
              </h3>
              <p className="text-neutral-300 text-xs sm:text-sm font-sans leading-relaxed mb-6">
                Engineered from 1200 GSM recycled core archival board with precision magnetic closure, soft-touch matte lamination, and laser-embossed architectural schematic of {selectedCol.landmark}.
              </p>

              {/* Engineering Specs */}
              <div className="space-y-2.5 text-xs text-neutral-300 font-sans border-t border-white/10 pt-4">
                <div className="flex items-center gap-2.5">
                  <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>1200 GSM rigid core archival box with magnetic lid snap</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Custom laser-embossed architectural landmark blueprint</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Serialized authenticity card & archival preservation sleeve</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Check className="w-4 h-4 text-amber-400 shrink-0" />
                  <span className="font-medium text-white">Recommended collector upgrade: ₦15,000 / $12 per piece</span>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => navigateTo('/collections')}
                className="bg-white text-[#080808] px-6 py-3 text-xs font-bold uppercase tracking-widest hover:bg-neutral-200 transition-colors flex items-center gap-2 cursor-pointer"
              >
                <span>EXPLORE 3KO 001–009 EDITIONS</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => navigateTo('/shop')}
                className="border border-white/30 text-white px-6 py-3 text-xs font-bold uppercase tracking-widest hover:bg-white/10 transition-colors cursor-pointer"
              >
                <span>SHOP APPAREL</span>
              </button>
            </div>
          </div>
        </div>

        {/* Minimalist 3KO 001-009 Quick Switcher Ribbon */}
        <div className="flex items-center justify-between overflow-x-auto no-scrollbar gap-2 pt-2">
          {collections.map((col) => {
            const isSelected = col.id === selectedBoxId;
            return (
              <button
                key={col.id}
                onClick={() => setSelectedBoxId(col.id)}
                className={`px-3 py-2 text-[11px] font-mono border transition-all cursor-pointer whitespace-nowrap flex items-center gap-2 ${
                  isSelected
                    ? 'border-white bg-white/15 text-white font-bold ring-1 ring-white/50'
                    : 'border-white/10 bg-white/5 text-neutral-400 hover:text-white hover:border-white/30'
                }`}
              >
                <span
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: col.colorHex }}
                />
                <span>{col.numberStr}</span>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
};
