import React, { useState } from 'react';
import { Heart, Plus, Eye, Package } from 'lucide-react';
import { Product } from '../types';
import { useShop } from '../context/ShopContext';

interface ProductCardProps {
  product: Product;
  onQuickView?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onQuickView }) => {
  const { navigateTo, formatPrice, addToCart, wishlist, toggleWishlist, setQuickViewProduct, theme } =
    useShop();

  const isDark = theme === 'dark';
  const isSaved = wishlist.includes(product.id);

  const handleCardClick = () => {
    navigateTo(`/product/${product.slug}`);
  };

  const [showSizeSelector, setShowSizeSelector] = useState<boolean>(false);
  const [justAddedSize, setJustAddedSize] = useState<string | null>(null);

  const handleQuickAddClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowSizeSelector((prev) => !prev);
  };

  const handleSelectSize = (size: string, e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product, size, product.color, 1, true);
    setJustAddedSize(size);
    setTimeout(() => {
      setJustAddedSize(null);
      setShowSizeSelector(false);
    }, 1200);
  };

  const handleQuickView = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onQuickView) {
      onQuickView(product);
    } else {
      setQuickViewProduct(product);
    }
  };

  const handleHeartClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleWishlist(product.id);
  };

  return (
    <div
      onClick={handleCardClick}
      className={`group flex flex-col border transition-all duration-300 cursor-pointer overflow-hidden ${
        isDark
          ? 'bg-[#111111] border-white/10 hover:border-white/30 text-white'
          : 'bg-white border-black/10 hover:border-black/30 text-neutral-900 shadow-sm'
      }`}
    >
      {/* Product Image Area with strict aspect ratio and responsive centering */}
      <div className={`relative aspect-[3/4] w-full overflow-hidden ${isDark ? 'bg-[#181818]' : 'bg-neutral-100'}`}>
        {(() => {
          const heroImg =
            product.primaryImageIndex !== undefined && product.images[product.primaryImageIndex]
              ? product.images[product.primaryImageIndex]
              : product.images[0] || '/images/apparel/look_001_ikoyi_tee_cap.jpg';
          const altImg = product.images.find((img) => img !== heroImg) || product.images[1];

          return (
            <>
              <img
                src={heroImg}
                alt={product.name}
                className="w-full h-full object-cover object-center transition-transform duration-700 ease-out group-hover:scale-105"
                referrerPolicy="no-referrer"
                loading="lazy"
              />

              {/* Secondary Image on Hover if available */}
              {altImg && (
                <img
                  src={altImg}
                  alt={`${product.name} alternate view`}
                  className="w-full h-full object-cover object-center absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
              )}
            </>
          );
        })()}

        {/* Wishlist Button - minimum 44px tap area */}
        <button
          onClick={handleHeartClick}
          className={`absolute top-2.5 right-2.5 w-10 h-10 flex items-center justify-center rounded-full backdrop-blur-md transition-colors z-10 cursor-pointer ${
            isSaved
              ? 'bg-white text-red-600 shadow-md'
              : 'bg-black/60 text-white/90 hover:bg-black hover:text-white'
          }`}
          aria-label={isSaved ? 'Remove from wishlist' : 'Save to wishlist'}
        >
          <Heart className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
        </button>

        {/* Collection & Category Badges */}
        <div className="absolute top-2.5 left-2.5 z-10 flex flex-col gap-1 items-start">
          <span className="text-[10px] font-mono tracking-widest uppercase bg-black/85 backdrop-blur-xs text-white px-2 py-0.5 border border-white/20">
            {product.collectionName?.split('—')[0].trim() || '3KO PIECE'}
          </span>
          {product.compareAtPriceNGN && product.compareAtPriceNGN > product.priceNGN && (
            <span className="text-[9px] font-mono font-bold tracking-wider uppercase bg-amber-400 text-black px-1.5 py-0.5 shadow-md">
              SALE
            </span>
          )}
          {product.isPreOrder && (
            <span className="text-[9px] font-mono tracking-wider uppercase bg-cyan-900/90 text-cyan-200 border border-cyan-400/40 px-1.5 py-0.5 backdrop-blur-xs">
              PRE-ORDER
            </span>
          )}
          {product.boxPackaging?.available && (
            <span className="text-[9px] font-mono tracking-wider uppercase bg-black/85 text-amber-300 border border-amber-400/30 px-1.5 py-0.5 flex items-center gap-1 backdrop-blur-xs">
              <Package className="w-2.5 h-2.5" />
              <span>Box Included</span>
            </span>
          )}
        </div>

        {/* Interactive Quick Size Selector Drawer Overlay */}
        {showSizeSelector ? (
          <div
            onClick={(e) => e.stopPropagation()}
            className="absolute inset-x-0 bottom-0 p-3 bg-black/95 backdrop-blur-md border-t border-white/20 z-20 animate-in slide-in-from-bottom duration-200"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-mono uppercase tracking-wider text-neutral-300">
                {justAddedSize ? 'Added to bag!' : 'Select Size:'}
              </span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setShowSizeSelector(false);
                }}
                className="text-[10px] font-mono text-neutral-400 hover:text-white uppercase"
              >
                Cancel
              </button>
            </div>
            <div className="grid grid-cols-5 gap-1.5">
              {product.sizes.map((sz) => (
                <button
                  key={sz}
                  onClick={(e) => handleSelectSize(sz, e)}
                  className={`py-1.5 text-xs font-mono font-bold uppercase transition-all cursor-pointer border ${
                    justAddedSize === sz
                      ? 'bg-lime-400 text-black border-lime-400 font-black'
                      : 'bg-white/10 text-white border-white/20 hover:bg-white hover:text-black'
                  }`}
                >
                  {sz}
                </button>
              ))}
            </div>
          </div>
        ) : (
          /* Default Quick Action Overlay (Bottom) */
          <div className="absolute inset-x-0 bottom-0 p-2.5 bg-gradient-to-t from-black/90 via-black/50 to-transparent translate-y-full group-hover:translate-y-0 transition-transform duration-300 flex items-center gap-2">
            <button
              onClick={handleQuickAddClick}
              className="flex-1 bg-white text-[#080808] py-2.5 text-[11px] font-bold uppercase tracking-wider hover:bg-neutral-200 transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-md"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Select Size & Add</span>
            </button>
            <button
              onClick={handleQuickView}
              className="w-10 h-10 bg-black/80 text-white hover:bg-black transition-colors border border-white/20 flex items-center justify-center cursor-pointer shrink-0"
              aria-label="Quick preview"
            >
              <Eye className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* Product Information */}
      <div className={`p-4 flex flex-col justify-between flex-1 ${isDark ? 'bg-[#101010]' : 'bg-white'}`}>
        <div>
          <div className={`flex items-center justify-between text-[11px] font-mono mb-1 ${isDark ? 'text-neutral-400' : 'text-neutral-500'}`}>
            <span className="uppercase tracking-wider">{product.category || product.line}</span>
            <div className="flex items-center gap-1.5">
              <span
                className="w-2.5 h-2.5 rounded-full border border-white/20"
                style={{ backgroundColor: product.colorHex }}
                title={product.color}
              />
              <span className="truncate max-w-[90px]">{product.color}</span>
            </div>
          </div>

          <h3 className={`font-display font-bold text-sm uppercase tracking-tight line-clamp-1 ${isDark ? 'text-white group-hover:text-neutral-200' : 'text-black group-hover:text-neutral-700'}`}>
            {product.name}
          </h3>
          <p className={`text-xs font-sans line-clamp-1 mt-0.5 ${isDark ? 'text-neutral-400' : 'text-neutral-600'}`}>
            {product.subtitle}
          </p>
        </div>

        <div className={`mt-4 pt-2.5 border-t flex items-center justify-between ${isDark ? 'border-white/10' : 'border-black/10'}`}>
          <div className="flex items-baseline gap-2">
            <span className={`font-mono text-xs font-bold tracking-wider ${isDark ? 'text-white' : 'text-black'}`}>
              {formatPrice(product.priceNGN, product.priceUSD, product.priceGBP)}
            </span>
            {product.compareAtPriceNGN && product.compareAtPriceNGN > product.priceNGN && (
              <span className="font-mono text-[10px] text-neutral-500 line-through">
                {formatPrice(product.compareAtPriceNGN, product.compareAtPriceUSD, product.compareAtPriceGBP)}
              </span>
            )}
          </div>
          <span className={`text-[10px] uppercase tracking-widest font-mono transition-colors ${
            isDark ? 'text-neutral-400 group-hover:text-white' : 'text-neutral-600 group-hover:text-black'
          }`}>
            View Piece →
          </span>
        </div>
      </div>
    </div>

  );
};
