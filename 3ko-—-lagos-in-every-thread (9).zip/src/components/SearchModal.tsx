import React, { useState, useMemo } from 'react';
import { Search, X, ArrowRight, Sparkles } from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const SearchModal: React.FC = () => {
  const { isSearchOpen, setIsSearchOpen, navigateTo, formatPrice, products, collections } = useShop();
  const [query, setQuery] = useState('');

  const filteredProducts = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();
    return products.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.collectionName.toLowerCase().includes(q) ||
        p.line.toLowerCase().includes(q) ||
        p.color.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q)
    );
  }, [products, query]);

  const filteredCollections = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();
    return collections.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        c.fullName.toLowerCase().includes(q) ||
        c.landmark.toLowerCase().includes(q) ||
        c.colorName.toLowerCase().includes(q)
    );
  }, [query]);

  if (!isSearchOpen) return null;

  const handleSelectProduct = (slug: string) => {
    setIsSearchOpen(false);
    setQuery('');
    navigateTo(`/product/${slug}`);
  };

  const handleSelectCollection = (slug: string) => {
    setIsSearchOpen(false);
    setQuery('');
    navigateTo(`/collections/${slug}`);
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex flex-col items-center pt-20 px-4 animate-in fade-in duration-200"
      onClick={() => setIsSearchOpen(false)}
    >
      <div
        className="w-full max-w-2xl bg-[#121212] border border-white/15 p-6 sm:p-8 shadow-2xl text-white"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="relative flex items-center border-b border-white/20 pb-4">
          <Search className="w-5 h-5 text-neutral-400 mr-3" />
          <input
            type="text"
            autoFocus
            placeholder="Search products, collections, fabrics (e.g. Polo, Tarkwa Bay, Street, Linen)..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-transparent text-white placeholder-neutral-500 text-sm sm:text-base font-sans focus:outline-none"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="text-neutral-400 hover:text-white p-1 mr-2"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={() => setIsSearchOpen(false)}
            className="text-neutral-400 hover:text-white p-1 text-xs uppercase tracking-widest font-mono"
          >
            ESC
          </button>
        </div>

        {/* Quick Search Suggestions when query is empty */}
        {!query.trim() && (
          <div className="pt-6 space-y-4">
            <span className="text-xs uppercase tracking-widest text-neutral-400 font-semibold flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-white" />
              POPULAR SEARCHES
            </span>
            <div className="flex flex-wrap gap-2 text-xs">
              {['3KO 005 POLO', '3KO STREET', '3KO FORM', 'IKOYI TEE', 'TARKWA BAY', 'CAPS', 'PACKAGING'].map(
                (term) => (
                  <button
                    key={term}
                    onClick={() => setQuery(term)}
                    className="px-3 py-1.5 bg-[#1c1c1c] border border-white/10 hover:border-white text-neutral-300 hover:text-white transition-colors cursor-pointer"
                  >
                    {term}
                  </button>
                )
              )}
            </div>
          </div>
        )}

        {/* Search Results */}
        {query.trim() && (
          <div className="pt-6 max-h-[60vh] overflow-y-auto space-y-6">
            {/* Matching Products */}
            <div>
              <div className="text-xs uppercase tracking-widest text-neutral-400 font-semibold mb-3">
                PRODUCTS ({filteredProducts.length})
              </div>
              {filteredProducts.length === 0 ? (
                <p className="text-xs text-neutral-500 font-mono">No matching products found.</p>
              ) : (
                <div className="space-y-2">
                  {filteredProducts.map((p) => (
                    <div
                      key={p.id}
                      onClick={() => handleSelectProduct(p.slug)}
                      className="flex items-center justify-between p-2.5 bg-[#181818] border border-white/5 hover:border-white/25 transition-colors cursor-pointer group"
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={p.images[0]}
                          alt={p.name}
                          className="w-10 h-12 object-cover bg-neutral-900 border border-white/10"
                        />
                        <div>
                          <h4 className="font-display font-bold text-xs uppercase tracking-tight text-white group-hover:text-neutral-200">
                            {p.name}
                          </h4>
                          <span className="text-[11px] text-neutral-400 font-mono">
                            {p.collectionName} · {p.color}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="font-mono text-xs font-semibold text-white">
                          {formatPrice(p.priceNGN, p.priceUSD, p.priceGBP)}
                        </span>
                        <ArrowRight className="w-3.5 h-3.5 text-neutral-500 group-hover:translate-x-1 group-hover:text-white transition-all" />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Matching Collections */}
            {filteredCollections.length > 0 && (
              <div>
                <div className="text-xs uppercase tracking-widest text-neutral-400 font-semibold mb-3">
                  COLLECTIONS ({filteredCollections.length})
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {filteredCollections.map((c) => (
                    <div
                      key={c.id}
                      onClick={() => handleSelectCollection(c.slug)}
                      className="p-3 bg-[#181818] border border-white/5 hover:border-white/20 transition-colors cursor-pointer flex items-center justify-between"
                    >
                      <div>
                        <span className="font-mono text-[10px] text-neutral-400">{c.numberStr}</span>
                        <h5 className="font-display font-bold text-xs uppercase text-white">
                          {c.name}
                        </h5>
                        <p className="text-[11px] text-neutral-400 truncate max-w-[180px]">
                          {c.landmark}
                        </p>
                      </div>
                      <div
                        className="w-3 h-3 rounded-full shrink-0"
                        style={{ backgroundColor: c.colorHex }}
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
