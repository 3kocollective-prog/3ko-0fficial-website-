import React, { useState } from 'react';
import { X, Ruler } from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const SizeGuideModal: React.FC = () => {
  const { isSizeGuideOpen, setIsSizeGuideOpen } = useShop();
  const [unit, setUnit] = useState<'cm' | 'in'>('cm');
  const [category, setCategory] = useState<'tops' | 'bottoms'>('tops');

  if (!isSizeGuideOpen) return null;

  const topsData = [
    { size: 'S', chestCm: '104 - 108', chestIn: '41 - 42.5', lengthCm: '70', lengthIn: '27.5', shoulderCm: '48', shoulderIn: '18.9' },
    { size: 'M', chestCm: '110 - 114', chestIn: '43 - 44.8', lengthCm: '72', lengthIn: '28.3', shoulderCm: '50', shoulderIn: '19.7' },
    { size: 'L', chestCm: '116 - 120', chestIn: '45.6 - 47.2', lengthCm: '74', lengthIn: '29.1', shoulderCm: '52', shoulderIn: '20.5' },
    { size: 'XL', chestCm: '122 - 126', chestIn: '48 - 49.6', lengthCm: '76', lengthIn: '29.9', shoulderCm: '54', shoulderIn: '21.3' },
    { size: 'XXL', chestCm: '128 - 132', chestIn: '50.4 - 52', lengthCm: '78', lengthIn: '30.7', shoulderCm: '56', shoulderIn: '22.0' },
  ];

  const bottomsData = [
    { size: '30', waistCm: '78', waistIn: '30.7', hipCm: '102', hipIn: '40.1', inseamCm: '78', inseamIn: '30.7' },
    { size: '32', waistCm: '82', waistIn: '32.3', hipCm: '106', hipIn: '41.7', inseamCm: '80', inseamIn: '31.5' },
    { size: '34', waistCm: '86', waistIn: '33.8', hipCm: '110', hipIn: '43.3', inseamCm: '81', inseamIn: '31.9' },
    { size: '36', waistCm: '90', waistIn: '35.4', hipCm: '114', hipIn: '44.9', inseamCm: '82', inseamIn: '32.3' },
    { size: '38', waistCm: '95', waistIn: '37.4', hipCm: '118', hipIn: '46.5', inseamCm: '83', inseamIn: '32.7' },
  ];

  return (
    <div
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200"
      onClick={() => setIsSizeGuideOpen(false)}
    >
      <div
        className="bg-[#121212] border border-white/15 max-w-2xl w-full p-6 sm:p-8 text-white shadow-2xl overflow-y-auto max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <div className="flex items-center gap-2">
            <Ruler className="w-5 h-5 text-neutral-300" />
            <h3 className="font-display font-bold uppercase tracking-wider text-lg text-white">
              3KO Architectural Fit Guide
            </h3>
          </div>
          <button
            onClick={() => setIsSizeGuideOpen(false)}
            className="text-neutral-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Category & Unit Selector */}
        <div className="flex items-center justify-between mt-6 mb-4 flex-wrap gap-4">
          <div className="flex border border-white/15 text-xs font-semibold uppercase tracking-wider">
            <button
              onClick={() => setCategory('tops')}
              className={`px-4 py-2 transition-colors ${
                category === 'tops' ? 'bg-white text-[#080808]' : 'text-neutral-400 hover:text-white'
              }`}
            >
              Tops & Outerwear
            </button>
            <button
              onClick={() => setCategory('bottoms')}
              className={`px-4 py-2 transition-colors ${
                category === 'bottoms' ? 'bg-white text-[#080808]' : 'text-neutral-400 hover:text-white'
              }`}
            >
              Trousers & Chinos
            </button>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="text-neutral-400">UNITS:</span>
            <button
              onClick={() => setUnit('cm')}
              className={`px-2 py-1 border ${
                unit === 'cm' ? 'border-white text-white font-bold bg-white/10' : 'border-white/10 text-neutral-400'
              }`}
            >
              CM
            </button>
            <button
              onClick={() => setUnit('in')}
              className={`px-2 py-1 border ${
                unit === 'in' ? 'border-white text-white font-bold bg-white/10' : 'border-white/10 text-neutral-400'
              }`}
            >
              INCHES
            </button>
          </div>
        </div>

        {/* Size Table */}
        <div className="overflow-x-auto border border-white/10 mb-6 font-mono text-xs">
          <table className="w-full text-left">
            <thead className="bg-[#181818] text-neutral-400 border-b border-white/10 uppercase tracking-wider">
              <tr>
                <th className="p-3">Size</th>
                {category === 'tops' ? (
                  <>
                    <th className="p-3">Chest Width</th>
                    <th className="p-3">Total Length</th>
                    <th className="p-3">Shoulder</th>
                  </>
                ) : (
                  <>
                    <th className="p-3">Waist</th>
                    <th className="p-3">Hip</th>
                    <th className="p-3">Inseam</th>
                  </>
                )}
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-neutral-200">
              {category === 'tops'
                ? topsData.map((row) => (
                    <tr key={row.size} className="hover:bg-white/5">
                      <td className="p-3 font-bold text-white">{row.size}</td>
                      <td className="p-3">{unit === 'cm' ? row.chestCm : row.chestIn}</td>
                      <td className="p-3">{unit === 'cm' ? row.lengthCm : row.lengthIn}</td>
                      <td className="p-3">{unit === 'cm' ? row.shoulderCm : row.shoulderIn}</td>
                    </tr>
                  ))
                : bottomsData.map((row) => (
                    <tr key={row.size} className="hover:bg-white/5">
                      <td className="p-3 font-bold text-white">{row.size}</td>
                      <td className="p-3">{unit === 'cm' ? row.waistCm : row.waistIn}</td>
                      <td className="p-3">{unit === 'cm' ? row.hipCm : row.hipIn}</td>
                      <td className="p-3">{unit === 'cm' ? row.inseamCm : row.inseamIn}</td>
                    </tr>
                  ))}
            </tbody>
          </table>
        </div>

        {/* Fit Philosophy Notes */}
        <div className="space-y-3 text-xs text-neutral-400 font-sans border-t border-white/10 pt-4">
          <p>
            <strong className="text-white">3KO STREET:</strong> Features an intentional relaxed streetwear silhouette with dropped shoulders and generous body drape. Choose your standard size for the intended oversized look.
          </p>
          <p>
            <strong className="text-white">3KO FORM:</strong> Cut with clean lines tailored for contemporary smart-casual settings. Fits true to size with flattering proportions around the collar, chest, and arms.
          </p>
        </div>
      </div>
    </div>
  );
};
