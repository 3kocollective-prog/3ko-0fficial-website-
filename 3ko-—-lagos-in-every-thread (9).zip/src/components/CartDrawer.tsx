import React, { useState } from 'react';
import { X, Trash2, Plus, Minus, ArrowRight, ShieldCheck, ShoppingBag, Package } from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const CartDrawer: React.FC = () => {
  const {
    cart,
    isCartOpen,
    setIsCartOpen,
    updateQuantity,
    toggleCartItemBox,
    removeFromCart,
    subtotal,
    currency,
    formatPrice,
    formatCurrentPrice,
    freeShippingThreshold,
    setIsCheckoutOpen,
    navigateTo,
  } = useShop();

  const [promoCode, setPromoCode] = useState('');
  const [discountApplied, setDiscountApplied] = useState(false);
  const [promoError, setPromoError] = useState('');

  if (!isCartOpen) return null;

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    if (promoCode.trim().toUpperCase() === 'LAGOSFIRST' || promoCode.trim().toUpperCase() === '3KO10') {
      setDiscountApplied(true);
      setPromoError('');
    } else {
      setPromoError('Invalid code. Use LAGOSFIRST for 10% off.');
    }
  };

  const discountAmount = discountApplied ? Math.round(subtotal * 0.1) : 0;
  const finalTotal = Math.max(0, subtotal - discountAmount);

  const remainingForFreeShipping = Math.max(0, freeShippingThreshold - subtotal);
  const progressPercent = Math.min(100, Math.round((subtotal / freeShippingThreshold) * 100));

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/75 backdrop-blur-xs flex justify-end animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-md bg-[#0e0e0e] text-white h-full flex flex-col shadow-2xl border-l border-white/10"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Drawer Header */}
        <div className="p-6 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <ShoppingBag className="w-5 h-5 text-neutral-300" />
            <h3 className="font-display font-extrabold uppercase tracking-wider text-base text-white">
              Shopping Bag ({cart.reduce((a, b) => a + b.quantity, 0)})
            </h3>
          </div>
          <button
            onClick={() => setIsCartOpen(false)}
            className="p-1.5 text-neutral-400 hover:text-white transition-colors cursor-pointer"
            aria-label="Close cart"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Free Shipping Progress Indicator */}
        <div className="px-6 py-3 bg-[#161616] border-b border-white/5 text-xs text-neutral-300">
          <div className="flex justify-between items-center mb-1.5 text-[11px] font-mono">
            {progressPercent >= 100 ? (
              <span className="text-emerald-400 font-semibold">
                ✓ Free Lagos Express Delivery Unlocked!
              </span>
            ) : (
              <span>
                Add{' '}
                <span className="text-white font-bold">
                  {formatCurrentPrice(remainingForFreeShipping)}
                </span>{' '}
                more for complimentary delivery
              </span>
            )}
            <span className="font-bold text-neutral-400">{progressPercent}%</span>
          </div>
          <div className="w-full bg-neutral-800 h-1.5 overflow-hidden rounded-full">
            <div
              className="bg-lime-400 h-full transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* Cart Items List */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center py-12">
              <ShoppingBag className="w-12 h-12 text-neutral-600 mb-4 stroke-1" />
              <h4 className="font-display font-bold uppercase text-lg text-white mb-2">
                Your Bag is Empty
              </h4>
              <p className="text-xs text-neutral-400 max-w-xs mb-6 font-sans">
                Explore the contemporary streetwear and refined form silhouettes inspired by Lagos.
              </p>
              <button
                onClick={() => {
                  setIsCartOpen(false);
                  navigateTo('/shop');
                }}
                className="bg-white text-[#080808] px-6 py-3 text-xs font-bold uppercase tracking-widest hover:bg-neutral-200 transition-colors cursor-pointer"
              >
                Shop Collections
              </button>
            </div>
          ) : (
            cart.map((item) => {
              const garmentPrice =
                currency === 'USD'
                  ? item.product.priceUSD
                  : currency === 'GBP'
                  ? item.product.priceGBP
                  : item.product.priceNGN;

              const boxAddon = item.includeCollectorBox
                ? currency === 'USD'
                  ? item.boxPriceUSD || 12
                  : currency === 'GBP'
                  ? item.boxPriceGBP || 10
                  : item.boxPriceNGN || 15000
                : 0;

              const totalUnit = garmentPrice + boxAddon;
              const hasBoxOption = !!item.product.boxPackaging?.available;

              return (
                <div
                  key={item.id}
                  className="flex flex-col p-3 bg-[#141414] border border-white/5 relative group transition-colors hover:border-white/10"
                >
                  <div className="flex gap-4">
                    {/* Thumbnail */}
                    <div
                      onClick={() => {
                        setIsCartOpen(false);
                        navigateTo(`/product/${item.product.slug}`);
                      }}
                      className="w-20 h-24 bg-neutral-900 overflow-hidden shrink-0 cursor-pointer border border-white/5 relative"
                    >
                      <img
                        src={item.product.images[0]}
                        alt={item.product.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      />
                      {item.includeCollectorBox && (
                        <span className="absolute top-1 left-1 bg-amber-400 text-black text-[9px] font-mono font-bold px-1 py-0.5 leading-none">
                          BOX
                        </span>
                      )}
                    </div>

                    {/* Info */}
                    <div className="flex-1 flex flex-col justify-between">
                      <div>
                        <div className="flex justify-between items-start gap-2">
                          <h4
                            onClick={() => {
                              setIsCartOpen(false);
                              navigateTo(`/product/${item.product.slug}`);
                            }}
                            className="font-display font-bold text-xs uppercase tracking-tight text-white hover:text-neutral-300 cursor-pointer line-clamp-1"
                          >
                            {item.product.name}
                          </h4>
                          <button
                            onClick={() => removeFromCart(item.id)}
                            className="text-neutral-500 hover:text-red-400 p-1 cursor-pointer"
                            aria-label="Remove item"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        <div className="flex items-center gap-2 text-[11px] text-neutral-400 mt-1 font-mono">
                          <span>Size: {item.selectedSize}</span>
                          <span>·</span>
                          <span>{item.selectedColor}</span>
                        </div>

                        {/* Real-time Garment Availability Badge */}
                        <div className="mt-1.5">
                          {item.product.isPreOrder ? (
                            <span className="inline-flex items-center gap-1 text-[9px] font-mono uppercase text-cyan-300 bg-cyan-950/80 px-1.5 py-0.5 border border-cyan-500/30">
                              ● Pre-Order Allocation
                            </span>
                          ) : item.product.availability === 'out_of_stock' ? (
                            <span className="inline-flex items-center gap-1 text-[9px] font-mono uppercase text-red-400 bg-red-950/80 px-1.5 py-0.5 border border-red-500/30">
                              ● Sold Out
                            </span>
                          ) : item.product.availability === 'low_stock' ? (
                            <span className="inline-flex items-center gap-1 text-[9px] font-mono uppercase text-amber-300 bg-amber-950/80 px-1.5 py-0.5 border border-amber-500/30">
                              ● Low Stock ({item.product.stockQuantity ?? 3} left)
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-[9px] font-mono uppercase text-emerald-400 bg-emerald-950/60 px-1.5 py-0.5 border border-emerald-500/30">
                              ● In Stock (Ready to Dispatch)
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center justify-between mt-3 pt-2 border-t border-white/5">
                        {/* Quantity Stepper */}
                        <div className="flex items-center border border-white/10 bg-[#1c1c1c]">
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            className="p-1 px-2 text-neutral-400 hover:text-white cursor-pointer"
                            aria-label="Decrease quantity"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="px-2 text-xs font-mono">{item.quantity}</span>
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            className="p-1 px-2 text-neutral-400 hover:text-white cursor-pointer"
                            aria-label="Increase quantity"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        {/* Price */}
                        <span className="font-mono text-xs font-semibold text-white">
                          {currency === 'USD'
                            ? `$${totalUnit * item.quantity}`
                            : currency === 'GBP'
                            ? `£${totalUnit * item.quantity}`
                            : `₦${(totalUnit * item.quantity).toLocaleString()}`}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Signature Collector Box Packaging Module */}
                  {hasBoxOption && (
                    <div className="mt-2.5 pt-2 border-t border-white/5 bg-[#0f0f0f] -mx-3 -mb-3 p-2.5 px-3 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        {item.product.boxPackaging?.boxImage ? (
                          <img
                            src={item.product.boxPackaging.boxImage}
                            alt="Box packaging"
                            className="w-8 h-8 object-cover border border-white/10 shrink-0 bg-black"
                          />
                        ) : (
                          <Package className="w-4 h-4 text-amber-400 shrink-0" />
                        )}
                        <div className="text-[10px] leading-tight font-mono">
                          <span className={item.includeCollectorBox ? 'text-amber-300 font-bold' : 'text-neutral-400'}>
                            {item.includeCollectorBox ? 'Signature Collector Box Included' : 'Minimalist Eco-Packaging'}
                          </span>
                          <span className="block text-neutral-400 text-[9px]">
                            {item.includeCollectorBox ? 'Complimentary 1200 GSM rigid box' : 'Reduced footprint (-₦5,000)'}
                          </span>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => toggleCartItemBox(item.id)}
                        className={`text-[9px] font-mono px-2 py-1 border transition-colors cursor-pointer uppercase ${
                          item.includeCollectorBox
                            ? 'bg-amber-400/10 text-amber-300 border-amber-400/40 hover:bg-neutral-800 hover:text-white'
                            : 'border-white/20 text-neutral-300 hover:border-white hover:text-white'
                        }`}
                      >
                        {item.includeCollectorBox ? 'Eco Option' : 'Restore Box'}
                      </button>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Drawer Footer Summary */}
        {cart.length > 0 && (
          <div className="p-6 border-t border-white/10 bg-[#111111] space-y-4">
            {/* Promo Code Input */}
            <form onSubmit={handleApplyPromo} className="flex gap-2">
              <input
                type="text"
                placeholder="PROMO CODE (e.g. LAGOSFIRST)"
                value={promoCode}
                onChange={(e) => setPromoCode(e.target.value)}
                className="flex-1 bg-[#1a1a1a] border border-white/10 px-3 py-2 text-xs uppercase tracking-wider text-white placeholder-neutral-500 focus:outline-none focus:border-white"
              />
              <button
                type="submit"
                className="bg-neutral-800 hover:bg-neutral-700 text-white px-3.5 py-2 text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer"
              >
                Apply
              </button>
            </form>
            {promoError && <p className="text-[11px] text-red-400 font-mono">{promoError}</p>}
            {discountApplied && (
              <p className="text-[11px] text-emerald-400 font-mono">
                10% Lagos Debut discount activated (-
                {currency === 'USD' ? `$${discountAmount}` : currency === 'GBP' ? `£${discountAmount}` : `₦${discountAmount.toLocaleString()}`}
                )
              </p>
            )}

            {/* Calculations */}
            <div className="space-y-1.5 text-xs text-neutral-400 font-mono pt-2 border-t border-white/5">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="text-white">
                  {currency === 'USD' ? `$${subtotal}` : currency === 'GBP' ? `£${subtotal}` : `₦${subtotal.toLocaleString()}`}
                </span>
              </div>
              {discountApplied && (
                <div className="flex justify-between text-emerald-400">
                  <span>Promo (LAGOSFIRST)</span>
                  <span>
                    -{currency === 'USD' ? `$${discountAmount}` : currency === 'GBP' ? `£${discountAmount}` : `₦${discountAmount.toLocaleString()}`}
                  </span>
                </div>
              )}
              <div className="flex justify-between text-neutral-400">
                <span>Estimated Shipping</span>
                <span className="text-white">Calculated at checkout</span>
              </div>
              <div className="flex justify-between text-sm font-bold text-white pt-2 border-t border-white/10 font-sans">
                <span className="uppercase tracking-wider">Estimated Total</span>
                <span className="font-mono">
                  {currency === 'USD' ? `$${finalTotal}` : currency === 'GBP' ? `£${finalTotal}` : `₦${finalTotal.toLocaleString()}`}
                </span>
              </div>
            </div>

            {/* Checkout Action Button */}
            <button
              onClick={() => {
                setIsCartOpen(false);
                setIsCheckoutOpen(true);
              }}
              className="w-full bg-white text-[#080808] font-bold py-3.5 text-xs uppercase tracking-widest hover:bg-neutral-200 transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg"
            >
              <span>CHECKOUT NOW</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="flex items-center justify-center gap-2 text-[10px] text-neutral-500 font-sans">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Secure checkout. Shipped directly from Lagos, Nigeria.</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
