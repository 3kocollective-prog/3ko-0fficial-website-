import React, { useState } from 'react';
import { ArrowRight, Instagram, X } from 'lucide-react';
import { useShop } from '../context/ShopContext';

interface SocialPost {
  id: string;
  image: string;
  title: string;
  caption: string;
  tag: string;
  productSlug?: string;
}

const SOCIAL_POSTS: SocialPost[] = [
  {
    id: 'post-1',
    image: '/images/social/social_1_model_back.jpg',
    title: 'Ikoyi Back Graphic Tee',
    caption: 'Lekki-Ikoyi Link Bridge meets the 3KO bubble wordmark. Heavyweight 280 GSM cotton engineered for the city.',
    tag: '#3KOStreet #Lagos001',
    productSlug: '/product/lagos-001-bridge-tee',
  },
  {
    id: 'post-2',
    image: '/images/social/social_2_polo_embroidery.jpg',
    title: 'Lagos 005 Pique Detail',
    caption: 'Subtle chest embroidery on custom-milled long-staple cotton pique. Sky-blue inspired by Tarkwa Bay waves.',
    tag: '#3KOForm #TarkwaBay',
    productSlug: '/product/lagos-005-polo',
  },
  {
    id: 'post-3',
    image: '/images/social/social_3_bridge_bw.jpg',
    title: 'The Monolith Overpass',
    caption: 'Where Ikoyi connects with Lekki. Architectural lines that inspired the geometric cut of our outerwear.',
    tag: '#3KOLagos #Architecture',
    productSlug: '/collections/001-ikoyi',
  },
  {
    id: 'post-4',
    image: '/images/social/social_4_cap.jpg',
    title: '3KO 3D Puff Cap',
    caption: 'Structured 6-panel washed twill featuring high-relief bubble typography and brass hardware.',
    tag: '#3KOAccessories #LagosMade',
    productSlug: '/product/lagos-001-cap',
  },
  {
    id: 'post-5',
    image: '/images/social/social_5_street_walk.jpg',
    title: 'Contemporary Lagosian in Motion',
    caption: 'Street tailoring styled with ease. Walking the tree-lined avenues of old Ikoyi in midday light.',
    tag: '#LagosInEveryThread',
    productSlug: '/street',
  },
  {
    id: 'post-6',
    image: '/images/social/social_6_label_packaging.jpg',
    title: 'Archival Woven Brand Label',
    caption: 'High-density damask woven brand label stitched inside every collector piece. Tactile perfection in every stitch.',
    tag: '#Craftsmanship #LagosDesign',
    productSlug: '/about',
  },
];

export const SocialSection: React.FC = () => {
  const { navigateTo } = useShop();
  const [selectedPost, setSelectedPost] = useState<SocialPost | null>(null);

  return (
    <section className="w-full bg-white text-[#080808] py-16 sm:py-20 lg:py-24 px-6 sm:px-10 lg:px-12 border-b border-black/10">
      <div className="max-w-[1440px] mx-auto">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 mb-8 sm:mb-12">
          <div>
            <span className="text-xs sm:text-[13px] font-bold tracking-[0.2em] uppercase text-neutral-500 block mb-1">
              FOLLOW THE JOURNEY
            </span>
            <h2 className="font-display font-black text-4xl sm:text-5xl lg:text-7xl uppercase tracking-tight text-[#080808]">
              @3KO
            </h2>
          </div>

          <a
            href="https://instagram.com"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-xs sm:text-sm font-bold tracking-widest uppercase text-[#080808] hover:opacity-75 transition-opacity border-b-2 border-[#080808] pb-1 cursor-pointer w-fit"
          >
            <span>FOLLOW US ON INSTAGRAM</span>
            <ArrowRight className="w-4 h-4" />
          </a>
        </div>

        {/* 6-Image Editorial Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2 sm:gap-3">
          {SOCIAL_POSTS.map((post) => (
            <div
              key={post.id}
              onClick={() => setSelectedPost(post)}
              className="relative aspect-square overflow-hidden group cursor-pointer bg-neutral-200"
            >
              <img
                src={post.image}
                alt={post.title}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-108"
                referrerPolicy="no-referrer"
              />
              {/* Subtle hover overlay with Instagram icon */}
              <div className="absolute inset-0 bg-[#080808]/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col items-center justify-center p-3 text-center text-white">
                <Instagram className="w-6 h-6 mb-1 text-white" />
                <span className="text-[11px] font-bold uppercase tracking-wider line-clamp-1">
                  {post.title}
                </span>
                <span className="text-[9px] text-neutral-300 font-mono mt-1">
                  TAP TO VIEW LOOK
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Social Post Detail Modal */}
      {selectedPost && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setSelectedPost(null)}
        >
          <div
            className="bg-[#121212] border border-white/15 max-w-lg w-full overflow-hidden text-white shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative aspect-video w-full bg-neutral-900">
              <img
                src={selectedPost.image}
                alt={selectedPost.title}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <button
                onClick={() => setSelectedPost(null)}
                className="absolute top-3 right-3 p-1.5 bg-black/60 text-white rounded-full hover:bg-black transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6">
              <div className="flex items-center justify-between text-xs text-neutral-400 mb-2">
                <span className="font-mono">{selectedPost.tag}</span>
                <span>@3KO OFFICAL</span>
              </div>
              <h4 className="font-display font-bold text-xl uppercase tracking-tight text-white mb-2">
                {selectedPost.title}
              </h4>
              <p className="text-sm text-neutral-300 leading-relaxed mb-6 font-normal">
                {selectedPost.caption}
              </p>

              {selectedPost.productSlug && (
                <button
                  onClick={() => {
                    const slug = selectedPost.productSlug!;
                    setSelectedPost(null);
                    navigateTo(slug);
                  }}
                  className="w-full bg-white text-[#080808] font-bold py-3 text-xs uppercase tracking-widest hover:bg-neutral-200 transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>EXPLORE THIS PIECE</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
