import React from 'react';
import { ArrowRight } from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const StreetFormSection: React.FC = () => {
  const { navigateTo, storeSettings } = useShop();

  const streetImg = storeSettings.banners?.streetwearBanner || '/images/brand/street_panel.jpg';
  const formImg = storeSettings.banners?.smartwearBanner || '/images/brand/form_panel.jpg';

  return (
    <section className="w-full bg-[#080808] border-t border-b border-white/10">
      <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-white/10">
        {/* LEFT PANEL: 3KO STREET */}
        <div
          onClick={() => navigateTo('/street')}
          className="relative min-h-[460px] lg:min-h-[580px] p-8 sm:p-12 lg:p-16 flex flex-col justify-end overflow-hidden group cursor-pointer bg-neutral-950"
        >
          {/* Background Image */}
          <div className="absolute inset-0 z-0">
            <img
              src={streetImg}
              alt="3KO STREET Collection campaign look"
              className="w-full h-full object-cover object-center filter brightness-[0.82] transition-transform duration-700 ease-out group-hover:scale-105"
              referrerPolicy="no-referrer"
            />
            {/* Scrim gradient to elevate text */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#080808]/90 via-[#080808]/40 to-transparent" />
          </div>

          {/* Panel Content */}
          <div className="relative z-10 flex flex-col items-start max-w-md">
            <span className="text-xs lg:text-[13px] font-semibold tracking-[0.2em] text-neutral-300 uppercase mb-2">
              BOLD LAGOS STREETWEAR
            </span>
            <h2 className="font-display font-extrabold text-4xl sm:text-5xl lg:text-6xl text-white tracking-tight uppercase mb-3">
              3KO STREET
            </h2>
            <p className="text-sm sm:text-base text-neutral-300 font-light mb-6 tracking-wide">
              Bold. Urban. Expressive.
            </p>
            <div className="inline-flex items-center gap-2 text-xs sm:text-sm font-bold tracking-widest text-white uppercase border-b border-white/60 pb-1 group-hover:border-white transition-all">
              <span>SHOP STREET</span>
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1.5" />
            </div>
          </div>
        </div>

        {/* RIGHT PANEL: 3KO FORM */}
        <div
          onClick={() => navigateTo('/form')}
          className="relative min-h-[460px] lg:min-h-[580px] p-8 sm:p-12 lg:p-16 flex flex-col justify-end overflow-hidden group cursor-pointer bg-neutral-900"
        >
          {/* Background Image */}
          <div className="absolute inset-0 z-0">
            <img
              src={formImg}
              alt="3KO FORM Collection campaign look with sky blue polo"
              className="w-full h-full object-cover object-center filter brightness-[0.88] transition-transform duration-700 ease-out group-hover:scale-105"
              referrerPolicy="no-referrer"
            />
            {/* Scrim gradient to elevate text */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#080808]/90 via-[#080808]/35 to-transparent" />

          </div>

          {/* Panel Content */}
          <div className="relative z-10 flex flex-col items-start max-w-md">
            <span className="text-xs lg:text-[13px] font-semibold tracking-[0.2em] text-neutral-300 uppercase mb-2">
              REFINED SMART CASUAL
            </span>
            <h2 className="font-display font-extrabold text-4xl sm:text-5xl lg:text-6xl text-white tracking-tight uppercase mb-3">
              3KO FORM
            </h2>
            <p className="text-sm sm:text-base text-neutral-300 font-light mb-6 tracking-wide">
              Clean. Refined. Versatile.
            </p>
            <div className="inline-flex items-center gap-2 text-xs sm:text-sm font-bold tracking-widest text-white uppercase border-b border-white/60 pb-1 group-hover:border-white transition-all">
              <span>SHOP FORM</span>
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1.5" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
