import React, { useState } from 'react';
import { X, ShieldCheck, CheckCircle2, Truck, CreditCard, Lock, ArrowRight, Printer } from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { Order, normalizePaymentStatus, normalizeOrderStatus } from '../types';
import {
  initializeAuthoritativeCheckout,
  verifyPaymentReference,
} from '../lib/paystack';

export const CheckoutModal: React.FC = () => {
  const {
    cart,
    subtotal,
    currency,
    formatPrice,
    isCheckoutOpen,
    setIsCheckoutOpen,
    clearCart,
    showToast,
    theme,
    currentUser,
  } = useShop();

  const isDark = theme === 'dark';

  const [step, setStep] = useState<'details' | 'payment' | 'confirmed'>('details');
  const [isProcessing, setIsProcessing] = useState(false);
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationMsg, setVerificationMsg] = useState<string | null>(null);

  // Form states initialized empty with ZERO hardcoded personal or test data
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    country: 'Nigeria',
    postalCode: '',
    deliveryNotes: '',
  });

  const [shippingMethod, setShippingMethod] = useState<'lagos-sameday' | 'nationwide' | 'dhl-intl'>('lagos-sameday');
  const [paymentMethod, setPaymentMethod] = useState<'paystack' | 'card' | 'transfer' | 'apple-pay'>('paystack');

  if (!isCheckoutOpen) return null;

  const shippingCosts = {
    'lagos-sameday': currency === 'USD' ? 5 : currency === 'GBP' ? 4 : 4500,
    'nationwide': currency === 'USD' ? 8 : currency === 'GBP' ? 6 : 7500,
    'dhl-intl': currency === 'USD' ? 35 : currency === 'GBP' ? 28 : 45000,
  };

  const shippingFee = subtotal > 100000 && shippingMethod === 'lagos-sameday' ? 0 : shippingCosts[shippingMethod];
  const grandTotal = subtotal + shippingFee;

  const handleDetailsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('payment');
  };

  const handleFinalPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    try {
      // 1. BACKEND AUTHORITATIVE INITIALIZATION
      // The browser does not calculate the payable total. The backend computes prices, shipping, and locked offers.
      const checkoutSession = await initializeAuthoritativeCheckout({
        items: cart,
        customer: {
          fullName: formData.fullName,
          email: formData.email,
          phone: formData.phone,
          address: formData.address,
          city: formData.city,
          state: formData.state || 'Lagos',
          country: formData.country || 'Nigeria',
          postalCode: formData.postalCode,
        },
        shippingMethod,
        currency,
        userId: currentUser?.uid,
      });

      if (checkoutSession.success && checkoutSession.order) {
        setCompletedOrder(checkoutSession.order);
        clearCart();
        setIsProcessing(false);
        setStep('confirmed');
        showToast(`Order ${checkoutSession.orderNumber} created. Status: PENDING PAYMENT.`);
      } else {
        throw new Error(checkoutSession.error || 'Failed to initialize authoritative order.');
      }
    } catch (err: any) {
      console.error('Checkout error:', err);
      setIsProcessing(false);
      showToast(err.message || 'Order initialization issue. Please check network connection.');
    }
  };

  const handleClose = () => {
    setIsCheckoutOpen(false);
    setStep('details');
  };

  const handleVerifyPayment = async () => {
    if (!completedOrder) return;
    setIsVerifying(true);
    setVerificationMsg(null);
    try {
      const ref = completedOrder.paymentReference || completedOrder.orderNumber;
      const res = await verifyPaymentReference(ref, completedOrder.orderNumber);
      if (res.success && res.order) {
        setCompletedOrder(res.order);
        showToast('Payment verified successfully!');
      } else {
        setVerificationMsg(res.message || 'Payment has not been confirmed yet.');
        showToast(res.message || 'Payment not confirmed yet.');
      }
    } catch (err: any) {
      setVerificationMsg(err.message || 'Verification request failed.');
      showToast(err.message || 'Verification request failed.');
    } finally {
      setIsVerifying(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div
        className={`border max-w-3xl w-full shadow-2xl overflow-hidden my-auto transition-colors duration-200 ${
          isDark ? 'bg-[#101010] border-white/15 text-white' : 'bg-white border-black/15 text-neutral-900'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className={`p-5 sm:p-6 border-b flex items-center justify-between ${
          isDark ? 'bg-[#0a0a0a] border-white/10' : 'bg-neutral-50 border-black/10'
        }`}>
          <div className="flex items-center gap-3">
            <img
              src="/images/brand/logo_white_transparent.png"
              alt="3KO Logo"
              className={`h-7 w-auto object-contain ${!isDark ? 'invert' : ''}`}
            />
            <span className={isDark ? 'text-white/30' : 'text-black/30'}>|</span>
            <span className={`font-display font-bold uppercase tracking-wider text-xs sm:text-sm ${
              isDark ? 'text-neutral-300' : 'text-neutral-700'
            }`}>
              {step === 'details' && 'Step 1: Shipping Details'}
              {step === 'payment' && 'Step 2: Secure Payment'}
              {step === 'confirmed' && 'Order Confirmed'}
            </span>
          </div>

          <button
            onClick={handleClose}
            className={`p-1 transition-colors ${isDark ? 'text-neutral-400 hover:text-white' : 'text-neutral-500 hover:text-black'}`}
            aria-label="Close checkout"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-8 max-h-[80vh] overflow-y-auto">
          {step === 'details' && (
            <form onSubmit={handleDetailsSubmit} className="space-y-6">
              {/* Customer Contact */}
              <div>
                <h4 className={`text-xs uppercase tracking-widest font-bold mb-3 ${
                  isDark ? 'text-neutral-400' : 'text-neutral-600'
                }`}>
                  1. Contact Information
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className={`block text-[11px] uppercase tracking-wider mb-1 ${
                      isDark ? 'text-neutral-400' : 'text-neutral-500'
                    }`}>
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Enter your full name"
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      className={`w-full border px-3.5 py-2.5 text-xs focus:outline-none transition-colors ${
                        isDark
                          ? 'bg-[#181818] border-white/10 text-white placeholder-neutral-500 focus:border-white'
                          : 'bg-neutral-50 border-black/15 text-black placeholder-neutral-400 focus:border-black'
                      }`}
                    />
                  </div>
                  <div>
                    <label className={`block text-[11px] uppercase tracking-wider mb-1 ${
                      isDark ? 'text-neutral-400' : 'text-neutral-500'
                    }`}>
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="Enter your email address"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className={`w-full border px-3.5 py-2.5 text-xs focus:outline-none transition-colors ${
                        isDark
                          ? 'bg-[#181818] border-white/10 text-white placeholder-neutral-500 focus:border-white'
                          : 'bg-neutral-50 border-black/15 text-black placeholder-neutral-400 focus:border-black'
                      }`}
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className={`block text-[11px] uppercase tracking-wider mb-1 ${
                      isDark ? 'text-neutral-400' : 'text-neutral-500'
                    }`}>
                      Phone Number (For Lagos Dispatch Rider) *
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="Enter your phone number"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className={`w-full border px-3.5 py-2.5 text-xs focus:outline-none transition-colors ${
                        isDark
                          ? 'bg-[#181818] border-white/10 text-white placeholder-neutral-500 focus:border-white'
                          : 'bg-neutral-50 border-black/15 text-black placeholder-neutral-400 focus:border-black'
                      }`}
                    />
                  </div>
                </div>
              </div>

              {/* Delivery Address */}
              <div className={`pt-4 border-t ${isDark ? 'border-white/10' : 'border-black/10'}`}>
                <h4 className={`text-xs uppercase tracking-widest font-bold mb-3 ${
                  isDark ? 'text-neutral-400' : 'text-neutral-600'
                }`}>
                  2. Delivery Address
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="sm:col-span-2">
                    <label className={`block text-[11px] uppercase tracking-wider mb-1 ${
                      isDark ? 'text-neutral-400' : 'text-neutral-500'
                    }`}>
                      Street Address *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Enter your delivery address"
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      className={`w-full border px-3.5 py-2.5 text-xs focus:outline-none transition-colors ${
                        isDark
                          ? 'bg-[#181818] border-white/10 text-white placeholder-neutral-500 focus:border-white'
                          : 'bg-neutral-50 border-black/15 text-black placeholder-neutral-400 focus:border-black'
                      }`}
                    />
                  </div>
                  <div>
                    <label className={`block text-[11px] uppercase tracking-wider mb-1 ${
                      isDark ? 'text-neutral-400' : 'text-neutral-500'
                    }`}>
                      City *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Enter your city"
                      value={formData.city}
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                      className={`w-full border px-3.5 py-2.5 text-xs focus:outline-none transition-colors ${
                        isDark
                          ? 'bg-[#181818] border-white/10 text-white placeholder-neutral-500 focus:border-white'
                          : 'bg-neutral-50 border-black/15 text-black placeholder-neutral-400 focus:border-black'
                      }`}
                    />
                  </div>
                  <div>
                    <label className={`block text-[11px] uppercase tracking-wider mb-1 ${
                      isDark ? 'text-neutral-400' : 'text-neutral-500'
                    }`}>
                      State / Province *
                    </label>
                    <select
                      value={formData.state}
                      onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                      className={`w-full border px-3.5 py-2.5 text-xs focus:outline-none transition-colors ${
                        isDark
                          ? 'bg-[#181818] border-white/10 text-white focus:border-white'
                          : 'bg-neutral-50 border-black/15 text-black focus:border-black'
                      }`}
                    >
                      <option value="Lagos">Lagos (Island & Mainland)</option>
                      <option value="Abuja">Abuja (FCT)</option>
                      <option value="Rivers">Rivers (Port Harcourt)</option>
                      <option value="Oyo">Oyo (Ibadan)</option>
                      <option value="Enugu">Enugu</option>
                      <option value="Delta">Delta</option>
                      <option value="International">International Address</option>
                    </select>
                  </div>
                  <div>
                    <label className={`block text-[11px] uppercase tracking-wider mb-1 ${
                      isDark ? 'text-neutral-400' : 'text-neutral-500'
                    }`}>
                      Country *
                    </label>
                    <select
                      value={formData.country}
                      onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                      className={`w-full border px-3.5 py-2.5 text-xs focus:outline-none transition-colors ${
                        isDark
                          ? 'bg-[#181818] border-white/10 text-white focus:border-white'
                          : 'bg-neutral-50 border-black/15 text-black focus:border-black'
                      }`}
                    >
                      <option value="Nigeria">Nigeria</option>
                      <option value="United Kingdom">United Kingdom</option>
                      <option value="United States">United States</option>
                      <option value="Canada">Canada</option>
                      <option value="Ghana">Ghana</option>
                      <option value="Other">Other Global Destination</option>
                    </select>
                  </div>
                  <div>
                    <label className={`block text-[11px] uppercase tracking-wider mb-1 ${
                      isDark ? 'text-neutral-400' : 'text-neutral-500'
                    }`}>
                      Postal / Area Code
                    </label>
                    <input
                      type="text"
                      placeholder="Enter postal / area code (optional)"
                      value={formData.postalCode}
                      onChange={(e) => setFormData({ ...formData, postalCode: e.target.value })}
                      className={`w-full border px-3.5 py-2.5 text-xs focus:outline-none transition-colors ${
                        isDark
                          ? 'bg-[#181818] border-white/10 text-white placeholder-neutral-500 focus:border-white'
                          : 'bg-neutral-50 border-black/15 text-black placeholder-neutral-400 focus:border-black'
                      }`}
                    />
                  </div>
                </div>
              </div>

              {/* Shipping Method Option */}
              <div className={`pt-4 border-t ${isDark ? 'border-white/10' : 'border-black/10'}`}>
                <h4 className={`text-xs uppercase tracking-widest font-bold mb-3 ${isDark ? 'text-neutral-400' : 'text-neutral-600'}`}>
                  3. Shipping Method
                </h4>
                <div className="space-y-2">
                  <label
                    className={`flex items-center justify-between p-3.5 border cursor-pointer transition-colors ${
                      shippingMethod === 'lagos-sameday'
                        ? isDark ? 'border-white bg-white/5' : 'border-black bg-black/5'
                        : isDark ? 'border-white/10 hover:border-white/20' : 'border-black/15 hover:border-black/30'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <input
                        type="radio"
                        name="shipping"
                        checked={shippingMethod === 'lagos-sameday'}
                        onChange={() => setShippingMethod('lagos-sameday')}
                        className={isDark ? 'accent-white' : 'accent-black'}
                      />
                      <div>
                        <span className={`text-xs font-bold block ${isDark ? 'text-white' : 'text-black'}`}>
                          Lagos Same-Day Dispatch (Island & Mainland)
                        </span>
                        <span className={`text-[11px] ${isDark ? 'text-neutral-400' : 'text-neutral-600'}`}>
                          Hand-delivered in 3KO collectible packaging by courier
                        </span>
                      </div>
                    </div>
                    <span className={`font-mono text-xs font-semibold ${isDark ? 'text-white' : 'text-black'}`}>
                      {shippingFee === 0 ? 'FREE' : formatPrice(4500, 5, 4)}
                    </span>
                  </label>

                  <label
                    className={`flex items-center justify-between p-3.5 border cursor-pointer transition-colors ${
                      shippingMethod === 'nationwide'
                        ? isDark ? 'border-white bg-white/5' : 'border-black bg-black/5'
                        : isDark ? 'border-white/10 hover:border-white/20' : 'border-black/15 hover:border-black/30'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <input
                        type="radio"
                        name="shipping"
                        checked={shippingMethod === 'nationwide'}
                        onChange={() => setShippingMethod('nationwide')}
                        className={isDark ? 'accent-white' : 'accent-black'}
                      />
                      <div>
                        <span className={`text-xs font-bold block ${isDark ? 'text-white' : 'text-black'}`}>
                          Nationwide Express (Nigeria-wide)
                        </span>
                        <span className={`text-[11px] ${isDark ? 'text-neutral-400' : 'text-neutral-600'}`}>
                          2–3 business days via GIG Express with tracking
                        </span>
                      </div>
                    </div>
                    <span className={`font-mono text-xs font-semibold ${isDark ? 'text-white' : 'text-black'}`}>
                      {formatPrice(7500, 8, 6)}
                    </span>
                  </label>

                  <label
                    className={`flex items-center justify-between p-3.5 border cursor-pointer transition-colors ${
                      shippingMethod === 'dhl-intl'
                        ? isDark ? 'border-white bg-white/5' : 'border-black bg-black/5'
                        : isDark ? 'border-white/10 hover:border-white/20' : 'border-black/15 hover:border-black/30'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <input
                        type="radio"
                        name="shipping"
                        checked={shippingMethod === 'dhl-intl'}
                        onChange={() => setShippingMethod('dhl-intl')}
                        className={isDark ? 'accent-white' : 'accent-black'}
                      />
                      <div>
                        <span className={`text-xs font-bold block ${isDark ? 'text-white' : 'text-black'}`}>
                          DHL Express Worldwide
                        </span>
                        <span className={`text-[11px] ${isDark ? 'text-neutral-400' : 'text-neutral-600'}`}>
                          3–5 business days to UK, US, Europe & Africa
                        </span>
                      </div>
                    </div>
                    <span className={`font-mono text-xs font-semibold ${isDark ? 'text-white' : 'text-black'}`}>
                      {formatPrice(45000, 35, 28)}
                    </span>
                  </label>
                </div>
              </div>

              {/* Continue button */}
              <button
                type="submit"
                className={`w-full font-bold py-3.5 text-xs uppercase tracking-widest transition-colors flex items-center justify-center gap-2 cursor-pointer ${
                  isDark ? 'bg-white text-black hover:bg-neutral-200' : 'bg-black text-white hover:bg-neutral-800'
                }`}
              >
                <span>CONTINUE TO PAYMENT</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {step === 'payment' && (
            <form onSubmit={handleFinalPayment} className="space-y-6">
              {/* Order Summary Snapshot */}
              <div className={`p-4 border text-xs font-mono space-y-2 ${
                isDark ? 'bg-[#161616] border-white/10' : 'bg-neutral-50 border-black/10'
              }`}>
                <div className={`flex justify-between ${isDark ? 'text-neutral-400' : 'text-neutral-500'}`}>
                  <span>Shipping to:</span>
                  <span className={`text-right font-medium ${isDark ? 'text-white' : 'text-black'}`}>
                    {formData.fullName}, {formData.city}, {formData.country}
                  </span>
                </div>
                <div className={`flex justify-between ${isDark ? 'text-neutral-400' : 'text-neutral-500'}`}>
                  <span>Items ({cart.reduce((a, b) => a + b.quantity, 0)}):</span>
                  <span className={isDark ? 'text-white' : 'text-black'}>
                    {currency === 'USD' ? `$${subtotal}` : currency === 'GBP' ? `£${subtotal}` : `₦${subtotal.toLocaleString()}`}
                  </span>
                </div>
                <div className={`flex justify-between ${isDark ? 'text-neutral-400' : 'text-neutral-500'}`}>
                  <span>Shipping:</span>
                  <span className={isDark ? 'text-white' : 'text-black'}>
                    {shippingFee === 0 ? 'FREE' : currency === 'USD' ? `$${shippingFee}` : currency === 'GBP' ? `£${shippingFee}` : `₦${shippingFee.toLocaleString()}`}
                  </span>
                </div>
                <div className={`flex justify-between text-sm font-bold pt-2 border-t ${
                  isDark ? 'border-white/10 text-white' : 'border-black/10 text-black'
                }`}>
                  <span>GRAND TOTAL:</span>
                  <span>
                    {currency === 'USD' ? `$${grandTotal}` : currency === 'GBP' ? `£${grandTotal}` : `₦${grandTotal.toLocaleString()}`}
                  </span>
                </div>
              </div>

              {/* Payment Methods */}
              <div>
                <h4 className={`text-xs uppercase tracking-widest font-bold mb-3 flex items-center justify-between ${
                  isDark ? 'text-neutral-400' : 'text-neutral-600'
                }`}>
                  <span>Select Payment Provider</span>
                  <span className="flex items-center gap-1 text-[10px] text-emerald-600 dark:text-emerald-400 lowercase">
                    <Lock className="w-3 h-3" /> 256-bit SSL encrypted
                  </span>
                </h4>

                <div className="space-y-2.5">
                  <label
                    className={`flex items-center justify-between p-3.5 border cursor-pointer transition-colors ${
                      paymentMethod === 'paystack'
                        ? isDark ? 'border-white bg-white/5' : 'border-black bg-black/5'
                        : isDark ? 'border-white/10 hover:border-white/20' : 'border-black/15 hover:border-black/30'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <input
                        type="radio"
                        name="payment"
                        checked={paymentMethod === 'paystack'}
                        onChange={() => setPaymentMethod('paystack')}
                        className={isDark ? 'accent-white' : 'accent-black'}
                      />
                      <div>
                        <span className={`text-xs font-bold block ${isDark ? 'text-white' : 'text-black'}`}>
                          Paystack (Cards, Bank Transfer, USSD)
                        </span>
                        <span className={`text-[11px] ${isDark ? 'text-neutral-400' : 'text-neutral-600'}`}>
                          Fastest Nigerian checkout for Naira cards & accounts
                        </span>
                      </div>
                    </div>
                    <span className="text-xs font-mono text-emerald-600 dark:text-emerald-400 font-bold">POPULAR</span>
                  </label>

                  <label
                    className={`flex items-center justify-between p-3.5 border cursor-pointer transition-colors ${
                      paymentMethod === 'card'
                        ? isDark ? 'border-white bg-white/5' : 'border-black bg-black/5'
                        : isDark ? 'border-white/10 hover:border-white/20' : 'border-black/15 hover:border-black/30'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <input
                        type="radio"
                        name="payment"
                        checked={paymentMethod === 'card'}
                        onChange={() => setPaymentMethod('card')}
                        className={isDark ? 'accent-white' : 'accent-black'}
                      />
                      <div>
                        <span className={`text-xs font-bold block ${isDark ? 'text-white' : 'text-black'}`}>
                          International Credit / Debit Card
                        </span>
                        <span className={`text-[11px] ${isDark ? 'text-neutral-400' : 'text-neutral-600'}`}>
                          Visa, Mastercard, American Express
                        </span>
                      </div>
                    </div>
                    <CreditCard className={`w-4 h-4 ${isDark ? 'text-neutral-400' : 'text-neutral-500'}`} />
                  </label>

                  <label
                    className={`flex items-center justify-between p-3.5 border cursor-pointer transition-colors ${
                      paymentMethod === 'apple-pay'
                        ? isDark ? 'border-white bg-white/5' : 'border-black bg-black/5'
                        : isDark ? 'border-white/10 hover:border-white/20' : 'border-black/15 hover:border-black/30'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <input
                        type="radio"
                        name="payment"
                        checked={paymentMethod === 'apple-pay'}
                        onChange={() => setPaymentMethod('apple-pay')}
                        className={isDark ? 'accent-white' : 'accent-black'}
                      />
                      <div>
                        <span className={`text-xs font-bold block ${isDark ? 'text-white' : 'text-black'}`}>
                          Apple Pay / Google Pay
                        </span>
                        <span className={`text-[11px] ${isDark ? 'text-neutral-400' : 'text-neutral-600'}`}>
                          One-tap biometric checkout
                        </span>
                      </div>
                    </div>
                  </label>
                </div>
              </div>

              {/* Interactive Transfer & Gateway Channels when Paystack is chosen */}
              {paymentMethod === 'paystack' && (
                <div className={`p-4 border text-xs font-mono space-y-2 ${
                  isDark ? 'bg-emerald-950/20 border-emerald-500/30' : 'bg-emerald-50/60 border-emerald-300'
                }`}>
                  <div className="flex items-center justify-between text-emerald-600 dark:text-emerald-400 font-bold">
                    <span>⚡ PAYSTACK SECURE GATEWAY:</span>
                    <span>REAL-TIME AUTOMATION</span>
                  </div>
                  <div className={`grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 ${isDark ? 'text-neutral-300' : 'text-neutral-700'}`}>
                    <div className={`p-2.5 border ${isDark ? 'bg-black/50 border-white/10' : 'bg-white border-black/10'}`}>
                      <span className={`block text-[10px] uppercase ${isDark ? 'text-neutral-400' : 'text-neutral-500'}`}>OPTION A: DYNAMIC BANK TRANSFER</span>
                      <strong className={`block text-xs mt-0.5 ${isDark ? 'text-white' : 'text-black'}`}>Automated Dedicated Virtual Account</strong>
                      <span className={`block text-[10px] ${isDark ? 'text-neutral-400' : 'text-neutral-500'}`}>Generated per order via Paystack gateway</span>
                    </div>
                    <div className={`p-2.5 border ${isDark ? 'bg-black/50 border-white/10' : 'bg-white border-black/10'}`}>
                      <span className={`block text-[10px] uppercase ${isDark ? 'text-neutral-400' : 'text-neutral-500'}`}>OPTION B: DEBIT / CREDIT CARD & USSD</span>
                      <span className={`block text-xs mt-0.5 ${isDark ? 'text-white' : 'text-black'}`}>Mastercard · Visa · Verve · USSD</span>
                      <span className="block text-[10px] text-emerald-600 dark:text-emerald-400">Zero transaction surcharge</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Action buttons */}
              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setStep('details')}
                  className={`px-5 py-3 border text-xs uppercase tracking-wider font-semibold cursor-pointer transition-colors ${
                    isDark ? 'border-white/20 text-neutral-400 hover:text-white' : 'border-black/20 text-neutral-600 hover:text-black'
                  }`}
                >
                  Back
                </button>
                <button
                  type="submit"
                  disabled={isProcessing}
                  className={`flex-1 font-bold py-3.5 text-xs uppercase tracking-widest transition-colors flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 ${
                    isDark ? 'bg-white text-black hover:bg-neutral-200' : 'bg-black text-white hover:bg-neutral-800'
                  }`}
                >
                  {isProcessing ? (
                    <span className="animate-pulse">RECORDING AUTHORITATIVE ORDER...</span>
                  ) : (
                    <>
                      <span>
                        PLACE ORDER —{' '}
                        {currency === 'USD'
                          ? `$${grandTotal}`
                          : currency === 'GBP'
                          ? `£${grandTotal}`
                          : `₦${grandTotal.toLocaleString()}`}{' '}
                        (PENDING PAYMENT)
                      </span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </form>
          )}

          {step === 'confirmed' && completedOrder && (() => {
            const isPaid = normalizePaymentStatus(completedOrder.paymentStatus) === 'SUCCESS';
            const normalizedOrderState = normalizeOrderStatus(completedOrder.orderStatus || completedOrder.status);

            return (
            <div className="text-center py-6 space-y-6">
              {isPaid ? (
                <div className="w-16 h-16 bg-emerald-500/10 border border-emerald-500 text-emerald-400 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
              ) : (
                <div className="w-16 h-16 bg-amber-500/10 border border-amber-500 text-amber-400 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
              )}

              <div>
                <span className={`text-xs uppercase tracking-[0.2em] font-mono ${
                  isPaid ? 'text-emerald-400 font-bold' : isDark ? 'text-neutral-400' : 'text-neutral-500'
                }`}>
                  {isPaid ? 'PAYMENT VERIFIED · CONFIRMED' : 'ORDER RECORDED · AWAITING PAYMENT'}
                </span>
                <h3 className={`font-display font-black text-3xl uppercase tracking-tight mt-1 ${isDark ? 'text-white' : 'text-black'}`}>
                  {completedOrder.orderNumber || completedOrder.id}
                </h3>
                <p className={`text-xs mt-2 max-w-md mx-auto ${isDark ? 'text-neutral-400' : 'text-neutral-600'}`}>
                  {isPaid
                    ? `Thank you, ${completedOrder.customer.fullName}. Your payment has been authoritatively verified server-side.`
                    : `Thank you, ${completedOrder.customer.fullName}. Your order has been registered authoritatively in the atelier system.`}
                </p>
              </div>

              {/* Order Receipt Box */}
              <div className={`border p-5 text-left text-xs font-mono space-y-2.5 max-w-lg mx-auto ${
                isDark ? 'bg-[#181818] border-white/10' : 'bg-neutral-50 border-black/10'
              }`}>
                <div className={`flex justify-between items-center border-b pb-2 ${isDark ? 'border-white/10' : 'border-black/10'}`}>
                  <span className={isDark ? 'text-neutral-400' : 'text-neutral-500'}>Order Number:</span>
                  <span className={`font-bold text-sm ${isDark ? 'text-white' : 'text-black'}`}>{completedOrder.orderNumber || completedOrder.id}</span>
                </div>
                <div className={`flex justify-between items-center border-b pb-2 ${isDark ? 'border-white/10' : 'border-black/10'}`}>
                  <span className={isDark ? 'text-neutral-400' : 'text-neutral-500'}>Payment Status:</span>
                  {isPaid ? (
                    <span className="px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      SUCCESS (PAID)
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-amber-500/20 text-amber-400 border border-amber-500/30">
                      PENDING
                    </span>
                  )}
                </div>
                <div className={`flex justify-between items-center border-b pb-2 ${isDark ? 'border-white/10' : 'border-black/10'}`}>
                  <span className={isDark ? 'text-neutral-400' : 'text-neutral-500'}>Order Workflow:</span>
                  <span className={`px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider border ${
                    normalizedOrderState === 'PAID'
                      ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                      : 'bg-neutral-800 text-neutral-300 border-neutral-700'
                  }`}>
                    {normalizedOrderState}
                  </span>
                </div>
                <div className={`flex justify-between items-center border-b pb-2 ${isDark ? 'border-white/10' : 'border-black/10'}`}>
                  <span className={isDark ? 'text-neutral-400' : 'text-neutral-500'}>Classification:</span>
                  {completedOrder.purchaseType === 'preorder' || completedOrder.isPreOrder ? (
                    <span className="px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-blue-500/20 text-blue-400 border border-blue-500/30">
                      PRE-ORDER DROP
                    </span>
                  ) : completedOrder.purchaseType === 'negotiated' || completedOrder.isNegotiated ? (
                    <span className="px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-purple-500/20 text-purple-400 border border-purple-500/30">
                      VIP BESPOKE OFFER
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-neutral-700/50 text-neutral-300 border border-neutral-600">
                      STANDARD PURCHASE
                    </span>
                  )}
                </div>
                <div className={`flex justify-between items-center border-b pb-2 ${isDark ? 'border-white/10' : 'border-black/10'}`}>
                  <span className={isDark ? 'text-neutral-400' : 'text-neutral-500'}>Payment Reference:</span>
                  <span className="text-[11px] font-medium text-neutral-400">
                    {completedOrder.paymentReference || 'Awaiting Payment Provider Integration'}
                  </span>
                </div>
                <div className={`flex justify-between border-b pb-2 ${isDark ? 'border-white/10' : 'border-black/10'}`}>
                  <span className={isDark ? 'text-neutral-400' : 'text-neutral-500'}>Client & Recipient:</span>
                  <span className={`text-right ${isDark ? 'text-white' : 'text-black'}`}>
                    <strong>{completedOrder.customer.fullName}</strong><br />
                    <span className="text-neutral-400 text-[10px]">{completedOrder.customer.email} · {completedOrder.customer.phone}</span>
                  </span>
                </div>
                <div className={`flex justify-between border-b pb-2 ${isDark ? 'border-white/10' : 'border-black/10'}`}>
                  <span className={isDark ? 'text-neutral-400' : 'text-neutral-500'}>Destination:</span>
                  <span className={`text-right max-w-[240px] truncate ${isDark ? 'text-white' : 'text-black'}`}>
                    {completedOrder.customer.address}, {completedOrder.customer.city}, {completedOrder.customer.state}, {completedOrder.customer.country}
                  </span>
                </div>
                <div className={`flex justify-between border-b pb-2 ${isDark ? 'border-white/10' : 'border-black/10'}`}>
                  <span className={isDark ? 'text-neutral-400' : 'text-neutral-500'}>Dispatch Method:</span>
                  <span className="text-amber-400 font-bold">{completedOrder.shippingMethod}</span>
                </div>
                <div className={`border-b pb-2 ${isDark ? 'border-white/10' : 'border-black/10'}`}>
                  <span className={`block mb-1.5 ${isDark ? 'text-neutral-400' : 'text-neutral-500'}`}>Items ({completedOrder.items?.length || 0}):</span>
                  <div className="space-y-1.5">
                    {completedOrder.items?.map((i: any, idx: number) => {
                      const itemName = i.name || i.product?.name || 'Garment';
                      const itemSize = i.selectedSize || 'M';
                      const itemColor = i.selectedColor || '';
                      const itemQty = i.quantity || 1;
                      const hasNegotiated = !!i.isNegotiated;
                      const hasPreOrder = !!i.isPreOrder;
                      return (
                        <div key={idx} className="flex justify-between items-start text-[11px] p-1.5 bg-black/20 rounded">
                          <div>
                            <span className="font-semibold">{itemName}</span> ({itemSize}{itemColor ? ` · ${itemColor}` : ''}) x{itemQty}
                            {hasPreOrder && (
                              <span className="ml-1 text-[9px] text-blue-400 uppercase font-bold">[Pre-order]</span>
                            )}
                            {hasNegotiated && (
                              <span className="ml-1 text-[9px] text-purple-400 uppercase font-bold">[VIP Offer]</span>
                            )}
                            {i.includeCollectorBox && (
                              <div className="text-[10px] text-amber-300">✓ 1200 GSM Collector Box</div>
                            )}
                          </div>
                          <span className="font-mono text-right">
                            ₦{((i.unitPrice || i.product?.priceNGN || 0) * itemQty).toLocaleString()}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
                <div className={`space-y-1 pt-1 text-[11px] ${isDark ? 'text-neutral-400' : 'text-neutral-600'}`}>
                  <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <span>₦{(completedOrder.subtotal || 0).toLocaleString()}</span>
                  </div>
                  {completedOrder.packagingFee ? (
                    <div className="flex justify-between">
                      <span>Collector Box Packaging:</span>
                      <span>₦{completedOrder.packagingFee.toLocaleString()}</span>
                    </div>
                  ) : null}
                  <div className="flex justify-between">
                    <span>Shipping Logistics:</span>
                    <span>{completedOrder.shippingFee === 0 ? 'COMPLIMENTARY' : `₦${completedOrder.shippingFee.toLocaleString()}`}</span>
                  </div>
                  {completedOrder.discount ? (
                    <div className="flex justify-between text-emerald-400">
                      <span>Special Discount / Promo:</span>
                      <span>-₦{completedOrder.discount.toLocaleString()}</span>
                    </div>
                  ) : null}
                </div>
                <div className={`flex justify-between text-base font-bold pt-2 border-t ${isDark ? 'text-white border-white/15' : 'text-black border-black/15'}`}>
                  <span>FINAL ORDER TOTAL:</span>
                  <span className="text-amber-400 font-mono">
                    ₦{(completedOrder.total || 0).toLocaleString()}
                  </span>
                </div>

                {isPaid ? (
                  <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-[10px] leading-relaxed">
                    ✓ <strong>Payment Authoritatively Confirmed:</strong> Transaction verified through Paystack server-to-server gateway.
                  </div>
                ) : (
                  <div className="p-2.5 bg-amber-500/10 border border-amber-500/20 text-amber-300 text-[10px] leading-relaxed">
                    ⓘ <strong>Payment Pending:</strong> Order recorded in authoritative pending status. Complete payment through Paystack or verify status below.
                  </div>
                )}
              </div>

              {/* Paystack Interactive Action Buttons */}
              {!isPaid && (
                <div className={`p-4 border max-w-lg mx-auto space-y-3 ${
                  isDark ? 'bg-white/5 border-white/10' : 'bg-black/5 border-black/10'
                }`}>
                  <div className="flex flex-wrap items-center justify-center gap-3">
                    {completedOrder.authorizationUrl && (
                      <a
                        href={completedOrder.authorizationUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer"
                      >
                        Complete Payment via Paystack →
                      </a>
                    )}
                    <button
                      type="button"
                      onClick={handleVerifyPayment}
                      disabled={isVerifying}
                      className={`px-5 py-2.5 text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer border ${
                        isDark ? 'border-white text-white hover:bg-white/10' : 'border-black text-black hover:bg-black/5'
                      } disabled:opacity-50`}
                    >
                      {isVerifying ? 'Verifying with Paystack...' : 'Check / Verify Payment Status'}
                    </button>
                  </div>
                  {verificationMsg && (
                    <p className="text-[11px] text-amber-400 font-mono">{verificationMsg}</p>
                  )}
                </div>
              )}

              <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
                <button
                  onClick={() => window.print()}
                  className={`px-5 py-2.5 border text-xs font-semibold uppercase tracking-wider flex items-center gap-2 cursor-pointer transition-colors ${
                    isDark ? 'border-white/20 text-neutral-300 hover:text-white' : 'border-black/20 text-neutral-700 hover:text-black'
                  }`}
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Order Slip</span>
                </button>
                <a
                  href={`https://wa.me/2348031234567?text=Hello%203KO%20Concierge,%20Order%20${completedOrder.orderNumber || completedOrder.id}%20is%20pending%20payment.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold uppercase tracking-wider flex items-center gap-2 cursor-pointer"
                >
                  <span>WhatsApp Concierge</span>
                </a>
                <button
                  onClick={handleClose}
                  className={`px-6 py-2.5 text-xs font-bold uppercase tracking-widest transition-colors cursor-pointer ${
                    isDark ? 'bg-white text-black hover:bg-neutral-200' : 'bg-black text-white hover:bg-neutral-800'
                  }`}
                >
                  Back to Store
                </button>
              </div>
            </div>
            );
          })()}
        </div>
      </div>
    </div>
  );
};
