import React, { useState } from 'react';
import { X, ArrowRight, Check, Ruler } from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const QuickViewModal: React.FC = () => {
  const {
    quickViewProduct,
    setQuickViewProduct,
    addToCart,
    formatPrice,
    navigateTo,
    setIsSizeGuideOpen,
  } = useShop();

  const [selectedSize, setSelectedSize] = useState<string>('');
  const [activeImageIndex, setActiveImageIndex] = useState(0);

  if (!quickViewProduct) return null;

  const product = quickViewProduct;
  const currentSize = selectedSize || product.sizes[0];

  const handleAdd = () => {
    addToCart(product, currentSize);
    setQuickViewProduct(null);
  };

  const handleViewFull = () => {
    setQuickViewProduct(null);
    navigateTo(`/product/${product.slug}`);
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200"
      onClick={() => setQuickViewProduct(null)}
    >
      <div
        className="bg-[#121212] border border-white/15 max-w-3xl w-full text-white shadow-2xl overflow-hidden relative"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={() => setQuickViewProduct(null)}
          className="absolute top-4 right-4 z-10 p-2 text-neutral-400 hover:text-white bg-black/60 rounded-full"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          {/* Gallery View */}
          <div className="relative aspect-[3/4] bg-neutral-900 overflow-hidden">
            <img
              src={product.images[activeImageIndex] || product.images[0]}
              alt={product.name}
              className="w-full h-full object-cover"
            />
            {product.images.length > 1 && (
              <div className="absolute bottom-3 left-3 right-3 flex gap-2">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImageIndex(idx)}
                    className={`w-12 h-14 border bg-neutral-800 overflow-hidden ${
                      activeImageIndex === idx ? 'border-white' : 'border-white/20 opacity-60'
                    }`}
                  >
                    <img src={img} alt="thumbnail" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Details & Actions */}
          <div className="p-6 sm:p-8 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-xs font-mono text-neutral-400 mb-2">
                <span className="uppercase">{product.line}</span>
                <span>·</span>
                <span>{product.collectionName}</span>
              </div>

              <h3 className="font-display font-extrabold text-2xl uppercase tracking-tight text-white mb-1">
                {product.name}
              </h3>
              <p className="text-xs text-neutral-400 mb-4">{product.subtitle}</p>

              <div className="font-mono text-lg font-bold text-white mb-6">
                {formatPrice(product.priceNGN, product.priceUSD, product.priceGBP)}
              </div>

              <p className="text-xs text-neutral-300 leading-relaxed mb-6 font-sans">
                {product.description}
              </p>

              {/* Sizes */}
              <div className="mb-6">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs uppercase tracking-wider font-semibold text-neutral-400">
                    Select Size:
                  </span>
                  <button
                    onClick={() => setIsSizeGuideOpen(true)}
                    className="text-[11px] text-neutral-400 hover:text-white flex items-center gap-1 font-mono"
                  >
                    <Ruler className="w-3 h-3" />
                    <span>Fit Guide</span>
                  </button>
                </div>

                <div className="flex flex-wrap gap-2">
                  {product.sizes.map((s) => (
                    <button
                      key={s}
                      onClick={() => setSelectedSize(s)}
                      className={`px-3.5 py-2 text-xs font-mono border transition-all cursor-pointer ${
                        currentSize === s
                          ? 'border-white bg-white text-[#080808] font-bold'
                          : 'border-white/20 text-neutral-300 hover:border-white'
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="space-y-2 pt-4 border-t border-white/10">
              <button
                onClick={handleAdd}
                className="w-full bg-white text-[#080808] font-bold py-3 text-xs uppercase tracking-widest hover:bg-neutral-200 transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>ADD TO SHOPPING BAG</span>
              </button>
              <button
                onClick={handleViewFull}
                className="w-full border border-white/20 text-neutral-300 font-semibold py-2.5 text-xs uppercase tracking-widest hover:text-white hover:border-white transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>VIEW COMPLETE DETAILS</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
