import React, { useState } from 'react';
import { ArrowRight, Instagram, Youtube, Check } from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const Footer: React.FC = () => {
  const { navigateTo, theme, showToast } = useShop();
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const isDark = theme === 'dark';

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) return;
    setSubscribed(true);
    setTimeout(() => {
      setSubscribed(false);
      setEmail('');
    }, 4000);
  };

  return (
    <footer className={`w-full pt-16 sm:pt-20 pb-12 border-t transition-colors duration-300 ${
      isDark ? 'bg-[#080808] text-white border-white/10' : 'bg-[#EFECE6] text-neutral-900 border-black/10'
    }`}>
      <div className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-12">
        {/* Main Footer Grid */}
        <div className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-12 pb-14 border-b ${
          isDark ? 'border-white/10' : 'border-black/10'
        }`}>
          {/* Brand & Tagline Column */}
          <div className="lg:col-span-4 flex flex-col items-start">
            <button
              onClick={() => navigateTo('/')}
              className="mb-4 focus:outline-none cursor-pointer"
              aria-label="3KO Home"
            >
              <img
                src="/images/brand/logo_white_transparent.png"
                alt="3KO Logo"
                className={`h-10 w-auto object-contain ${!isDark ? 'invert' : ''}`}
              />
            </button>
            <p className={`font-display font-bold text-sm tracking-[0.2em] uppercase mb-6 ${
              isDark ? 'text-neutral-400' : 'text-neutral-600'
            }`}>
              LAGOS IN EVERY THREAD.
            </p>
            <p className={`text-xs leading-relaxed max-w-sm font-sans ${
              isDark ? 'text-neutral-400' : 'text-neutral-600'
            }`}>
              Born on Lagos Island. Designed for dreamers, doers and those who carry Nigerian contemporary identity with them across the world.
            </p>
          </div>

          {/* Navigation Column: SHOP */}
          <div className="lg:col-span-2">
            <h4 className="font-display font-bold text-xs uppercase tracking-[0.2em] text-white mb-4">
              SHOP
            </h4>
            <ul className="space-y-2.5 text-xs text-neutral-400 font-sans tracking-wide">
              <li>
                <button
                  onClick={() => navigateTo('/shop')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  All Items
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('/street')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  3KO Street
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('/form')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  3KO Form
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('/collections')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  The Lagos Collections
                </button>
              </li>
            </ul>
          </div>

          {/* Navigation Column: ABOUT */}
          <div className="lg:col-span-2">
            <h4 className="font-display font-bold text-xs uppercase tracking-[0.2em] text-white mb-4">
              ABOUT
            </h4>
            <ul className="space-y-2.5 text-xs text-neutral-400 font-sans tracking-wide">
              <li>
                <button
                  onClick={() => navigateTo('/about')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Our Story
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('/about#sustainability')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Sustainability
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('/contact')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Store Locator
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('/contact')}
                  className={`transition-colors cursor-pointer ${isDark ? 'hover:text-white' : 'hover:text-black'}`}
                >
                  Contact & Concierge
                </button>
              </li>
            </ul>
          </div>

          {/* Newsletter Column */}
          <div className="lg:col-span-4">
            <h4 className="font-display font-bold text-xs uppercase tracking-[0.2em] mb-2">
              JOIN OUR NEWSLETTER
            </h4>
            <p className={`text-xs leading-relaxed mb-4 font-sans ${isDark ? 'text-neutral-400' : 'text-neutral-600'}`}>
              Be the first to know about new drops, exclusive offers and Lagos stories.
            </p>

            <form onSubmit={handleSubscribe} className="relative flex items-center">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email address"
                required
                className={`w-full border text-xs px-4 py-3 pr-12 focus:outline-none transition-colors ${
                  isDark
                    ? 'bg-transparent border-white/30 text-white placeholder-neutral-500 focus:border-white'
                    : 'bg-white border-black/20 text-black placeholder-neutral-400 focus:border-black'
                }`}
              />
              <button
                type="submit"
                className={`absolute right-1 top-1 bottom-1 px-3 flex items-center justify-center transition-colors cursor-pointer ${
                  isDark
                    ? 'bg-white text-[#080808] hover:bg-neutral-200'
                    : 'bg-black text-white hover:bg-neutral-800'
                }`}
                aria-label="Subscribe to 3KO newsletter"
              >
                {subscribed ? <Check className="w-4 h-4 text-emerald-600" /> : <ArrowRight className="w-4 h-4" />}
              </button>
            </form>
            {subscribed && (
              <p className="text-[11px] text-emerald-500 mt-2 font-mono">
                Welcome to the 3KO Dispatch. First drop code sent to your inbox.
              </p>
            )}
          </div>
        </div>

        {/* Bottom Sub-Footer Bar */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-6 text-[11px] text-neutral-500 font-sans">
          <div>
            © {new Date().getFullYear()} 3KO. All rights reserved. Lagos, Nigeria.
          </div>

          {/* Social Icons matching mock-up */}
          <div className="flex items-center gap-5 text-neutral-400">
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-white transition-colors"
              aria-label="3KO on Instagram"
            >
              <Instagram className="w-4 h-4" />
            </a>
            {/* Custom SVG for X / Twitter */}
            <a
              href="https://x.com"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-white transition-colors"
              aria-label="3KO on X"
            >
              <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
              </svg>
            </a>
            {/* Custom SVG for TikTok */}
            <a
              href="https://tiktok.com"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-white transition-colors"
              aria-label="3KO on TikTok"
            >
              <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.24 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z" />
              </svg>
            </a>
            <a
              href="https://youtube.com"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-white transition-colors"
              aria-label="3KO on YouTube"
            >
              <Youtube className="w-4 h-4" />
            </a>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-4 text-[11px] text-neutral-400 font-mono">
            <span>3KO Contemporary Apparel Limited · RC 1948201</span>
            <span className="hidden sm:inline">|</span>
            <span>Flagship: 14 Admiralty Way, Lekki Phase 1, Lagos</span>
            <span className="hidden sm:inline">|</span>
            <button
              onClick={() => showToast('Terms of Service: All orders fulfilled from Lagos. Worldwide DHL Express.')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Terms of Service
            </button>
            <span>|</span>
            <button
              onClick={() => showToast('Privacy Policy: Client credentials and transactions secured via 256-bit SSL.')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Privacy Policy
            </button>
            <span>|</span>
            <span>Lagos · London · New York</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
