import React, { useState } from 'react';
import { ArrowRight, ArrowLeft } from 'lucide-react';
import { useShop } from '../context/ShopContext';

interface CampaignSlide {
  id: string;
  number: string;
  headline: string;
  subtext: string;
  image: string;
  alt: string;
  collectionSlug: string;
  ctaPrimaryText: string;
  ctaSecondaryText: string;
}

const HERO_SLIDES: CampaignSlide[] = [
  {
    id: 'slide-01',
    number: '01 / 03',
    headline: 'LAGOS IN EVERY THREAD.',
    subtext:
      '3KO is a contemporary Lagos fashion house built on two core aesthetics: 3KO STREET for bold, heavyweight streetwear and 3KO FORM for refined, architectural smart casual.',
    image: '/images/brand/hero_bg.jpg',
    alt: '3KO campaign model wearing Ikoyi Bridge graphic tee overlooking Lekki-Ikoyi cable bridge',
    collectionSlug: '/street',
    ctaPrimaryText: 'SHOP STREET',
    ctaSecondaryText: 'SHOP FORM',
  },
  {
    id: 'slide-02',
    number: '02 / 03',
    headline: '3KO STREET — BOLD & URBAN.',
    subtext:
      'Heavyweight 280–480 GSM organic cottons, tactile puff ink elevation, and oversized silhouettes engineered for the Nigerian street and global capitals.',
    image: '/images/brand/street_panel.jpg',
    alt: '3KO Streetwear campaign model with sunglasses',
    collectionSlug: '/street',
    ctaPrimaryText: 'DISCOVER STREET',
    ctaSecondaryText: 'STREET LOOKBOOK',
  },
  {
    id: 'slide-03',
    number: '03 / 03',
    headline: '3KO FORM — CLEAN & REFINED.',
    subtext:
      'Engineered for Lagos boardrooms, evening dining, and international itineraries. Breathable pique knits, structured linens, and contemporary smart tailoring.',
    image: '/images/brand/form_panel.jpg',
    alt: '3KO Form campaign model wearing the Sky Blue polo',
    collectionSlug: '/form',
    ctaPrimaryText: 'DISCOVER FORM',
    ctaSecondaryText: 'SMART TAILORING',
  },
];

export const Hero: React.FC = () => {
  const { navigateTo, storeSettings } = useShop();
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);

  const heroSlides: CampaignSlide[] = [
    {
      id: 'slide-01',
      number: '01 / 03',
      headline: 'LAGOS IN EVERY THREAD.',
      subtext:
        '3KO is a contemporary Lagos fashion house built on two core aesthetics: 3KO STREET for bold, heavyweight streetwear and 3KO FORM for refined, architectural smart casual.',
      image: storeSettings.banners?.heroBanner || '/images/brand/hero_bg.jpg',
      alt: '3KO campaign model wearing Ikoyi Bridge graphic tee overlooking Lekki-Ikoyi cable bridge',
      collectionSlug: '/street',
      ctaPrimaryText: 'SHOP STREET',
      ctaSecondaryText: 'SHOP FORM',
    },
    {
      id: 'slide-02',
      number: '02 / 03',
      headline: '3KO STREET — BOLD & URBAN.',
      subtext:
        'Heavyweight 280–480 GSM organic cottons, tactile puff ink elevation, and oversized silhouettes engineered for the Nigerian street and global capitals.',
      image: storeSettings.banners?.heroSlide2 || '/images/brand/street_panel.jpg',
      alt: '3KO Streetwear campaign model with sunglasses',
      collectionSlug: '/street',
      ctaPrimaryText: 'DISCOVER STREET',
      ctaSecondaryText: 'STREET LOOKBOOK',
    },
    {
      id: 'slide-03',
      number: '03 / 03',
      headline: '3KO FORM — CLEAN & REFINED.',
      subtext:
        'Engineered for Lagos boardrooms, evening dining, and international itineraries. Breathable pique knits, structured linens, and contemporary smart tailoring.',
      image: storeSettings.banners?.heroSlide3 || '/images/brand/form_panel.jpg',
      alt: '3KO Form campaign model wearing the Sky Blue polo',
      collectionSlug: '/form',
      ctaPrimaryText: 'DISCOVER FORM',
      ctaSecondaryText: 'SMART TAILORING',
    },
  ];

  const activeSlide = heroSlides[currentSlideIndex];

  // Auto advance slides every 6 seconds
  React.useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlideIndex((prev) => (prev + 1) % heroSlides.length);
    }, 6500);
    return () => clearInterval(timer);
  }, [heroSlides.length]);

  const handlePrev = () => {
    setCurrentSlideIndex((prev) => (prev === 0 ? heroSlides.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentSlideIndex((prev) => (prev === heroSlides.length - 1 ? 0 : prev + 1));
  };

  return (
    <section className="relative w-full min-h-[580px] lg:min-h-[720px] pt-20 flex items-center bg-[#080808] overflow-hidden">
      {/* Background Photography with subtle responsive framing */}
      <div className="absolute inset-0 z-0">
        <img
          src={activeSlide.image}
          alt={activeSlide.alt}
          className="w-full h-full object-cover object-right md:object-center transition-all duration-700 ease-out filter brightness-[0.85]"
          referrerPolicy="no-referrer"
        />
        {/* Measured Scrim: ensuring text readability while preserving the model and bridge backdrop */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#080808]/95 via-[#080808]/65 to-transparent w-full md:w-[75%]" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#080808] via-transparent to-transparent h-24 bottom-0" />
      </div>

      {/* Hero Content Container */}
      <div className="relative z-10 max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-12 w-full py-16 md:py-24">
        <div className="max-w-xl lg:max-w-2xl flex flex-col items-start">
          {/* Subtle Tagline / Sub-header */}
          <div className="flex items-center gap-2 text-xs font-mono tracking-[0.25em] uppercase text-neutral-300 mb-3 bg-black/50 px-3 py-1 border border-white/10 backdrop-blur-xs">
            <span className="w-2 h-2 rounded-full bg-lime-400 animate-pulse" />
            <span>3KO OFFICIAL · LAGOS IN EVERY THREAD</span>
          </div>

          {/* Main Editorial Headline */}
          <h1 className="font-display font-black text-4xl sm:text-6xl lg:text-7xl leading-[0.92] tracking-tight uppercase text-white mb-6 text-balance">
            {activeSlide.headline}
          </h1>

          {/* Supporting Copy */}
          <p className="text-sm sm:text-base lg:text-[17px] text-neutral-200/95 font-normal leading-relaxed max-w-lg mb-8 md:mb-10">
            {activeSlide.subtext}
          </p>

          {/* Call-to-Action Buttons */}
          <div className="flex flex-wrap items-center gap-4 w-full sm:w-auto">
            <button
              onClick={() => navigateTo(activeSlide.collectionSlug)}
              className="bg-white text-[#080808] px-7 py-3.5 text-xs sm:text-sm font-bold tracking-widest uppercase hover:bg-neutral-200 transition-colors flex items-center gap-2 cursor-pointer group shadow-xl"
            >
              <span>{activeSlide.ctaPrimaryText}</span>
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>

            <button
              onClick={() => {
                if (activeSlide.id === 'slide-01') {
                  navigateTo('/form');
                } else {
                  navigateTo('/collections');
                }
              }}
              className="border border-white/40 bg-black/40 backdrop-blur-xs text-white px-7 py-3.5 text-xs sm:text-sm font-semibold tracking-widest uppercase hover:bg-white/10 hover:border-white transition-colors cursor-pointer"
            >
              {activeSlide.ctaSecondaryText}
            </button>
          </div>

          {/* Trust Footnote */}
          <div className="mt-5 flex items-center gap-2 text-[11px] font-mono text-neutral-400">
            <span className="text-lime-400">✓</span>
            <span>All First Edition drops arrive in the signature 1200 GSM architectural collector box</span>
          </div>
        </div>

        {/* Carousel Slide Pager: 01 / 03 ← → */}
        <div className="absolute bottom-6 md:bottom-10 right-6 sm:right-10 lg:right-12 flex items-center gap-4 text-xs font-mono tracking-widest text-white/90 bg-black/40 backdrop-blur-sm px-3.5 py-2 border border-white/10">
          <span className="font-semibold">{activeSlide.number}</span>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrev}
              className="p-1 hover:text-white text-neutral-400 transition-colors focus:outline-none"
              aria-label="Previous campaign slide"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <button
              onClick={handleNext}
              className="p-1 hover:text-white text-neutral-400 transition-colors focus:outline-none"
              aria-label="Next campaign slide"
            >
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
