import React from 'react';
import { ArrowRight } from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const CitySection: React.FC = () => {
  const { navigateTo } = useShop();

  return (
    <section className="w-full bg-[#080808] text-white pt-16 sm:pt-20 pb-12 sm:pb-16 border-b border-white/10 overflow-hidden">
      <div className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-12">
        {/* Section Header */}
        <div className="mb-8 sm:mb-12">
          <span className="text-xs sm:text-[13px] font-semibold tracking-[0.2em] uppercase text-neutral-400 block mb-2">
            LAGOS EDITORIAL
          </span>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div>
              <h2 className="font-display font-black text-5xl sm:text-6xl lg:text-8xl uppercase tracking-tight text-white mb-2">
                LAGOS
              </h2>
              <p className="text-sm sm:text-base text-neutral-300 font-mono tracking-wider uppercase">
                More than a city. A culture. A movement.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row sm:items-center gap-6 md:gap-10 pb-2">
              <span className="text-xs sm:text-sm font-mono tracking-widest text-lime-400 uppercase hidden sm:inline">
                LAGOS IN EVERY THREAD
              </span>
              <button
                onClick={() => navigateTo('/lagos')}
                className="inline-flex items-center gap-2 text-xs sm:text-sm font-bold tracking-widest uppercase text-white hover:text-neutral-300 border-b border-white pb-1 transition-all cursor-pointer w-fit"
              >
                <span>EXPLORE THE LAGOS ESSENCE</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Wide Cinematic Desaturated Skyline Panorama */}
        <div
          onClick={() => navigateTo('/lagos')}
          className="relative w-full aspect-[21/9] sm:aspect-[24/9] md:aspect-[32/10] overflow-hidden group cursor-pointer bg-neutral-900 border border-white/10"
        >
          <img
            src="/images/brand/city_lagos.jpg"
            alt="Lagos waterfront skyline and maritime commercial vessels at dusk"
            className="w-full h-full object-cover object-center filter grayscale contrast-110 brightness-[0.88] transition-transform duration-700 ease-out group-hover:scale-103"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-80" />

          {/* Minimalist Coordinate Badge */}
          <div className="absolute bottom-4 left-4 sm:bottom-6 sm:left-6 flex items-center gap-3 text-xs font-mono text-white/80 bg-black/60 backdrop-blur-xs px-3 py-1.5 border border-white/10">
            <span>6°27′N 3°23′E</span>
            <span>·</span>
            <span className="tracking-widest uppercase font-sans font-semibold text-[11px]">
              Center of African Velocity
            </span>
          </div>
        </div>
      </div>
    </section>
  );
};
