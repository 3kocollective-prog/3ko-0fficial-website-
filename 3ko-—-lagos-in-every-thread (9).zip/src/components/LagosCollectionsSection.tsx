import React, { useRef } from 'react';
import { ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react';
import { LAGOS_COLLECTIONS } from '../data/collections';
import { useShop } from '../context/ShopContext';

export const LagosCollectionsSection: React.FC = () => {
  const { navigateTo } = useShop();
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = direction === 'left' ? -340 : 340;
      scrollRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  return (
    <section
      id="lagos-collections-section"
      className="w-full bg-[#F4F1EA] text-[#080808] py-16 sm:py-20 lg:py-24 px-6 sm:px-10 lg:px-12 border-b border-black/10 overflow-hidden"
    >
      <div className="max-w-[1440px] mx-auto">
        {/* Header Block matching the mock-up */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-12 sm:mb-16">
          <div>
            <span className="text-xs sm:text-[13px] font-bold tracking-[0.2em] uppercase text-neutral-600 block mb-2">
              NUMBERED CHAPTERS · LAGOS ARCHITECTURE
            </span>
            <h2 className="font-display font-black text-4xl sm:text-5xl lg:text-7xl uppercase tracking-tight text-[#080808]">
              3KO 001–009
            </h2>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between lg:justify-end gap-6 lg:gap-12 flex-1">
            <p className="text-sm sm:text-base text-neutral-700 max-w-md font-medium leading-relaxed">
              Nine location-based chapters. Distinct districts. Singular Lagos perspective.
            </p>

            <div className="flex items-center gap-4 shrink-0">
              {/* Arrow controls for desktop/tablet browsing */}
              <div className="flex items-center gap-1.5 border border-black/15 bg-white p-1">
                <button
                  onClick={() => scroll('left')}
                  className="p-1.5 hover:bg-black/5 text-neutral-800 transition-colors"
                  aria-label="Scroll left collections"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={() => scroll('right')}
                  className="p-1.5 hover:bg-black/5 text-neutral-800 transition-colors"
                  aria-label="Scroll right collections"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              <button
                onClick={() => navigateTo('/collections')}
                className="inline-flex items-center gap-2 text-xs sm:text-sm font-bold tracking-widest uppercase text-[#080808] hover:opacity-70 transition-opacity border-b-2 border-[#080808] pb-1 cursor-pointer"
              >
                <span>EXPLORE 3KO 001–009 ARCHIVE</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* 9 Collection Cards: Horizontal Grid / Scroll Container */}
        <div
          ref={scrollRef}
          className="flex lg:grid lg:grid-cols-9 gap-3 sm:gap-4 overflow-x-auto no-scrollbar pb-6 pt-2 snap-x snap-mandatory"
        >
          {LAGOS_COLLECTIONS.map((col) => (
            <div
              key={col.id}
              onClick={() => navigateTo(`/collections/${col.slug}`)}
              className="flex-shrink-0 w-[140px] sm:w-[160px] lg:w-auto flex flex-col bg-white shadow-xs border border-black/10 group cursor-pointer transition-all duration-300 hover:-translate-y-1 hover:shadow-lg snap-start"
            >
              {/* Image Container */}
              <div className="relative aspect-[3/4] w-full overflow-hidden bg-neutral-200">
                <img
                  src={col.image}
                  alt={`${col.fullName} location photography`}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-108"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-black/10 opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>

              {/* Card Meta Content */}
              <div className="p-3 bg-white flex flex-col justify-between flex-1">
                <span className="font-mono text-[11px] font-semibold text-neutral-500 tracking-wider">
                  {col.numberStr}
                </span>
                <h3 className="font-display font-extrabold text-[12px] sm:text-[13px] tracking-tight uppercase text-[#080808] truncate mt-0.5">
                  {col.name}
                </h3>
              </div>

              {/* Signature Bottom Color Accent Stripe */}
              <div
                className="h-[5px] w-full transition-all group-hover:h-[7px]"
                style={{ backgroundColor: col.colorHex }}
                title={`Collection Color: ${col.colorName}`}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
