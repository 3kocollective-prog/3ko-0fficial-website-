import React, { useState, useEffect } from 'react';
import { Search, ShoppingBag, User, Menu, X, ChevronDown, Heart, Sun, Moon } from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const Navbar: React.FC = () => {
  const {
    totalItems,
    setIsCartOpen,
    setIsSearchOpen,
    currency,
    setCurrency,
    navigateTo,
    currentRoute,
    wishlist,
    theme,
    toggleTheme,
    currentUser,
    isAdmin,
    loginWithGoogle,
    logout,
  } = useShop();

  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [shopDropdownOpen, setShopDropdownOpen] = useState(false);
  const [accountModalOpen, setAccountModalOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNav = (route: string) => {
    navigateTo(route);
    setMobileMenuOpen(false);
    setShopDropdownOpen(false);
  };

  const handleVirtualRailClick = () => {
    if (currentRoute === '/') {
      const el = document.getElementById('clothing-rail-showroom');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    } else {
      navigateTo('/');
      setTimeout(() => {
        const el = document.getElementById('clothing-rail-showroom');
        if (el) {
          el.scrollIntoView({ behavior: 'smooth' });
        }
      }, 350);
    }
    setMobileMenuOpen(false);
    setShopDropdownOpen(false);
  };

  const isDark = theme === 'dark';

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          isDark
            ? isScrolled
              ? 'bg-[#080808]/95 backdrop-blur-md border-b border-white/10 py-3 text-white'
              : 'bg-[#080808] border-b border-white/5 py-4 text-white'
            : isScrolled
              ? 'bg-[#F9F8F5]/95 backdrop-blur-md border-b border-black/10 py-3 text-neutral-900 shadow-sm'
              : 'bg-[#F9F8F5] border-b border-black/5 py-4 text-neutral-900'
        }`}
      >
        <div className="max-w-[1440px] mx-auto px-5 sm:px-8 flex items-center justify-between">
          {/* Left: 3KO Wordmark / Bubble Logo */}
          <button
            onClick={() => handleNav('/')}
            className="flex items-center gap-2 group cursor-pointer focus:outline-none focus-visible:ring-1 focus-visible:ring-current"
            aria-label="3KO Home"
          >
            <img
              src="/images/brand/logo_white_transparent.png"
              alt="3KO Logo"
              className={`h-8 md:h-10 w-auto object-contain transition-transform group-hover:scale-105 ${
                !isDark ? 'invert' : ''
              }`}
            />
          </button>

          {/* Center: Desktop Navigation Links (Clean, uncrowded luxury architecture) */}
          <nav
            className={`hidden lg:flex items-center gap-7 xl:gap-9 text-[12px] xl:text-[13px] tracking-[0.18em] uppercase font-semibold ${
              isDark ? 'text-white/90' : 'text-neutral-800'
            }`}
          >
            <button
              onClick={() => handleNav('/shop')}
              className={`transition-colors relative py-1 focus:outline-none cursor-pointer ${
                currentRoute === '/shop'
                  ? isDark ? 'text-white font-bold' : 'text-black font-bold'
                  : isDark ? 'text-neutral-400 hover:text-white' : 'text-neutral-500 hover:text-black'
              }`}
            >
              SHOP
              {currentRoute === '/shop' && (
                <span className={`absolute bottom-0 left-0 right-0 h-[2px] rounded-full ${isDark ? 'bg-white' : 'bg-black'}`} />
              )}
            </button>

            <button
              onClick={() => handleNav('/street')}
              className={`transition-colors relative py-1 focus:outline-none cursor-pointer ${
                currentRoute === '/street'
                  ? isDark ? 'text-white font-bold' : 'text-black font-bold'
                  : isDark ? 'text-neutral-400 hover:text-white' : 'text-neutral-500 hover:text-black'
              }`}
            >
              STREET
              {currentRoute === '/street' && (
                <span className={`absolute bottom-0 left-0 right-0 h-[2px] rounded-full ${isDark ? 'bg-white' : 'bg-black'}`} />
              )}
            </button>

            <button
              onClick={() => handleNav('/form')}
              className={`transition-colors relative py-1 focus:outline-none cursor-pointer ${
                currentRoute === '/form'
                  ? isDark ? 'text-white font-bold' : 'text-black font-bold'
                  : isDark ? 'text-neutral-400 hover:text-white' : 'text-neutral-500 hover:text-black'
              }`}
            >
              FORM
              {currentRoute === '/form' && (
                <span className={`absolute bottom-0 left-0 right-0 h-[2px] rounded-full ${isDark ? 'bg-white' : 'bg-black'}`} />
              )}
            </button>

            <button
              onClick={() => handleNav('/collections')}
              className={`transition-colors relative py-1 focus:outline-none cursor-pointer ${
                currentRoute.startsWith('/collections') || currentRoute === '/lagos'
                  ? isDark ? 'text-white font-bold' : 'text-black font-bold'
                  : isDark ? 'text-neutral-400 hover:text-white' : 'text-neutral-500 hover:text-black'
              }`}
            >
              LAGOS
              {(currentRoute.startsWith('/collections') || currentRoute === '/lagos') && (
                <span className={`absolute bottom-0 left-0 right-0 h-[2px] rounded-full ${isDark ? 'bg-white' : 'bg-black'}`} />
              )}
            </button>

            <button
              onClick={() => handleNav('/about')}
              className={`transition-colors relative py-1 focus:outline-none cursor-pointer ${
                currentRoute === '/about'
                  ? isDark ? 'text-white font-bold' : 'text-black font-bold'
                  : isDark ? 'text-neutral-400 hover:text-white' : 'text-neutral-500 hover:text-black'
              }`}
            >
              ABOUT
              {currentRoute === '/about' && (
                <span className={`absolute bottom-0 left-0 right-0 h-[2px] rounded-full ${isDark ? 'bg-white' : 'bg-black'}`} />
              )}
            </button>
          </nav>

          {/* Right: Currency, Theme Toggle, Search, Wishlist, Account, Cart */}
          <div className="flex items-center gap-3 sm:gap-4 md:gap-5">
            {/* Currency Selector */}
            <div
              className={`hidden sm:flex items-center text-[11px] font-semibold tracking-wider border px-2 py-1 ${
                isDark ? 'text-neutral-400 border-white/10' : 'text-neutral-600 border-black/10'
              }`}
            >
              {(['NGN', 'USD', 'GBP'] as const).map((curr, i) => (
                <React.Fragment key={curr}>
                  {i > 0 && <span className={isDark ? 'text-white/20' : 'text-black/20'}>|</span>}
                  <button
                    onClick={() => setCurrency(curr)}
                    className={`px-1.5 transition-colors ${
                      currency === curr
                        ? isDark
                          ? 'text-white font-bold'
                          : 'text-black font-bold'
                        : isDark
                          ? 'hover:text-neutral-200'
                          : 'hover:text-black'
                    }`}
                  >
                    {curr}
                  </button>
                </React.Fragment>
              ))}
            </div>

            {/* Light / Dark Theme Switcher */}
            <button
              onClick={toggleTheme}
              className={`flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-mono uppercase tracking-wider transition-all border cursor-pointer ${
                isDark
                  ? 'border-white/20 text-neutral-300 hover:text-white hover:border-white/50 bg-white/5'
                  : 'border-black/20 text-neutral-700 hover:text-black hover:border-black/50 bg-black/5'
              }`}
              title={`Switch to ${isDark ? 'Light Ivory' : 'Dark Obsidian'} theme`}
              aria-label="Toggle theme mode"
            >
              {isDark ? (
                <>
                  <Sun className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
                  <span className="hidden md:inline font-bold">LIGHT</span>
                </>
              ) : (
                <>
                  <Moon className="w-3.5 h-3.5 text-indigo-700" />
                  <span className="hidden md:inline font-bold">DARK</span>
                </>
              )}
            </button>

            {/* Search */}
            <button
              onClick={() => setIsSearchOpen(true)}
              className={`p-1.5 transition-colors focus:outline-none ${
                isDark ? 'hover:text-white' : 'hover:text-black'
              }`}
              aria-label="Search catalog"
            >
              <Search className="w-5 h-5 stroke-[1.75]" />
            </button>

            {/* Wishlist Indicator */}
            {wishlist.length > 0 && (
              <button
                onClick={() => handleNav('/shop')}
                className={`hidden md:flex items-center p-1.5 transition-colors relative ${
                  isDark ? 'hover:text-white' : 'hover:text-black'
                }`}
                aria-label="View saved items"
                title={`${wishlist.length} saved items`}
              >
                <Heart className={`w-5 h-5 stroke-[1.75] ${isDark ? 'fill-white/20' : 'fill-black/10'}`} />
                <span className="absolute -top-1 -right-1 bg-[#DC2626] text-white text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  {wishlist.length}
                </span>
              </button>
            )}

            {/* Account */}
            <button
              onClick={() => setAccountModalOpen(true)}
              className={`hidden sm:flex items-center p-1.5 transition-colors focus:outline-none ${
                isDark ? 'hover:text-white' : 'hover:text-black'
              }`}
              aria-label="Client account"
            >
              <User className="w-5 h-5 stroke-[1.75]" />
            </button>

            {/* Cart Button */}
            <button
              onClick={() => setIsCartOpen(true)}
              className={`flex items-center gap-2 px-3 py-1.5 border transition-all duration-200 cursor-pointer ${
                isDark
                  ? 'border-white/25 hover:border-white hover:bg-white/5'
                  : 'border-black/25 hover:border-black hover:bg-black/5'
              }`}
              aria-label="Open Shopping Bag"
            >
              <ShoppingBag className="w-4 h-4 stroke-[1.75]" />
              <span className="text-xs font-mono font-bold tracking-wider">
                BAG ({totalItems})
              </span>
            </button>

            {/* Mobile Menu Hamburger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className={`lg:hidden p-1.5 transition-colors focus:outline-none ${
                isDark ? 'hover:text-white' : 'hover:text-black'
              }`}
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div
          className={`fixed inset-0 z-30 pt-20 px-6 pb-10 flex flex-col justify-between lg:hidden animate-in fade-in duration-200 ${
            isDark ? 'bg-[#080808] text-white' : 'bg-[#F9F8F5] text-neutral-900'
          }`}
        >
          <div className="flex flex-col gap-5 text-xl tracking-[0.16em] uppercase font-bold pt-4">
            <button
              onClick={() => handleNav('/')}
              className={`text-left transition-colors ${
                currentRoute === '/'
                  ? isDark ? 'text-white' : 'text-black'
                  : isDark ? 'text-neutral-400 hover:text-white' : 'text-neutral-500 hover:text-black'
              }`}
            >
              Home
            </button>
            <button
              onClick={() => handleNav('/shop')}
              className={`text-left transition-colors ${
                currentRoute === '/shop'
                  ? isDark ? 'text-white' : 'text-black'
                  : isDark ? 'text-neutral-400 hover:text-white' : 'text-neutral-500 hover:text-black'
              }`}
            >
              Shop
            </button>
            <button
              onClick={() => handleNav('/street')}
              className={`text-left transition-colors ${
                currentRoute === '/street'
                  ? isDark ? 'text-white' : 'text-black'
                  : isDark ? 'text-neutral-400 hover:text-white' : 'text-neutral-500 hover:text-black'
              }`}
            >
              Street
            </button>
            <button
              onClick={() => handleNav('/form')}
              className={`text-left transition-colors ${
                currentRoute === '/form'
                  ? isDark ? 'text-white' : 'text-black'
                  : isDark ? 'text-neutral-400 hover:text-white' : 'text-neutral-500 hover:text-black'
              }`}
            >
              Form
            </button>
            <button
              onClick={() => handleNav('/collections')}
              className={`text-left transition-colors ${
                currentRoute.startsWith('/collections') || currentRoute === '/lagos'
                  ? isDark ? 'text-white' : 'text-black'
                  : isDark ? 'text-neutral-400 hover:text-white' : 'text-neutral-500 hover:text-black'
              }`}
            >
              Lagos
            </button>
            <button
              onClick={() => handleNav('/about')}
              className={`text-left transition-colors ${
                currentRoute === '/about'
                  ? isDark ? 'text-white' : 'text-black'
                  : isDark ? 'text-neutral-400 hover:text-white' : 'text-neutral-500 hover:text-black'
              }`}
            >
              About
            </button>
            <button
              onClick={() => handleNav('/contact')}
              className={`text-left transition-colors text-sm font-mono ${
                currentRoute === '/contact'
                  ? isDark ? 'text-white' : 'text-black'
                  : isDark ? 'text-neutral-400 hover:text-white' : 'text-neutral-500 hover:text-black'
              }`}
            >
              Contact & Flagship
            </button>

            {/* Virtual Showroom Quick Access */}
            <button
              onClick={handleVirtualRailClick}
              className="text-left text-xs font-mono text-neutral-400 hover:text-white transition-colors flex items-center justify-between py-1"
            >
              <span>Clothing Rail Showroom</span>
              <span className="text-[10px] px-1.5 py-0.5 border border-white/20 uppercase">Interactive</span>
            </button>

            {/* Mobile Theme Switcher */}
            <button
              onClick={toggleTheme}
              className={`text-left transition-colors flex items-center justify-between pt-3 border-t text-sm font-mono ${
                isDark
                  ? 'border-white/10 text-neutral-300 hover:text-white'
                  : 'border-black/10 text-neutral-800 hover:text-black'
              }`}
            >
              <div className="flex items-center gap-2">
                {isDark ? (
                  <Sun className="w-4 h-4 text-amber-300" />
                ) : (
                  <Moon className="w-4 h-4 text-indigo-600" />
                )}
                <span>Theme: {isDark ? 'Dark Obsidian' : 'Light Ivory'}</span>
              </div>
              <span
                className={`text-[10px] px-2 py-0.5 border font-bold uppercase ${
                  isDark ? 'border-white/30 text-white' : 'border-black/30 text-black'
                }`}
              >
                Switch
              </span>
            </button>

          </div>

          <div className={`pt-6 border-t mt-6 flex flex-col gap-4 ${isDark ? 'border-white/10' : 'border-black/10'}`}>
            <div className="flex items-center justify-between text-xs tracking-wider">
              <span className={isDark ? 'text-neutral-400' : 'text-neutral-500'}>SELECT CURRENCY:</span>
              <div className="flex gap-2">
                {(['NGN', 'USD', 'GBP'] as const).map((curr) => (
                  <button
                    key={curr}
                    onClick={() => setCurrency(curr)}
                    className={`px-2.5 py-1 text-xs border ${
                      currency === curr
                        ? isDark
                          ? 'border-white text-white font-bold bg-white/10'
                          : 'border-black text-black font-bold bg-black/10'
                        : isDark
                          ? 'border-white/10 text-neutral-400'
                          : 'border-black/10 text-neutral-500'
                    }`}
                  >
                    {curr}
                  </button>
                ))}
              </div>
            </div>

            <p className={`text-xs font-sans tracking-wide ${isDark ? 'text-neutral-500' : 'text-neutral-500'}`}>
              LAGOS IN EVERY THREAD. Delivered across Nigeria & Worldwide.
            </p>
          </div>
        </div>
      )}

      {/* Account Info Modal */}
      {accountModalOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setAccountModalOpen(false)}
        >
          <div
            className={`border max-w-md w-full p-6 sm:p-8 ${
              isDark ? 'bg-[#121212] border-white/15 text-white' : 'bg-white border-black/15 text-neutral-900'
            }`}
            onClick={(e) => e.stopPropagation()}
          >
            <div className={`flex items-center justify-between pb-4 border-b ${isDark ? 'border-white/10' : 'border-black/10'}`}>
              <h3 className="font-display font-bold uppercase tracking-wider text-lg">
                3KO Client Portal
              </h3>
              <button
                onClick={() => setAccountModalOpen(false)}
                className={`transition-colors ${isDark ? 'text-neutral-400 hover:text-white' : 'text-neutral-500 hover:text-black'}`}
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className={`py-6 space-y-4 text-sm ${isDark ? 'text-neutral-300' : 'text-neutral-700'}`}>
              {currentUser ? (
                <div className="space-y-4">
                  <div className={`p-3.5 border rounded-sm ${isDark ? 'bg-white/5 border-white/10' : 'bg-neutral-50 border-black/10'}`}>
                    <span className="block text-[10px] font-mono uppercase tracking-wider text-neutral-400">
                      Signed In As:
                    </span>
                    <strong className={`block text-sm truncate mt-0.5 ${isDark ? 'text-white' : 'text-black'}`}>
                      {currentUser.displayName || currentUser.email}
                    </strong>
                    <span className="block text-xs text-neutral-400 font-mono mt-0.5">
                      {currentUser.email}
                    </span>
                    {isAdmin && (
                      <span className="inline-block mt-2 px-2 py-0.5 text-[10px] font-mono font-bold uppercase tracking-wider bg-lime-400/20 text-lime-400 border border-lime-400/30">
                        Atelier Administrator
                      </span>
                    )}
                  </div>

                  {isAdmin && (
                    <button
                      onClick={() => {
                        handleNav('/admin');
                        setAccountModalOpen(false);
                      }}
                      className="w-full bg-lime-400 hover:bg-lime-300 text-black font-bold py-3 text-xs uppercase tracking-widest transition-colors cursor-pointer"
                    >
                      Open Atelier Admin Dashboard →
                    </button>
                  )}

                  <button
                    onClick={async () => {
                      await logout();
                      setAccountModalOpen(false);
                    }}
                    className={`w-full font-bold py-2.5 text-xs uppercase tracking-widest border transition-colors cursor-pointer ${
                      isDark
                        ? 'border-white/20 text-neutral-300 hover:text-white hover:border-white'
                        : 'border-black/20 text-neutral-700 hover:text-black hover:border-black'
                    }`}
                  >
                    Sign Out
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  <p className="text-xs text-neutral-400 leading-relaxed">
                    Sign in to track orders, manage your shipping addresses, or access owner administration privileges.
                  </p>
                  <button
                    onClick={async () => {
                      try {
                        await loginWithGoogle();
                        setAccountModalOpen(false);
                      } catch (e) {
                        // handled
                      }
                    }}
                    className={`w-full font-bold py-3 text-xs uppercase tracking-widest transition-colors flex items-center justify-center gap-2 cursor-pointer ${
                      isDark
                        ? 'bg-white text-[#080808] hover:bg-neutral-200'
                        : 'bg-black text-white hover:bg-neutral-800'
                    }`}
                  >
                    <span>Continue with Google</span>
                  </button>

                  <div className="pt-2 text-center">
                    <button
                      onClick={() => {
                        handleNav('/admin');
                        setAccountModalOpen(false);
                      }}
                      className={`text-[11px] font-mono uppercase tracking-wider hover:underline transition-colors ${
                        isDark ? 'text-neutral-400 hover:text-white' : 'text-neutral-600 hover:text-black'
                      }`}
                    >
                      Store Owner / Atelier Login →
                    </button>
                  </div>
                </div>
              )}
            </div>
            <div className={`pt-4 border-t text-xs text-center ${isDark ? 'border-white/10 text-neutral-500' : 'border-black/10 text-neutral-500'}`}>
              3KO Studio — Lagos in Every Thread.
            </div>
          </div>
        </div>
      )}
    </>
  );
};
