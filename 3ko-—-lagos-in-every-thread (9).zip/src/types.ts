export type BrandLine = 'street' | 'form' | 'edition' | 'all';

export type ProductCategory =
  | 'shirts'
  | 'joggers'
  | 'hoodies'
  | 'caps'
  | 'jerseys'
  | 'polos'
  | 'trousers'
  | 'tailoring'
  | 'packaging';

export type Currency = 'NGN' | 'USD' | 'GBP';

export interface LagosCollection {
  id: string; // '001', '002', etc.
  numberStr: string;
  slug: string;
  name: string;
  fullName: string;
  colorName: string;
  colorHex: string;
  accentBg: string;
  image: string;
  boxImage: string;
  landmark: string;
  coordinates: string;
  personality: string;
  shortDesc: string;
  fullStory: string;
  paletteDescription: string;
}

export interface BoxPackagingOption {
  available: boolean;
  boxName: string;
  collectionId: string;
  boxImage: string;
  priceNGN: number;
  priceUSD: number;
  priceGBP: number;
  coordinates: string;
  description: string;
}

export interface Product {
  id: string;
  slug: string;
  name: string;
  subtitle: string;
  line: 'street' | 'form' | 'edition';
  category: ProductCategory;
  collectionId: string;
  collectionName: string;
  sku?: string;
  priceNGN: number;
  priceUSD: number;
  priceGBP: number;
  compareAtPriceNGN?: number;
  compareAtPriceUSD?: number;
  compareAtPriceGBP?: number;
  color: string;
  colorHex: string;
  secondaryColors?: { name: string; hex: string; image?: string; theme?: string }[];
  sizes: string[];
  description: string;
  editorialNote: string;
  fabricDetails: string[];
  careInstructions: string[];
  fit: string;
  images: string[];
  primaryImageIndex?: number;
  isNew?: boolean;
  isFeatured?: boolean;
  isBestSeller?: boolean;
  isPreOrder?: boolean;
  preOrderLimit?: number;
  preOrderCount?: number;
  productionStatus?: string;
  estimatedDelivery?: string;
  stockQuantity?: number;
  availability?: 'in_stock' | 'low_stock' | 'out_of_stock' | 'preorder_only' | 'archived';
  isArchived?: boolean;
  allowNegotiation?: boolean;
  minOfferPercentage?: number;
  packagingNote: string;
  boxPackaging: BoxPackagingOption;
  createdAt?: string;
  updatedAt?: string;
}

export interface CartItem {
  id: string;
  product: Product;
  selectedSize: string;
  selectedColor: string;
  quantity: number;
  includeCollectorBox: boolean;
  boxPriceNGN: number;
  boxPriceUSD: number;
  boxPriceGBP: number;
}

export interface OrderItem {
  id?: string;
  productId: string;
  name: string;
  slug?: string;
  sku?: string;
  image?: string;
  product?: Product;
  selectedSize: string;
  selectedColor?: string;
  quantity: number;
  regularPrice: number;
  negotiatedPrice?: number | null;
  unitPrice: number;
  boxPrice?: number;
  boxPriceNGN?: number;
  boxPriceUSD?: number;
  boxPriceGBP?: number;
  includeCollectorBox?: boolean;
  isPreOrder?: boolean;
  isNegotiated?: boolean;
  purchaseType?: 'normal' | 'negotiated' | 'preorder';
  totalItemPrice?: number;
}

export interface OrderCustomer {
  fullName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  postalCode?: string;
  country: string;
}

// Standardized Commerce Status Vocabulary (Priority 4)
export type PaymentStatus = 'PENDING' | 'SUCCESS' | 'FAILED' | 'REFUNDED';

export type OrderStatus =
  | 'PENDING_PAYMENT'
  | 'PAID'
  | 'PROCESSING'
  | 'READY'
  | 'SHIPPED'
  | 'DELIVERED'
  | 'CANCELLED'
  | 'REFUNDED';

// Normalization utilities for uniform state handling across DB, Paystack, and UI
export function normalizePaymentStatus(status?: string | null): PaymentStatus {
  if (!status) return 'PENDING';
  const upper = status.trim().toUpperCase();
  if (upper === 'SUCCESS' || upper === 'PAID') return 'SUCCESS';
  if (upper === 'FAILED') return 'FAILED';
  if (upper === 'REFUNDED') return 'REFUNDED';
  return 'PENDING';
}

export function normalizeOrderStatus(status?: string | null): OrderStatus {
  if (!status) return 'PENDING_PAYMENT';
  const upper = status.trim().toUpperCase();
  if (upper === 'PAID' || upper === 'CONFIRMED') return 'PAID';
  if (upper === 'PROCESSING') return 'PROCESSING';
  if (upper === 'READY') return 'READY';
  if (upper === 'SHIPPED') return 'SHIPPED';
  if (upper === 'DELIVERED') return 'DELIVERED';
  if (upper === 'CANCELLED') return 'CANCELLED';
  if (upper === 'REFUNDED') return 'REFUNDED';
  return 'PENDING_PAYMENT';
}

// Backward-compatible aliases
export type OrderWorkflowStatus =
  | OrderStatus
  | 'pending_payment'
  | 'confirmed'
  | 'paid'
  | 'processing'
  | 'ready'
  | 'shipped'
  | 'delivered'
  | 'cancelled'
  | 'refunded';

export type PaymentLifecycleStatus = PaymentStatus | 'pending' | 'paid' | 'success' | 'failed' | 'refunded';

export interface Order {
  id: string;
  orderNumber: string;
  items: (CartItem | OrderItem | any)[];
  regularSubtotal?: number;
  subtotal: number;
  packagingFee?: number;
  shippingFee: number;
  discount: number;
  total: number;
  currency: Currency;
  customer: OrderCustomer;
  shippingMethod: string;
  paymentMethod: string;
  paymentReference?: string | null;
  authorizationUrl?: string;
  accessCode?: string;
  paymentStatus: PaymentLifecycleStatus;
  paymentChannel?: string;
  orderDate?: string;
  orderStatus: OrderWorkflowStatus;
  status: OrderWorkflowStatus | 'confirmed';
  trackingNumber?: string;
  fulfillmentCarrier?: string;
  estimatedDelivery?: string;
  notes?: string;
  isPreOrder?: boolean;
  isNegotiated?: boolean;
  purchaseType?: 'normal' | 'negotiated' | 'preorder';
  userId?: string;
  paidAt?: string;
  customerConfirmationEmailSent?: boolean;
  adminNotificationEmailSent?: boolean;
  customerEmailSentAt?: string;
  adminEmailSentAt?: string;
  emailDispatchError?: string;
  negotiatedOfferId?: string | null;
  negotiatedDiscount?: number;
  createdAt?: string;
  updatedAt?: string;
}

export interface VipOffer {
  id: string;
  productId: string;
  productName: string;
  customerName: string;
  customerEmail: string;
  offerAmountNGN: number;
  listPriceNGN: number;
  status: 'pending' | 'accepted' | 'declined';
  notes?: string;
  userId?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface PromoCode {
  code: string;
  discountPercentage: number;
  description: string;
  isActive: boolean;
}

export type ThemeMode = 'dark' | 'light';


export interface SiteBanners {
  heroBanner: string;
  heroSlide2: string;
  heroSlide3: string;
  streetwearBanner: string;
  smartwearBanner: string;
  packagingBanner: string;
  lagosGuideBanner: string;
}

export interface StoreSettings {
  announcementText: string;
  isAnnouncementActive: boolean;
  freeShippingThresholdNGN: number;
  freeShippingThresholdUSD: number;
  freeShippingThresholdGBP: number;
  contactEmail: string;
  contactPhone: string;
  flagshipLocation: string;
  banners: SiteBanners;
}

