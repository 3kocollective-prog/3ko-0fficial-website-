import { Product } from '../types';

export const PRODUCTS: Product[] = [
  // ==========================================
  // STREETWEAR: SHIRTS & GRAPHIC TEES
  // ==========================================
  {
    id: 'prod-001-tee',
    slug: 'lagos-001-bridge-tee',
    name: '3KO — 3KO 001 BRIDGE GRAPHIC TEE',
    subtitle: 'Heavyweight Signature Back-Graphic T-Shirt',
    line: 'street',
    category: 'shirts',
    collectionId: '001',
    collectionName: '3KO 001 — IKOYI',
    priceNGN: 55000,
    priceUSD: 38,
    priceGBP: 30,
    color: 'Cream / Bone',
    colorHex: '#F4F1EA',
    secondaryColors: [
      { name: 'Cream / Bone', hex: '#F4F1EA' },
      { name: 'Pitch Black', hex: '#080808' }
    ],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    description: 'The definitive 3KO graphic shirt. Illustrated with the cable-stayed Lekki-Ikoyi Link Bridge skyline fused with the 3KO bubble emblem on the back, and front chest coordinates (6.4289° N, 3.3672° E).',
    editorialNote: 'As seen in the official 3KO campaign overlooking the Ikoyi waterfront. Designed with dropped shoulders and dense 280 GSM ringspun cotton.',
    fabricDetails: [
      '100% ringspun organic cotton jersey (280 GSM)',
      'High-density screen print with tactile matte puff ink on back',
      'Minimal 3KO chest wordmark with Ikoyi coordinates on front left',
      'Thick 1.25" rib collar that retains structure after repeated wear',
      'Double-needle stitching at cuffs and hem'
    ],
    careInstructions: [
      'Wash inside out in cold water',
      'Line dry only; avoid direct heat to protect graphic puff ink',
      'Cool iron on reverse side'
    ],
    fit: 'Relaxed boxy streetwear cut with dropped shoulders.',
    images: [
      '/images/apparel/look_001_ikoyi_tee_cap.jpg',
      '/images/social/social_1_model_back.jpg',
      '/images/brand/street_panel.jpg'
    ],
    isFeatured: true,
    isBestSeller: true,
    isNew: true,
    packagingNote: 'Optional recommended 3KO 001 Matte Obsidian collector box with serialized certificate of authenticity.',
    boxPackaging: {
      available: true,
      boxName: '3KO 001 IKOYI COLLECTOR BOX',
      collectionId: '001',
      boxImage: '/images/packaging/box_001_ikoyi.jpg',
      priceNGN: 15000,
      priceUSD: 12,
      priceGBP: 10,
      coordinates: '6.4289° N, 3.3672° E',
      description: 'Matte Obsidian 1200 GSM rigid box with white architectural sketch of Lekki-Ikoyi Bridge, embossed 3KO logo, and serialized registry card.'
    }
  },
  {
    id: 'prod-003-tee',
    slug: 'lagos-003-island-tee',
    name: '3KO — 3KO 003 LAGOS ISLAND TEE',
    subtitle: 'High-Density Architectural Skyline T-Shirt',
    line: 'street',
    category: 'shirts',
    collectionId: '003',
    collectionName: '3KO 003 — LAGOS ISLAND',
    priceNGN: 55000,
    priceUSD: 38,
    priceGBP: 30,
    color: 'Forest Green',
    colorHex: '#14532D',
    secondaryColors: [
      { name: 'Forest Green', hex: '#14532D' },
      { name: 'Pitch Black', hex: '#080808' }
    ],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    description: 'Featuring the iconic Marina skyline and Carter Bridge waterfront towers under the bold 3KO emblem. Finished with historical coordinates (6.4500° N, 3.3958° E).',
    editorialNote: 'Derived from the mercantile heart of Isale Eko. Styled effortlessly with beige chinos or street shorts.',
    fabricDetails: [
      '100% combed cotton jersey (280 GSM)',
      'Silkscreened Marina financial skyline graphics',
      'Reinforced shoulder seam binding'
    ],
    careInstructions: ['Machine wash cold inside out', 'Hang to dry'],
    fit: 'Boxy streetwear fit.',
    images: [
      '/images/apparel/look_003_lagos_island_tee_polo.jpg',
      '/images/collections/003_lagos_island.jpg'
    ],
    isFeatured: true,
    packagingNote: 'Arrives optionally in the 3KO 003 Cobalt Blue architectural collector box.',
    boxPackaging: {
      available: true,
      boxName: '3KO 003 LAGOS ISLAND COLLECTOR BOX',
      collectionId: '003',
      boxImage: '/images/packaging/box_003_lagos_island.jpg',
      priceNGN: 15000,
      priceUSD: 12,
      priceGBP: 10,
      coordinates: '6.4500° N, 3.3958° E',
      description: 'Lagos Harbor Navy 1200 GSM rigid box with white architectural sketch of Marina towers and Carter Bridge.'
    }
  },
  {
    id: 'prod-005-palm-tee',
    slug: 'lagos-005-palm-tee',
    name: '3KO — 3KO 005 TARKWA BAY PALM TEE',
    subtitle: 'Coastal Beachside Graphic T-Shirt',
    line: 'street',
    category: 'shirts',
    collectionId: '005',
    collectionName: '3KO 005 — TARKWA BAY',
    priceNGN: 55000,
    priceUSD: 38,
    priceGBP: 30,
    color: 'Warm Sand / Cream',
    colorHex: '#F4F1EA',
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    description: 'Inspired by the gentle Atlantic surf, coconut palms, and wooden fishing boats lining Tarkwa Bay. Detailed with coordinates (6.4216° N, 3.8085° E).',
    editorialNote: 'The signature beach-to-street uniform. Styled with 3KO navy drawstring shorts and matching bucket hat.',
    fabricDetails: [
      '100% organic cotton jersey (260 GSM)',
      'Subtle distressed graphic print with tropical palm illustration',
      'Soft enzyme garment wash'
    ],
    careInstructions: ['Wash cold with mild detergent', 'Do not tumble dry'],
    fit: 'Relaxed oversized fit.',
    images: [
      '/images/apparel/look_005_tarkwa_palm_tee_shorts.jpg',
      '/images/collections/005_tarkwa_bay.jpg'
    ],
    isFeatured: true,
    packagingNote: 'Optional recommended 3KO 005 Sky-Blue collector box.',
    boxPackaging: {
      available: true,
      boxName: '3KO 005 TARKWA BAY COLLECTOR BOX',
      collectionId: '005',
      boxImage: '/images/packaging/box_005_tarkwa_bay.jpg',
      priceNGN: 15000,
      priceUSD: 12,
      priceGBP: 10,
      coordinates: '6.4216° N, 3.8085° E',
      description: 'Sky-Blue 1200 GSM rigid magnetic box with palm grove and coastal harbor boat sketches.'
    }
  },
  {
    id: 'prod-004-tee',
    slug: 'lagos-004-oversized-tee',
    name: '3KO — 3KO 004 BALOGUN OVERSIZED TEE',
    subtitle: 'Vibrant Heavyweight Street T-Shirt',
    line: 'street',
    category: 'shirts',
    collectionId: '004',
    collectionName: '3KO 004 — BALOGUN',
    priceNGN: 52000,
    priceUSD: 35,
    priceGBP: 28,
    color: 'Clean White',
    colorHex: '#FFFFFF',
    secondaryColors: [
      { name: 'Clean White', hex: '#FFFFFF' },
      { name: 'Electric Crimson', hex: '#DC2626' }
    ],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    description: 'Channeling the unstoppable energy and chromatic frenzy of Balogun Market. Clean white cotton with tactile 3KO chest badge.',
    editorialNote: 'Statement streetwear with uncompromising saturation. Pairs with raw denim or Balogun street joggers.',
    fabricDetails: [
      '100% open-end carded cotton (260 GSM)',
      'Tactile puff embroidery',
      'Reinforced taped shoulder seams'
    ],
    careInstructions: ['Wash cold inside out', 'Hang to dry'],
    fit: 'True oversized drape.',
    images: [
      '/images/apparel/look_004_balogun_hoodie_shorts.jpg',
      '/images/collections/004_balogun.jpg'
    ],
    packagingNote: 'Encased in the 3KO 004 high-gloss red foil collector box.',
    boxPackaging: {
      available: true,
      boxName: '3KO 004 BALOGUN COLLECTOR BOX',
      collectionId: '004',
      boxImage: '/images/packaging/box_004_balogun.jpg',
      priceNGN: 15000,
      priceUSD: 12,
      priceGBP: 10,
      coordinates: '6.4544° N, 3.3836° E',
      description: 'Electric Crimson rigid box stamped with Balogun open-air canopy sketches and market coordinates.'
    }
  },

  // ==========================================
  // STREETWEAR: JOGGERS & SHORTS
  // ==========================================
  {
    id: 'prod-005-shorts',
    slug: 'lagos-005-drawstring-shorts',
    name: '3KO — 3KO 005 TARKWA BAY DRAWSTRING SHORTS',
    subtitle: 'Heavyweight Loopback Athletic Shorts',
    line: 'street',
    category: 'joggers',
    collectionId: '005',
    collectionName: '3KO 005 — TARKWA BAY',
    priceNGN: 48000,
    priceUSD: 32,
    priceGBP: 26,
    color: 'Deep Navy Blue',
    colorHex: '#1E293B',
    sizes: ['S', 'M', 'L', 'XL'],
    description: 'Relaxed heavyweight sweat shorts constructed with dense loopback cotton, thick elasticated drawstring waistband, metal eyelets, and white 3KO bubble logo on the left hem.',
    editorialNote: 'Directly featured in the 3KO Streetwear lookbook paired with the Tarkwa Bay Palm graphic tee.',
    fabricDetails: [
      '420 GSM heavy loopback French terry',
      'Screenprinted white 3KO bubble emblem on left thigh',
      'Deep functional welt side pockets & back pocket',
      'Chunky natural cotton drawcord with dipped silicone aglets'
    ],
    careInstructions: ['Machine wash cold', 'Wash with similar colors', 'Dry flat'],
    fit: 'Relaxed comfortable cut sitting just above the knee.',
    images: [
      '/images/apparel/look_005_tarkwa_palm_tee_shorts.jpg',
      '/images/brand/street_panel.jpg'
    ],
    isFeatured: true,
    packagingNote: 'Optional recommended 3KO 005 Sky-Blue collector box.',
    boxPackaging: {
      available: true,
      boxName: '3KO 005 TARKWA BAY COLLECTOR BOX',
      collectionId: '005',
      boxImage: '/images/packaging/box_005_tarkwa_bay.jpg',
      priceNGN: 15000,
      priceUSD: 12,
      priceGBP: 10,
      coordinates: '6.4216° N, 3.8085° E',
      description: 'Sky-Blue 1200 GSM rigid box with coastal palm sketches and archival tissue.'
    }
  },
  {
    id: 'prod-004-joggers',
    slug: 'lagos-004-balogun-joggers',
    name: '3KO — 3KO 004 BALOGUN STREET JOGGERS',
    subtitle: 'Tapered Heavyweight Street Sweatpants',
    line: 'street',
    category: 'joggers',
    collectionId: '004',
    collectionName: '3KO 004 — BALOGUN',
    priceNGN: 68000,
    priceUSD: 46,
    priceGBP: 37,
    color: 'Pitch Black',
    colorHex: '#080808',
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    description: 'Designed for daily movement in the city. Heavyweight 450 GSM fleece with tailored tapered legs, custom contrast white cuff panels, and 3KO coordinate screenprint.',
    editorialNote: 'The everyday streetwear companion to the Balogun Market hoodie.',
    fabricDetails: [
      '450 GSM 100% ringspun cotton loopback',
      'Heavy-duty ribbed ankle cuffs with contrast paneling',
      'Concealed zip pockets for secure phone and wallet storage'
    ],
    careInstructions: ['Machine wash cold', 'Air dry only'],
    fit: 'Modern tapered silhouette.',
    images: [
      '/images/apparel/look_004_balogun_hoodie_shorts.jpg',
      '/images/social/social_5_street_walk.jpg'
    ],
    packagingNote: 'Arrives in the 3KO 004 Red collector box.',
    boxPackaging: {
      available: true,
      boxName: '3KO 004 BALOGUN COLLECTOR BOX',
      collectionId: '004',
      boxImage: '/images/packaging/box_004_balogun.jpg',
      priceNGN: 15000,
      priceUSD: 12,
      priceGBP: 10,
      coordinates: '6.4544° N, 3.3836° E',
      description: 'Electric Crimson rigid box with market bazaar graphics.'
    }
  },
  {
    id: 'prod-007-joggers',
    slug: 'lagos-007-sabo-joggers',
    name: '3KO — 3KO 007 SABO FLEECE JOGGERS',
    subtitle: 'Relaxed Tech-Corridor Sweats',
    line: 'street',
    category: 'joggers',
    collectionId: '007',
    collectionName: '3KO 007 — YABA',
    priceNGN: 65000,
    priceUSD: 44,
    priceGBP: 35,
    color: 'Mocha Earth Brown',
    colorHex: '#854D0E',
    sizes: ['S', 'M', 'L', 'XL'],
    description: 'Warm earth tones honoring the creative builders and software hackers of Sabo, Yaba. Cut with an easy relaxed leg and elasticated ankle gathers.',
    editorialNote: 'Engineered for extended studio work sessions and late-night sprints.',
    fabricDetails: ['100% organic cotton fleece (420 GSM)', 'Double-layer knee articulation'],
    careInstructions: ['Wash cold inside out', 'Hang dry'],
    fit: 'Relaxed streetwear cut.',
    images: [
      '/images/collections/007_yaba.jpg',
      '/images/social/social_5_street_walk.jpg'
    ],
    packagingNote: 'Optional recommended 3KO 007 Brown collector box.',
    boxPackaging: {
      available: true,
      boxName: '3KO 007 YABA COLLECTOR BOX',
      collectionId: '007',
      boxImage: '/images/packaging/box_007_yaba.jpg',
      priceNGN: 15000,
      priceUSD: 12,
      priceGBP: 10,
      coordinates: '6.5244° N, 3.3717° E',
      description: 'Rich Mocha 1200 GSM box with Yaba Tech gate illustrations.'
    }
  },

  // ==========================================
  // STREETWEAR: HOODIES
  // ==========================================
  {
    id: 'prod-002-black-hoodie',
    slug: 'lagos-002-theatre-hoodie-black',
    name: '3KO — 3KO 002 ARCHITECTURAL HOODIE (BLACK)',
    subtitle: 'Heavyweight National Theatre Back-Graphic Pullover',
    line: 'street',
    category: 'hoodies',
    collectionId: '002',
    collectionName: '3KO 002 — NATIONAL THEATRE',
    priceNGN: 85000,
    priceUSD: 58,
    priceGBP: 46,
    color: 'Jet Black',
    colorHex: '#080808',
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    description: 'Dedicated to the monumental concrete crest of the National Arts Theatre in Iganmu. Features the iconic 3KO bubble logo above a detailed architectural sketch of the theatre, along with FESTAC coordinates (6.4606° N, 3.3633° E).',
    editorialNote: 'The flagship outerwear piece of the 3KO streetwear collection as seen in the official campaign materials.',
    fabricDetails: [
      '480 GSM ultra-dense loopback French terry',
      'High-definition silkscreen graphic on back',
      'Dual-layer structured hood without drawstrings for clean silhouette',
      'Reinforced kangaroo pocket with hidden internal card pocket'
    ],
    careInstructions: ['Wash cold inside out', 'Line dry only', 'Do not iron graphic'],
    fit: 'Substantial boxy streetwear cut with dropped shoulders.',
    images: [
      '/images/apparel/look_002_theatre_hoodies.jpg',
      '/images/collections/002_national_theatre.jpg'
    ],
    isFeatured: true,
    isBestSeller: true,
    packagingNote: 'Optional recommended 3KO 002 Architectural Bone White collector box.',
    boxPackaging: {
      available: true,
      boxName: '3KO 002 NATIONAL THEATRE COLLECTOR BOX',
      collectionId: '002',
      boxImage: '/images/packaging/box_002_national_theatre.jpg',
      priceNGN: 15000,
      priceUSD: 12,
      priceGBP: 10,
      coordinates: '6.4500° N, 3.3958° E',
      description: 'Chalk White 1200 GSM rigid box with black architectural sketch of National Theatre.'
    }
  },
  {
    id: 'prod-002-cream-hoodie',
    slug: 'lagos-002-theatre-hoodie-cream',
    name: '3KO — 3KO 002 EMBLEM HOODIE (CREAM)',
    subtitle: 'Clean Minimalist Drawstring Pullover',
    line: 'street',
    category: 'hoodies',
    collectionId: '002',
    collectionName: '3KO 002 — NATIONAL THEATRE',
    priceNGN: 82000,
    priceUSD: 55,
    priceGBP: 44,
    color: 'Warm Bone / Cream',
    colorHex: '#F4F1EA',
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    description: 'The companion cream pullover featuring the circular 3KO bubble logo on the left chest and back coordinate tag. Crafted in ultra-soft brushed French terry.',
    editorialNote: 'Paired seamlessly with black joggers or relaxed denim.',
    fabricDetails: [
      '450 GSM organic cotton French terry',
      'Tactile high-relief chest embroidery',
      'Metal aglet tonal drawstrings'
    ],
    careInstructions: ['Wash with whites only', 'Cold water', 'Dry flat'],
    fit: 'Relaxed modern fit.',
    images: [
      '/images/apparel/look_002_theatre_hoodies.jpg',
      '/images/social/social_5_street_walk.jpg'
    ],
    isFeatured: true,
    packagingNote: 'Optional recommended 3KO 002 Bone White collector box.',
    boxPackaging: {
      available: true,
      boxName: '3KO 002 NATIONAL THEATRE COLLECTOR BOX',
      collectionId: '002',
      boxImage: '/images/packaging/box_002_national_theatre.jpg',
      priceNGN: 15000,
      priceUSD: 12,
      priceGBP: 10,
      coordinates: '6.4500° N, 3.3958° E',
      description: 'Chalk White 1200 GSM box with architectural sketches and tissue.'
    }
  },
  {
    id: 'prod-004-hoodie',
    slug: 'lagos-004-balogun-hoodie',
    name: '3KO — 3KO 004 BALOGUN OVERSIZED HOODIE',
    subtitle: 'Fierce Merchant Culture Pullover',
    line: 'street',
    category: 'hoodies',
    collectionId: '004',
    collectionName: '3KO 004 — BALOGUN',
    priceNGN: 85000,
    priceUSD: 58,
    priceGBP: 46,
    color: 'Pitch Black',
    colorHex: '#080808',
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    description: 'Honoring the bustling canopy corridors and merchant spirit of Balogun Market. Giant back print featuring 3KO bubble logo, market stalls illustration, and Broad Street coordinates.',
    editorialNote: 'As seen in the Balogun collection campaign lookbook.',
    fabricDetails: [
      '480 GSM dense loopback cotton',
      'Puff print with crisp white line detailing',
      'Ribbed cuffs and waistband'
    ],
    careInstructions: ['Cold wash inside out', 'Do not tumble dry'],
    fit: 'Oversized boxy cut.',
    images: [
      '/images/apparel/look_004_balogun_hoodie_shorts.jpg',
      '/images/collections/004_balogun.jpg'
    ],
    packagingNote: 'Optional recommended 3KO 004 Electric Crimson box.',
    boxPackaging: {
      available: true,
      boxName: '3KO 004 BALOGUN COLLECTOR BOX',
      collectionId: '004',
      boxImage: '/images/packaging/box_004_balogun.jpg',
      priceNGN: 15000,
      priceUSD: 12,
      priceGBP: 10,
      coordinates: '6.4544° N, 3.3836° E',
      description: 'Electric Crimson 1200 GSM box with market canopy sketches.'
    }
  },

  // ==========================================
  // STREETWEAR: CAPS & HEADWEAR
  // ==========================================
  {
    id: 'prod-001-cap',
    slug: 'lagos-001-cap',
    name: '3KO — 3KO 001 EMBROIDERED 6-PANEL CAP',
    subtitle: 'Structured 6-Panel Cotton Twill Cap',
    line: 'street',
    category: 'caps',
    collectionId: '001',
    collectionName: '3KO 001 — IKOYI',
    priceNGN: 35000,
    priceUSD: 24,
    priceGBP: 19,
    color: 'Matte Black',
    colorHex: '#121212',
    secondaryColors: [
      { name: 'Matte Black', hex: '#121212' },
      { name: 'Forest Green', hex: '#14532D' }
    ],
    sizes: ['ONE SIZE (ADJUSTABLE)'],
    description: 'Everyday headwear built with structured front panels, custom 3D raised puff embroidery of the 3KO emblem, and brass metal slide buckle at the back.',
    editorialNote: 'Featured throughout 3KO STREET looks. Pairs with tailored blazers and graphic tees alike.',
    fabricDetails: [
      '100% heavy washed cotton chino twill',
      'High-relief 3D embroidery on front crown',
      'Subtle "LAGOS IN EVERY THREAD" embroidery above back arch',
      'Custom embossed brass slider buckle closure',
      'Moisture-wicking internal sweatband'
    ],
    careInstructions: ['Spot clean with damp cloth', 'Air dry'],
    fit: 'Adjustable strap fits 54cm to 62cm.',
    images: [
      '/images/social/social_4_cap.jpg',
      '/images/apparel/look_001_ikoyi_tee_cap.jpg',
      '/images/apparel/look_003_lagos_island_tee_polo.jpg'
    ],
    isFeatured: true,
    packagingNote: 'Optional recommended 3KO 001 Matte Obsidian collector box.',
    boxPackaging: {
      available: true,
      boxName: '3KO 001 IKOYI COLLECTOR BOX',
      collectionId: '001',
      boxImage: '/images/packaging/box_001_ikoyi.jpg',
      priceNGN: 15000,
      priceUSD: 12,
      priceGBP: 10,
      coordinates: '6.4289° N, 3.3672° E',
      description: 'Matte Obsidian 1200 GSM rigid box with bridge sketches.'
    }
  },
  {
    id: 'prod-005-bucket',
    slug: 'lagos-005-bucket-hat',
    name: '3KO — 3KO 005 TARKWA BAY BUCKET HAT',
    subtitle: 'Relaxed Coastal Cotton Twill Bucket',
    line: 'street',
    category: 'caps',
    collectionId: '005',
    collectionName: '3KO 005 — TARKWA BAY',
    priceNGN: 38000,
    priceUSD: 26,
    priceGBP: 21,
    color: 'Deep Navy Blue',
    colorHex: '#1E293B',
    sizes: ['S/M', 'L/XL'],
    description: 'Shield against the Atlantic sun. Constructed in durable washed cotton twill with reinforced brim stitching and circular white 3KO logo embroidery on front.',
    editorialNote: 'The quintessential Tarkwa Bay weekend accessory as shown in the uploaded collection sheet.',
    fabricDetails: ['100% washed cotton twill', 'Breathable metal ventilation eyelets', 'Custom interior taped seams'],
    careInstructions: ['Spot clean only'],
    fit: 'Classic bucket fit with downward sloping brim.',
    images: [
      '/images/apparel/look_005_tarkwa_palm_tee_shorts.jpg',
      '/images/collections/005_tarkwa_bay.jpg'
    ],
    packagingNote: 'Optional recommended 3KO 005 Sky-Blue collector box.',
    boxPackaging: {
      available: true,
      boxName: '3KO 005 TARKWA BAY COLLECTOR BOX',
      collectionId: '005',
      boxImage: '/images/packaging/box_005_tarkwa_bay.jpg',
      priceNGN: 15000,
      priceUSD: 12,
      priceGBP: 10,
      coordinates: '6.4216° N, 3.8085° E',
      description: 'Sky-Blue 1200 GSM box with beachside illustrations.'
    }
  },

  // ==========================================
  // STREETWEAR: FOOTBALL JERSEYS (8 COLORWAYS)
  // ==========================================
  {
    id: 'prod-jersey-main',
    slug: '3ko-football-jersey',
    name: '3KO — OFFICIAL LAGOS FOOTBALL JERSEY',
    subtitle: 'Custom Jacquard Palm Performance Kit — 8 Colorways',
    line: 'street',
    category: 'jerseys',
    collectionId: '003',
    collectionName: 'LAGOS FOOTBALL EDITIONS',
    priceNGN: 62000,
    priceUSD: 42,
    priceGBP: 34,
    color: 'Black (Original)',
    colorHex: '#080808',
    secondaryColors: [
      { name: 'Black (Original)', hex: '#080808', image: '/images/jerseys/jersey_black.jpg', theme: 'Timeless. Bold. Iconic.' },
      { name: 'White', hex: '#F4F1EA', image: '/images/jerseys/jersey_white.jpg', theme: 'Clean. Fresh. Versatile.' },
      { name: 'Green', hex: '#166534', image: '/images/jerseys/jersey_green.jpg', theme: 'Nature. Lagos. Growth.' },
      { name: 'Red', hex: '#991B1B', image: '/images/jerseys/jersey_red.jpg', theme: 'Energy. Passion. Lagos.' },
      { name: 'Navy Blue', hex: '#1E3A8A', image: '/images/jerseys/jersey_navy.jpg', theme: 'Classic. Calm. Confident.' },
      { name: 'Beige / Stone', hex: '#D6C7A1', image: '/images/jerseys/jersey_beige.jpg', theme: 'Minimal. Refined. Modern.' },
      { name: 'Purple', hex: '#581C87', image: '/images/jerseys/jersey_purple.jpg', theme: 'Distinct. Creative. Lagos.' },
      { name: 'Grey', hex: '#475569', image: '/images/jerseys/jersey_grey.jpg', theme: 'Modern. Versatile. Essential.' }
    ],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    description: 'The celebrated 3KO Football Jersey, bridging Nigerian pitch heritage with contemporary streetwear culture. Crafted from custom jacquard fabric with woven palm motifs, embroidered Lagos palm crest, signature 3KO chest logo, Lagos coordinates (06°27\'N 03°24\'E), and back squad number 30 with "LAGOS IN EVERY THREAD".',
    editorialNote: 'As presented in the official 3KO Football Jersey Campaign. Available in 8 distinct colorways representing the moods and energies of Lagos.',
    fabricDetails: [
      'Custom-engineered jacquard palm leaf performance fabric',
      'High-definition embroidered Lagos Palm shield crest',
      'Signature heat-transferred tactile 3KO chest wordmark',
      'Lagos geographic coordinates: 06°27\'N 03°24\'E',
      'Dual-stripe engineered rib-knit V-neck collar & sleeve cuffs',
      'Breathable, moisture-wicking quick-dry athletic construction',
      'Numbered back: LAGOS 30 with skyline silhouette graphic'
    ],
    careInstructions: [
      'Machine wash cold on gentle cycle',
      'Do not use fabric softener or bleach',
      'Line dry only; do not iron over silicone prints'
    ],
    fit: 'Athletic streetwear cut with natural drape. True to size.',
    images: [
      '/images/jerseys/jersey_black.jpg',
      '/images/jerseys/jersey_white.jpg',
      '/images/jerseys/jersey_green.jpg',
      '/images/jerseys/jersey_red.jpg',
      '/images/jerseys/jersey_navy.jpg',
      '/images/jerseys/jersey_beige.jpg',
      '/images/jerseys/jersey_purple.jpg',
      '/images/jerseys/jersey_grey.jpg',
      '/images/jerseys/jersey_craft_details.jpg'
    ],
    isFeatured: true,
    isBestSeller: true,
    isNew: true,
    packagingNote: 'Arrives in the optional recommended 3KO Collector Box with coordinates seal.',
    boxPackaging: {
      available: true,
      boxName: '3KO LAGOS HARBOR COLLECTOR BOX',
      collectionId: '003',
      boxImage: '/images/packaging/box_003_lagos_island.jpg',
      priceNGN: 15000,
      priceUSD: 12,
      priceGBP: 10,
      coordinates: '06°27\'N 03°24\'E',
      description: 'Cobalt Blue 1200 GSM rigid box with serialized collector authentication card.'
    }
  },

  // ==========================================
  // SMARTWEAR (3KO FORM): POLOS IN ALL 9 COLORS
  // ==========================================
  {
    id: 'prod-005-polo',
    slug: 'lagos-005-polo',
    name: '3KO — 3KO 005 SMART PIQUE POLO',
    subtitle: 'Classic Smart Pique Polo — Sky Blue Edition',
    line: 'form',
    category: 'polos',
    collectionId: '005',
    collectionName: '3KO 005 — TARKWA BAY',
    priceNGN: 68000,
    priceUSD: 45,
    priceGBP: 36,
    color: 'Sky Blue',
    colorHex: '#38BDF8',
    secondaryColors: [
      { name: 'Sky Blue (005 Tarkwa Bay)', hex: '#38BDF8' },
      { name: 'Jet Black (001 Ikoyi)', hex: '#080808' },
      { name: 'Chalk White (002 Theatre)', hex: '#FFFFFF' },
      { name: 'Navy Blue (003 Island)', hex: '#1E3A8A' },
      { name: 'Crimson Red (004 Balogun)', hex: '#DC2626' },
      { name: 'Forest Green (006 VI)', hex: '#16A34A' },
      { name: 'Earth Brown (007 Yaba)', hex: '#854D0E' },
      { name: 'Stone Grey (008 Badagry)', hex: '#64748B' },
      { name: 'Dusty Pink (009 Freedom)', hex: '#EC4899' }
    ],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    description: 'A contemporary polo inspired by the relaxed energy of Tarkwa Bay, designed as the cornerstone of 3KO FORM. Tailored for smart-casual elegance in tropical climates, balancing unstructured drape with refined collar poise.',
    editorialNote: 'Styled seamlessly with light cream straight trousers. Presented in the 3KO packaging lookbook inside the sky-blue rigid box.',
    fabricDetails: [
      '100% long-staple combed cotton pique (260 GSM)',
      'Subtle tonal 3KO bubble logo embroidery on left chest',
      'Mother-of-pearl dual buttons with engraved coordinates',
      'Reinforced side split hems with herringbone tape binding',
      'Pre-shrunk and garment-washed for ultra-soft handfeel'
    ],
    careInstructions: [
      'Machine wash cold (30°C) with similar colors',
      'Warm iron inside out; do not iron over embroidery',
      'Dry flat in shade'
    ],
    fit: 'Modern regular fit. True to size.',
    images: [
      '/images/packaging/box_005_tarkwa_bay.jpg',
      '/images/brand/form_panel.jpg',
      '/images/social/social_2_polo_embroidery.jpg'
    ],
    isFeatured: true,
    isBestSeller: true,
    isNew: true,
    packagingNote: 'Highlight: Delivered in the signature 3KO 005 Sky-Blue rigid magnetic collector box with coordinates (6.4216° N, 3.8085° E).',
    boxPackaging: {
      available: true,
      boxName: '3KO 005 TARKWA BAY COLLECTOR BOX',
      collectionId: '005',
      boxImage: '/images/packaging/box_005_tarkwa_bay.jpg',
      priceNGN: 15000,
      priceUSD: 12,
      priceGBP: 10,
      coordinates: '6.4216° N, 3.8085° E',
      description: 'Sky-Blue 1200 GSM collector box with coastal palm sketches, serialized registry card, and archival tissue.'
    }
  },
  {
    id: 'prod-001-polo',
    slug: 'lagos-001-smart-polo',
    name: '3KO — 3KO 001 IKOYI SMART POLO',
    subtitle: 'Signature Obsidian Smart Pique Polo',
    line: 'form',
    category: 'polos',
    collectionId: '001',
    collectionName: '3KO 001 — IKOYI',
    priceNGN: 68000,
    priceUSD: 45,
    priceGBP: 36,
    color: 'Obsidian Black',
    colorHex: '#080808',
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    description: 'The quintessential Ikoyi executive polo. Deep carbon black pique with tonal chest embroidery, paired with light cream tailored trousers for boardroom poise.',
    editorialNote: 'Showcased inside the 3KO 001 collector box packaging suite.',
    fabricDetails: ['260 GSM long-staple cotton pique', 'Tonal black 3KO chest embroidery', 'Rib-knit collar that will not curl'],
    careInstructions: ['Machine wash cold', 'Dry flat'],
    fit: 'Tailored smart-casual fit.',
    images: [
      '/images/packaging/box_001_ikoyi.jpg',
      '/images/brand/form_panel.jpg'
    ],
    isFeatured: true,
    packagingNote: 'Delivered in the 3KO 001 Matte Obsidian rigid box with bridge sketches.',
    boxPackaging: {
      available: true,
      boxName: '3KO 001 IKOYI COLLECTOR BOX',
      collectionId: '001',
      boxImage: '/images/packaging/box_001_ikoyi.jpg',
      priceNGN: 15000,
      priceUSD: 12,
      priceGBP: 10,
      coordinates: '6.4289° N, 3.3672° E',
      description: 'Matte Obsidian 1200 GSM rigid box with white architectural sketch of Lekki-Ikoyi Bridge.'
    }
  },
  {
    id: 'prod-006-polo',
    slug: 'lagos-006-smart-polo',
    name: '3KO — 3KO 006 VICTORIA ISLAND SMART POLO',
    subtitle: 'Executive Forest Green Pique Polo',
    line: 'form',
    category: 'polos',
    collectionId: '006',
    collectionName: '3KO 006 — VICTORIA ISLAND',
    priceNGN: 68000,
    priceUSD: 45,
    priceGBP: 36,
    color: 'Forest Palm Green',
    colorHex: '#16A34A',
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    description: 'Designed for the corporate towers of Ozumba Mbadiwe. Rich evergreen pique with mother-of-pearl buttons, packaged in the Victoria Island green collector box.',
    editorialNote: 'Tailored for tropical executive refinement without British suit stiffness.',
    fabricDetails: ['260 GSM combed cotton', 'Custom engraved VI coordinates', 'Side split hem'],
    careInstructions: ['Gentle wash cold', 'Warm iron'],
    fit: 'Clean tailored fit.',
    images: [
      '/images/packaging/box_006_victoria_island.jpg',
      '/images/apparel/look_006_vi_tailored_blazer_suit.jpg'
    ],
    packagingNote: 'Shipped in the 3KO 006 Forest Green collector presentation box.',
    boxPackaging: {
      available: true,
      boxName: '3KO 006 VICTORIA ISLAND COLLECTOR BOX',
      collectionId: '006',
      boxImage: '/images/packaging/box_006_victoria_island.jpg',
      priceNGN: 15000,
      priceUSD: 12,
      priceGBP: 10,
      coordinates: '6.4281° N, 3.3988° E',
      description: 'Forest Green 1200 GSM box featuring sketches of VI glass high-rises and harbor.'
    }
  },

  // ==========================================
  // SMARTWEAR: TAILORED TROUSERS & CHINOS
  // ==========================================
  {
    id: 'prod-005-trouser',
    slug: 'lagos-005-trousers',
    name: '3KO — 3KO 005 PLEATED LINEN TROUSERS',
    subtitle: 'Relaxed Straight-Leg Linen-Cotton Pant',
    line: 'form',
    category: 'trousers',
    collectionId: '005',
    collectionName: '3KO 005 — TARKWA BAY',
    priceNGN: 82000,
    priceUSD: 55,
    priceGBP: 44,
    color: 'Light Cream',
    colorHex: '#F4F1EA',
    secondaryColors: [
      { name: 'Light Cream', hex: '#F4F1EA' },
      { name: 'Charcoal Black', hex: '#181818' }
    ],
    sizes: ['30', '32', '34', '36', '38'],
    description: 'Designed as the foundation for 3KO FORM. Tailored with double forward pleats, mid-rise waist, and clean straight leg for breathability in tropical heat without compromising sharp lines.',
    editorialNote: 'Shown in the packaging reference suite inside the 3KO 005 box next to the sky-blue polo.',
    fabricDetails: [
      '55% French linen, 45% organic Aegean cotton',
      'Deep functional slash pockets and rear button-through jetted pockets',
      'Hidden interior waist drawstring for optional belt-free wear',
      'Corozo nut buttons dyed to match fabric tone'
    ],
    careInstructions: ['Gentle cold wash or dry clean', 'Steam iron while damp'],
    fit: 'Relaxed straight leg with clean break at ankle.',
    images: [
      '/images/packaging/box_005_tarkwa_bay.jpg',
      '/images/social/social_5_street_walk.jpg'
    ],
    isFeatured: true,
    packagingNote: 'Shipped optionally in the 3KO 005 box with wooden travel hanger.',
    boxPackaging: {
      available: true,
      boxName: '3KO 005 TARKWA BAY COLLECTOR BOX',
      collectionId: '005',
      boxImage: '/images/packaging/box_005_tarkwa_bay.jpg',
      priceNGN: 15000,
      priceUSD: 12,
      priceGBP: 10,
      coordinates: '6.4216° N, 3.8085° E',
      description: 'Sky-Blue 1200 GSM rigid box with archival tissue.'
    }
  },
  {
    id: 'prod-006-trousers',
    slug: 'lagos-006-tailored-trousers',
    name: '3KO — 3KO 006 VICTORIA ISLAND TAILORED TROUSERS',
    subtitle: 'Architectural Charcoal Wool-Blend Trouser',
    line: 'form',
    category: 'trousers',
    collectionId: '006',
    collectionName: '3KO 006 — VICTORIA ISLAND',
    priceNGN: 88000,
    priceUSD: 60,
    priceGBP: 48,
    color: 'Charcoal Black',
    colorHex: '#181818',
    sizes: ['30', '32', '34', '36', '38'],
    description: 'Sharp tailored trousers formulated for boardroom engagements and diplomatic gallery evenings. Features clean front closure and pressed creases.',
    editorialNote: 'As shown in the Victoria Island smartwear collection sheet.',
    fabricDetails: ['Tropical wool and Tencel blend (breathable)', 'Adjustable side waist tabs'],
    careInstructions: ['Dry clean only'],
    fit: 'Clean tailored taper.',
    images: [
      '/images/apparel/look_006_vi_tailored_blazer_suit.jpg',
      '/images/packaging/box_006_victoria_island.jpg'
    ],
    packagingNote: 'Optional recommended 3KO 006 Forest Green collector box.',
    boxPackaging: {
      available: true,
      boxName: '3KO 006 VICTORIA ISLAND COLLECTOR BOX',
      collectionId: '006',
      boxImage: '/images/packaging/box_006_victoria_island.jpg',
      priceNGN: 15000,
      priceUSD: 12,
      priceGBP: 10,
      coordinates: '6.4281° N, 3.3988° E',
      description: 'Forest Green 1200 GSM rigid box with high-rise sketches.'
    }
  },

  // ==========================================
  // SMARTWEAR: TAILORING & OVERSHIRTS
  // ==========================================
  {
    id: 'prod-006-blazer',
    slug: 'lagos-006-structured-blazer',
    name: '3KO — 3KO 006 VICTORIA ISLAND STRUCTURED BLAZER',
    subtitle: 'Modern Minimalist Single-Breasted Jacket',
    line: 'form',
    category: 'tailoring',
    collectionId: '006',
    collectionName: '3KO 006 — VICTORIA ISLAND',
    priceNGN: 135000,
    priceUSD: 92,
    priceGBP: 74,
    color: 'Heather Charcoal Grey',
    colorHex: '#334155',
    sizes: ['38R', '40R', '42R', '44R'],
    description: 'The pinnacle of 3KO FORM. Unstructured shoulder pads for tropical movement, notched lapels, horn buttons, and subtle tonal 3KO embroidery inside the breast pocket.',
    editorialNote: 'Displayed prominently in the Victoria Island collection campaign look.',
    fabricDetails: ['Fine tropical wool and silk blend', 'Half-lined in breathable Bemberg cupro', 'Dual rear vents'],
    careInstructions: ['Professional dry clean only'],
    fit: 'Modern tailored fit with relaxed shoulders.',
    images: [
      '/images/apparel/look_006_vi_tailored_blazer_suit.jpg',
      '/images/packaging/box_006_victoria_island.jpg'
    ],
    isFeatured: true,
    packagingNote: 'Delivered in the oversized 3KO 006 Collector Box with custom cedar hanger.',
    boxPackaging: {
      available: true,
      boxName: '3KO 006 VICTORIA ISLAND COLLECTOR BOX',
      collectionId: '006',
      boxImage: '/images/packaging/box_006_victoria_island.jpg',
      priceNGN: 15000,
      priceUSD: 12,
      priceGBP: 10,
      coordinates: '6.4281° N, 3.3988° E',
      description: 'Forest Green 1200 GSM box with VI sketches.'
    }
  },
  {
    id: 'prod-006-overshirt',
    slug: 'lagos-006-overshirt',
    name: '3KO — 3KO 006 MINIMALIST SMART OVERSHIRT',
    subtitle: 'Corporate Casual Button-Up with Hidden Placket',
    line: 'form',
    category: 'tailoring',
    collectionId: '006',
    collectionName: '3KO 006 — VICTORIA ISLAND',
    priceNGN: 78000,
    priceUSD: 52,
    priceGBP: 42,
    color: 'Pitch Black',
    colorHex: '#080808',
    sizes: ['S', 'M', 'L', 'XL'],
    description: 'Crisp button-up shirt in dense cotton poplin featuring a clean hidden front placket and circular 3KO chest patch. Transition seamlessly from meetings on Ozumba Mbadiwe to rooftop lounges.',
    editorialNote: 'As seen in the Victoria Island smartwear ensemble.',
    fabricDetails: ['100% Egyptian cotton poplin (160 GSM)', 'Hidden button placket', 'Convertible cuffs'],
    careInstructions: ['Warm wash', 'Medium iron'],
    fit: 'Modern smart-casual silhouette.',
    images: [
      '/images/apparel/look_006_vi_tailored_blazer_suit.jpg',
      '/images/packaging/box_006_victoria_island.jpg'
    ],
    packagingNote: 'Optional recommended 3KO 006 Forest Green collector box.',
    boxPackaging: {
      available: true,
      boxName: '3KO 006 VICTORIA ISLAND COLLECTOR BOX',
      collectionId: '006',
      boxImage: '/images/packaging/box_006_victoria_island.jpg',
      priceNGN: 15000,
      priceUSD: 12,
      priceGBP: 10,
      coordinates: '6.4281° N, 3.3988° E',
      description: 'Forest Green 1200 GSM box with VI sketches.'
    }
  },
  {
    id: 'prod-006-clutch',
    slug: 'lagos-006-leather-folio',
    name: '3KO — 3KO 006 ARCHITECTURAL LEATHER FOLIO',
    subtitle: 'Structured Crossbody Portfolio / Clutch',
    line: 'form',
    category: 'tailoring',
    collectionId: '006',
    collectionName: '3KO 006 — VICTORIA ISLAND',
    priceNGN: 58000,
    priceUSD: 39,
    priceGBP: 31,
    color: 'Matte Black',
    colorHex: '#080808',
    sizes: ['ONE SIZE (32cm x 22cm)'],
    description: 'Handcrafted in full-grain Nigerian leather with high-relief white 3KO bubble emblem, gunmetal zipper, and detachable wristlet strap. Sized for tablets, documents, and essentials.',
    editorialNote: 'As shown in the Victoria Island ensemble in the uploaded lookbook.',
    fabricDetails: ['100% full-grain calf leather', 'YKK Excella metal zipper', 'Microfiber suede interior'],
    careInstructions: ['Treat with natural leather balm'],
    fit: 'Slim architectural profile.',
    images: [
      '/images/apparel/look_006_vi_tailored_blazer_suit.jpg',
      '/images/packaging/box_006_victoria_island.jpg'
    ],
    packagingNote: 'Delivered in the 3KO 006 Forest Green collector box.',
    boxPackaging: {
      available: true,
      boxName: '3KO 006 VICTORIA ISLAND COLLECTOR BOX',
      collectionId: '006',
      boxImage: '/images/packaging/box_006_victoria_island.jpg',
      priceNGN: 15000,
      priceUSD: 12,
      priceGBP: 10,
      coordinates: '6.4281° N, 3.3988° E',
      description: 'Forest Green 1200 GSM box.'
    }
  },

  // ==========================================
  // STANDALONE COLLECTOR BOX PACKAGING SUITES
  // ==========================================
  {
    id: 'prod-all-boxes',
    slug: 'lagos-collector-box-suites',
    name: '3KO — THE 9 LAGOS COLLECTOR BOX SUITES',
    subtitle: 'Architectural 1200 GSM Rigid Storage Boxes (001–009)',
    line: 'edition',
    category: 'packaging',
    collectionId: '005',
    collectionName: 'THE 3KO PACKAGING SYSTEM',
    priceNGN: 25000,
    priceUSD: 18,
    priceGBP: 14,
    color: 'Sky Blue (005 Tarkwa Bay)',
    colorHex: '#38BDF8',
    secondaryColors: [
      { name: '001 Ikoyi (Black)', hex: '#080808', image: '/images/packaging/box_001_ikoyi.jpg' },
      { name: '002 National Theatre (White)', hex: '#FFFFFF', image: '/images/packaging/box_002_national_theatre.jpg' },
      { name: '003 Lagos Island (Dark Blue)', hex: '#1E3A8A', image: '/images/packaging/box_003_lagos_island.jpg' },
      { name: '004 Balogun (Red)', hex: '#DC2626', image: '/images/packaging/box_004_balogun.jpg' },
      { name: '005 Tarkwa Bay (Sky Blue)', hex: '#38BDF8', image: '/images/packaging/box_005_tarkwa_bay.jpg' },
      { name: '006 Victoria Island (Green)', hex: '#16A34A', image: '/images/packaging/box_006_victoria_island.jpg' },
      { name: '007 Yaba (Brown)', hex: '#854D0E', image: '/images/packaging/box_007_yaba.jpg' },
      { name: '008 Badagry (Grey)', hex: '#64748B', image: '/images/packaging/box_008_badagry.jpg' },
      { name: '009 Freedom Park (Pink)', hex: '#EC4899', image: '/images/packaging/box_009_freedom_park.jpg' }
    ],
    sizes: ['ONE SIZE (34cm x 26cm x 7cm)'],
    description: 'The acclaimed 3KO collectible packaging system shown in the uploaded material. Available across all nine Lagos collections, featuring rigid 1200 GSM greyboard, location architectural sketches, embossed 3KO bubble logo, GPS coordinates, serialized registry card, and archival tissue.',
    editorialNote: 'Designed as an architectural art object for your closet or living space. Fits up to 2 folded garments.',
    fabricDetails: [
      '1200 GSM ultra-rigid core board',
      'Dual hidden neodymium magnetic closures',
      'Location-specific foil stamped coordinates',
      'Numbered certificate of authenticity included'
    ],
    careInstructions: ['Wipe clean with dry microfiber cloth'],
    fit: 'Dimensions: 34cm x 26cm x 7cm.',
    images: [
      '/images/packaging/box_005_tarkwa_bay.jpg',
      '/images/packaging/box_001_ikoyi.jpg',
      '/images/packaging/box_002_national_theatre.jpg',
      '/images/packaging/box_003_lagos_island.jpg',
      '/images/packaging/box_004_balogun.jpg',
      '/images/packaging/box_006_victoria_island.jpg',
      '/images/packaging/box_007_yaba.jpg',
      '/images/packaging/box_008_badagry.jpg',
      '/images/packaging/box_009_freedom_park.jpg'
    ],
    isFeatured: true,
    packagingNote: 'Highlight: The full 9-box collector packaging system as detailed in the uploaded reference sheets.',
    boxPackaging: {
      available: false,
      boxName: 'Included with Box Order',
      collectionId: '005',
      boxImage: '/images/packaging/box_005_tarkwa_bay.jpg',
      priceNGN: 0,
      priceUSD: 0,
      priceGBP: 0,
      coordinates: 'Lagos, Nigeria',
      description: 'The packaging box itself.'
    }
  }
];
