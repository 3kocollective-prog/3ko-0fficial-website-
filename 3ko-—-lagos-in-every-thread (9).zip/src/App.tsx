import React, { useEffect } from 'react';
import { ShopProvider, useShop } from './context/ShopContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { CartDrawer } from './components/CartDrawer';
import { SearchModal } from './components/SearchModal';
import { SizeGuideModal } from './components/SizeGuideModal';
import { CheckoutModal } from './components/CheckoutModal';
import { QuickViewModal } from './components/QuickViewModal';
import { HomePage } from './pages/HomePage';
import { ShopPage } from './pages/ShopPage';
import { StreetwearPage } from './pages/StreetwearPage';
import { SmartwearPage } from './pages/SmartwearPage';
import { CollectionDetailPage } from './pages/CollectionDetailPage';
import { ProductDetailPage } from './pages/ProductDetailPage';
import { AboutPage } from './pages/AboutPage';
import { LagosCulturalPage } from './pages/LagosCulturalPage';
import { ContactPage } from './pages/ContactPage';
import { AdminDashboardPage } from './pages/AdminDashboardPage';
import { Check } from 'lucide-react';

const MainRouter: React.FC = () => {
  const { currentRoute, toastMessage, theme } = useShop();

  // Scroll to top whenever current route changes
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentRoute]);

  const renderContent = () => {
    // Normalize path (strip query params and trailing slash)
    const normalizedRoute = currentRoute.split('?')[0].replace(/\/+$/, '') || '/';

    // Route: /collections/:slug
    if (normalizedRoute.startsWith('/collections/')) {
      const slug = normalizedRoute.replace('/collections/', '');
      return <CollectionDetailPage slug={slug} />;
    }

    // Route: /product/:slug
    if (normalizedRoute.startsWith('/product/')) {
      const slug = normalizedRoute.replace('/product/', '');
      return <ProductDetailPage slug={slug} />;
    }

    switch (normalizedRoute) {
      case '/admin':
        return <AdminDashboardPage />;
      case '/shop':
        return <ShopPage initialLine="all" />;
      case '/street':
        return <StreetwearPage />;
      case '/form':
        return <SmartwearPage />;
      case '/collections':
        return <LagosCulturalPage />;
      case '/about':
        return <AboutPage />;
      case '/lagos':
        return <LagosCulturalPage />;
      case '/contact':
        return <ContactPage />;
      case '/':
      default:
        return <HomePage />;
    }
  };

  return (
    <div
      className={`min-h-screen flex flex-col transition-colors duration-300 ${
        theme === 'dark'
          ? 'bg-[#080808] text-[#F4F1EA] selection:bg-[#F4F1EA] selection:text-[#080808]'
          : 'bg-[#F9F8F5] text-[#0E0E0E] selection:bg-[#0E0E0E] selection:text-[#F9F8F5]'
      }`}
    >
      {/* Toast Notification Container */}
      {toastMessage && (
        <div
          className={`fixed top-20 right-5 z-50 px-4 py-3 shadow-2xl flex items-center gap-2.5 text-xs font-mono animate-in slide-in-from-top-2 duration-200 border ${
            theme === 'dark'
              ? 'bg-[#161616] border-white/20 text-white'
              : 'bg-white border-black/15 text-neutral-900 shadow-lg'
          }`}
        >
          <Check className="w-4 h-4 text-emerald-500 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}


      {/* Global Navigation */}
      <Navbar />

      {/* Primary Page Content */}
      <main className="flex-1 w-full">{renderContent()}</main>

      {/* Global Footer */}
      <Footer />

      {/* Drawers and Modals */}
      <CartDrawer />
      <SearchModal />
      <SizeGuideModal />
      <CheckoutModal />
      <QuickViewModal />
    </div>
  );
};

export default function App() {
  return (
    <ShopProvider>
      <MainRouter />
    </ShopProvider>
  );
}
